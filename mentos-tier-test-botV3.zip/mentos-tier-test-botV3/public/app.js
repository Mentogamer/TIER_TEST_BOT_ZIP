(() => {
  const $ = (s, el = document) => el.querySelector(s);
  const app = $('#app');
  let CFG = null;

  function h(tag, attrs, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') e.className = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v);
    }
    for (const c of kids.flat()) { if (c == null || c === false) continue; e.append(c.nodeType ? c : document.createTextNode(String(c))); }
    return e;
  }
  const api = async (url, opts) => {
    const r = await fetch(url, opts);
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || 'Request failed');
    return j;
  };
  const date = (iso) => new Date(iso).toLocaleDateString();
  const playerLink = (ign) => h('a', { class: 'chip', href: '#/player/' + encodeURIComponent(ign) }, ign);
  const show = (...nodes) => { app.replaceChildren(...nodes); };

  /* ---------------- header: auth + search ---------------- */
  async function renderAuth() {
    const box = $('#auth');
    const me = await api('/api/me').catch(() => ({ loggedIn: false }));
    if (me.loggedIn) {
      box.replaceChildren(
        h('a', { class: 'btn alt', href: '#/me' }, me.profile ? me.profile.ign : 'My Profile'), ' ',
        h('button', { class: 'btn alt', onclick: async () => { await api('/auth/logout', { method: 'POST' }); renderAuth(); location.hash = '#/'; } }, 'Log out'));
    } else if (me.loginAvailable) box.replaceChildren(h('a', { class: 'btn', href: '/auth/login' }, 'Login with Discord'));
    else box.replaceChildren();
  }
  const q = $('#q'), sres = $('#sres');
  let timer;
  q.addEventListener('input', () => {
    clearTimeout(timer);
    timer = setTimeout(async () => {
      const t = q.value.trim();
      if (t.length < 2) { sres.style.display = 'none'; return; }
      const { players } = await api('/api/search?q=' + encodeURIComponent(t)).catch(() => ({ players: [] }));
      sres.replaceChildren(...(players.length ? players.map((p) => h('a', { href: '#/player/' + encodeURIComponent(p.ign), onclick: () => { sres.style.display = 'none'; q.value = ''; } }, p.ign)) : [h('a', {}, 'No players found')]));
      sres.style.display = 'block';
    }, 200);
  });
  document.addEventListener('click', (e) => { if (!e.target.closest('.search')) sres.style.display = 'none'; });

  /* ---------------- pages ---------------- */
  async function tierlist(gmName) {
    const gms = CFG.gamemodes;
    if (!gms.length) return show(h('h1', {}, 'Tier Lists'), h('p', { class: 'muted' }, 'No gamemodes yet.'));
    const current = gms.find((g) => g.name.toLowerCase() === (gmName || '').toLowerCase()) || gms[0];
    const data = await api('/api/tierlist/' + encodeURIComponent(current.name));
    show(
      h('h1', {}, `${current.emoji} ${current.name}`),
      h('div', { class: 'tabs' }, gms.map((g) => h('button', { class: 'tab' + (g.id === current.id ? ' on' : ''), onclick: () => { location.hash = '#/gm/' + encodeURIComponent(g.name); } }, `${g.emoji} ${g.name}`))),
      data.total === 0 ? h('p', { class: 'muted' }, 'Nobody is ranked in this gamemode yet.') : null,
      data.tiers.filter((t) => t.players.length).map((t) => h('div', { class: 'card tier' }, h('div', { class: 't' }, t.tier), h('div', { class: 'chips' }, t.players.map(playerLink)))),
    );
  }

  async function leaderboard() {
    const { players } = await api('/api/leaderboard');
    show(h('h1', {}, 'Overall Rankings'),
      players.length ? h('div', { class: 'card' }, h('table', {},
        h('thead', {}, h('tr', {}, h('th', {}, '#'), h('th', {}, 'Player'), h('th', {}, 'Ranked gamemodes'), h('th', {}, 'Points'))),
        h('tbody', {}, players.map((p, i) => h('tr', {}, h('td', {}, i + 1), h('td', {}, h('a', { href: '#/player/' + encodeURIComponent(p.ign) }, p.ign)), h('td', {}, p.gamemodes), h('td', {}, h('b', {}, p.points))))))
      ) : h('p', { class: 'muted' }, 'No ranked players yet.'));
  }

  async function recent() {
    const { results } = await api('/api/recent');
    show(h('h1', {}, 'Recent Results'),
      results.length ? h('div', { class: 'card' }, h('table', {},
        h('thead', {}, h('tr', {}, h('th', {}, 'Player'), h('th', {}, 'Gamemode'), h('th', {}, 'Result'), h('th', {}, 'Tester'), h('th', {}, 'Date'))),
        h('tbody', {}, results.map((r) => h('tr', {},
          h('td', {}, h('a', { href: '#/player/' + encodeURIComponent(r.ign || '') }, r.ign || '—')),
          h('td', {}, `${r.emoji} ${r.gamemode}`),
          h('td', {}, `${r.old_tier} → `, h('b', { class: r.is_high ? 'hi' : '' }, r.new_tier), r.is_high ? ' 🔥' : ''),
          h('td', { class: 'muted' }, r.tester || '—'), h('td', { class: 'muted' }, date(r.created_at))))))
      ) : h('p', { class: 'muted' }, 'No results yet.'));
  }

  async function player(ign) {
    let p;
    try { p = await api('/api/player/' + encodeURIComponent(ign)); }
    catch { return show(h('h1', {}, 'Player not found'), h('p', { class: 'muted' }, `There is no profile for "${ign}".`)); }
    const latest = p.history.slice(0, 5);
    show(
      h('h1', {}, p.ign),
      h('p', { class: 'muted' }, `Tests completed: `, h('b', {}, p.testsCompleted), ` • Profile since ${date(p.createdAt)}`),
      h('div', { class: 'grid' }, p.tiers.map((t) => h('div', { class: 'card' },
        h('div', { class: 'muted' }, `${t.emoji} ${t.name}`),
        h('div', { class: 'big' }, t.current_tier || 'Not Tested'),
        h('div', { class: 'muted' }, t.current_tier ? 'verified' : '')))),
      h('h2', {}, 'Latest Results'),
      latest.length ? h('div', { class: 'card' }, latest.map((r) => h('div', {}, `${r.emoji} ${r.gamemode}: ${r.old_tier} → `, h('b', {}, r.new_tier), r.is_high ? ' 🔥' : ''))) : h('p', { class: 'muted' }, 'No results yet.'),
      h('h2', {}, 'Test History'),
      p.history.length ? h('div', { class: 'card' }, h('table', {},
        h('thead', {}, h('tr', {}, h('th', {}, 'Gamemode'), h('th', {}, 'Change'), h('th', {}, 'Tester'), h('th', {}, 'Date'))),
        h('tbody', {}, p.history.map((r) => h('tr', {}, h('td', {}, `${r.emoji} ${r.gamemode}`), h('td', {}, `${r.old_tier} → ${r.new_tier}${r.is_high ? ' 🔥' : ''}`), h('td', { class: 'muted' }, r.tester || '—'), h('td', { class: 'muted' }, date(r.created_at))))))
      ) : h('p', { class: 'muted' }, 'Nothing yet.'));
  }

  async function me() {
    const m = await api('/api/me');
    if (!m.loggedIn) {
      return show(h('h1', {}, 'My Profile'), m.loginAvailable
        ? h('p', {}, h('a', { class: 'btn', href: '/auth/login' }, 'Login with Discord'))
        : h('p', { class: 'muted' }, 'Website login is not enabled on this server. Use the #profile channel in Discord.'));
    }
    if (!m.profile) {
      return show(h('h1', {}, 'No profile yet'), h('p', { class: 'muted' }, 'Create your profile in the #profile channel on Discord (IGN + gamemodes). It will appear here automatically.'));
    }
    const msg = h('div');
    const ign = h('input', { type: 'text', maxlength: '16', value: m.profile.ign, placeholder: 'Minecraft IGN' });
    const save = h('button', { class: 'btn', onclick: async () => {
      try {
        await api('/api/me/profile', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ign: ign.value.trim() }) });
        msg.replaceChildren(h('div', { class: 'msg ok' }, 'IGN saved. It is synced with Discord.'));
        renderAuth();
      } catch (e) { msg.replaceChildren(h('div', { class: 'msg err' }, e.message)); }
    } }, 'Save IGN');
    show(
      h('h1', {}, `Welcome, ${m.profile.ign}`),
      h('p', { class: 'muted' }, `Tests completed: ${m.profile.testsCompleted} • `, h('a', { href: '#/player/' + encodeURIComponent(m.profile.ign) }, 'View public profile')),
      h('div', { class: 'card' }, h('label', {}, 'Minecraft IGN'), ign, msg, h('div', { class: 'row' }, save)),
      h('h2', {}, 'Your gamemodes'),
      h('p', { class: 'muted' }, 'Gamemodes are chosen in the #profile channel on Discord. Tiers are set by testers only; players without a result are Not Tested.'),
      h('div', { class: 'grid' }, m.gamemodes.filter((g) => g.selected).map((g) => h('div', { class: 'card' },
        h('div', { class: 'muted' }, `${g.emoji} ${g.name}`), h('div', { class: 'big' }, g.tier), h('div', { class: 'muted' }, g.verified ? 'verified' : '')))));
  }

  /* ---------------- router ---------------- */
  async function route() {
    const parts = (location.hash.replace(/^#\/?/, '') || '').split('/').map(decodeURIComponent);
    try {
      if (!parts[0]) return await tierlist();
      if (parts[0] === 'gm') return await tierlist(parts[1]);
      if (parts[0] === 'leaderboard') return await leaderboard();
      if (parts[0] === 'recent') return await recent();
      if (parts[0] === 'player') return await player(parts.slice(1).join('/'));
      if (parts[0] === 'me') return await me();
      await tierlist();
    } catch (e) { show(h('div', { class: 'msg err' }, e.message)); }
  }

  (async () => {
    CFG = await api('/api/config');
    $('#brand').textContent = CFG.brand;
    document.title = `${CFG.brand} — Tier Lists`;
    renderAuth();
    window.addEventListener('hashchange', route);
    route();
  })().catch((e) => show(h('div', { class: 'msg err' }, e.message)));
})();
