import 'dotenv/config';
import path from 'node:path';

function parseDbPath(url: string): string {
  let p = url.trim();
  if (p.startsWith('file:')) p = p.slice(5);
  if (p.startsWith('//')) p = p.slice(2);
  return path.resolve(process.cwd(), p);
}

const webPort = Number(process.env.WEB_PORT ?? 3000);
const publicUrl = (process.env.WEB_PUBLIC_URL ?? `http://localhost:${webPort}`).replace(/\/+$/, '');
const databaseUrl = process.env.DATABASE_URL ?? 'file:./data/tiertest.db';

export const config = {
  token: process.env.DISCORD_TOKEN ?? '',
  clientId: process.env.CLIENT_ID ?? '',
  guildId: process.env.GUILD_ID ?? '',
  clientSecret: process.env.DISCORD_CLIENT_SECRET ?? '',
  databaseUrl,
  dbPath: parseDbPath(databaseUrl),
  webPort,
  webHost: process.env.WEB_HOST ?? '0.0.0.0',
  sessionSecret: process.env.SESSION_SECRET ?? '',
  webPublicUrl: publicUrl,
  oauthRedirect: process.env.OAUTH_REDIRECT_URI ?? `${publicUrl}/auth/callback`,
  staffRoleIds: (process.env.STAFF_ROLE_IDS ?? '').split(',').map((s) => s.trim()).filter(Boolean),
  queueManagerRoleIds: (process.env.QUEUE_MANAGER_ROLE_IDS ?? '').split(',').map((s) => s.trim()).filter(Boolean),
  autoRegister: (process.env.AUTO_REGISTER_COMMANDS ?? 'true').toLowerCase() !== 'false',
  ticketCloseDelaySec: Math.max(0, Number(process.env.TICKET_CLOSE_DELAY_SECONDS ?? 10)),
};

export function assertBotConfig(): void {
  const names: Record<string, string> = { token: 'DISCORD_TOKEN', clientId: 'CLIENT_ID', guildId: 'GUILD_ID' };
  const missing = Object.keys(names).filter((k) => !(config as any)[k]).map((k) => names[k]);
  if (missing.length) throw new Error(`Missing required environment variables: ${missing.join(', ')} (see .env.example)`);
}

export function assertWebConfig(): void {
  if (config.sessionSecret.length < 16) {
    throw new Error('SESSION_SECRET must be set to a random string of at least 16 characters (see .env.example)');
  }
}
