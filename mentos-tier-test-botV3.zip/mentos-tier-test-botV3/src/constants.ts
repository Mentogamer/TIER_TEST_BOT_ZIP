export const BRAND = "Mento's Tier Test Bot";
export const UNRANKED = 'Unranked';
/** A player with no recorded result in a gamemode is "Not Tested" there (no Discord role is granted for it). */
export const DEFAULT_TIER = 'Not Tested';

/** Lowest to highest. */
export const TIER_LADDER = ['LT5', 'HT5', 'LT4', 'HT4', 'LT3', 'HT3', 'LT2', 'HT2', 'LT1', 'HT1'];

export const TIER_POINTS: Record<string, number> = {
  LT5: 1, HT5: 2, LT4: 3, HT4: 4, LT3: 6, HT3: 10, LT2: 20, HT2: 32, LT1: 44, HT1: 60,
};

export const TIER_ROLE_COLORS: Record<string, number> = {
  LT5: 0x95a5a6, HT5: 0xbdc3c7, LT4: 0x2ecc71, HT4: 0x1abc9c, LT3: 0x3498db,
  HT3: 0x2980b9, LT2: 0x9b59b6, HT2: 0x8e44ad, LT1: 0xf1c40f, HT1: 0xe67e22,
};
export const TESTER_ROLE_COLOR = 0x5865f2;

export const DEFAULT_GAMEMODES = [
  { name: 'Sword', emoji: '⚔️' },
  { name: 'Axe', emoji: '🪓' },
  { name: 'UHC', emoji: '🏹' },
  { name: 'DiaPot', emoji: '🧪' },
  { name: 'NethPot', emoji: '🧪' },
  { name: 'Crystal', emoji: '💎' },
  { name: 'Mace', emoji: '🔨' },
  { name: 'Spear-Mace', emoji: '🔱' },
  { name: 'Cart', emoji: '🛒' },
];

export const COLORS = {
  primary: 0x5865f2,
  success: 0x2ecc71,
  error: 0xe74c3c,
  warn: 0xf1c40f,
  high: 0xf39c12,
};

export const STRUCTURE = {
  requestCategory: '📋 REQUEST TEST',
  ticketCategory: '🎫 TIER TEST TICKET',
  logCategory: '📜 TIER TEST LOGS',
  requestChannel: 'request-test',
  ticketsChannel: 'testing-tickets',
  logsChannel: 'tier-test-logs',
  profileChannel: 'profile',
  waitlistCategory: 'WAITLIST',
  resultChannel: 'result',
  highResultChannel: 'high-result',
  tierListChannel: 'tier-list',
};

/** Log channel key (bot_config) -> channel name. 'admin' reuses the original #tier-test-logs. */
export const LOG_CHANNELS: Record<string, { key: string; name: string; topic: string }> = {
  admin: { key: 'logs_channel', name: 'tier-test-logs', topic: 'Administrative actions, profile changes and errors.' },
  queue: { key: 'log_queue', name: 'queue-logs', topic: 'Queue opened/closed, joins and leaves.' },
  ticket: { key: 'log_ticket', name: 'ticket-logs', topic: 'Ticket creation, claims and closures.' },
  tester: { key: 'log_tester', name: 'tester-logs', topic: 'Tester role assignments and permissions.' },
  result: { key: 'log_result', name: 'result-logs', topic: 'Test results and high results.' },
};
export type LogKind = keyof typeof LOG_CHANNELS;

export const GAMEMODE_BLURBS: Record<string, string> = {
  sword: 'Classic sword PvP — pure 1v1 fighting skill.',
  axe: 'Axe PvP — shield breaking, timing and burst damage.',
  uhc: 'UHC — golden apples, lava, bows and rods. Survival PvP.',
  diapot: 'Diamond pot PvP — potion sustain and armor management.',
  nethpot: 'Netherite pot PvP — the high-end potion fighting meta.',
  crystal: 'Crystal PvP — end crystals, obsidian and totems.',
  mace: 'Mace PvP — wind charges, smash attacks and positioning.',
  'spear-mace': 'Spear + Mace — reach, mobility and heavy smash combos.',
  cart: 'Cart PvP — TNT minecarts, rails and trap play.',
};

export const channelSlug = (s: string) => (s ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
/** Loose comparison key: ignores emoji, punctuation, case. "📋 REQUEST TEST" === "request-test". */
export const looseKey = (s: string) => (s ?? '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();

export function normalizeTier(raw: string): string | null {
  const v = (raw ?? '').trim().toUpperCase();
  if (['UNRANKED', 'UNRANK', 'NONE', 'N/A', 'NA'].includes(v)) return UNRANKED;
  return TIER_LADDER.includes(v) ? v : null;
}
export const tierRoleName = (tier: string, gamemode: string) => `${tier}-${gamemode}`;
export const testerRoleName = (gamemode: string) => `🧪 ${gamemode} Tester`;
export const tierLabel = (tier: string, gamemode: string) => (tier === UNRANKED || tier === DEFAULT_TIER ? tier : `${tier}-${gamemode}`);
export const tierRank = (tier: string) => TIER_LADDER.indexOf(tier); // -1 = not tested
export const normName = (s: string) => (s ?? '').toLowerCase().replace(/\s+/g, ' ').trim();
