import { migrate, seedDefaults } from './migrations';
import { db } from './connection';
import { config } from '../config';

const n = migrate();
seedDefaults();
console.log(`Database ready at ${config.dbPath} (${n} migration(s) applied).`);
db.close();
