import { db } from './connection';
import { DEFAULT_GAMEMODES, TIER_LADDER, TIER_POINTS } from '../constants';
import { log } from '../logger';

interface Migration { version: number; name: string; sql: string }

export const MIGRATIONS: Migration[] = [
  {
    version: 1,
    name: 'initial schema',
    sql: `
CREATE TABLE users (
  discord_id TEXT PRIMARY KEY,
  username   TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE profiles (
  discord_id TEXT PRIMARY KEY REFERENCES users(discord_id) ON DELETE CASCADE,
  ign        TEXT NOT NULL COLLATE NOCASE UNIQUE,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE gamemodes (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT NOT NULL COLLATE NOCASE UNIQUE,
  emoji      TEXT NOT NULL DEFAULT '🎮',
  active     INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE TABLE tiers (
  name       TEXT PRIMARY KEY,
  rank_order INTEGER NOT NULL UNIQUE,
  points     INTEGER NOT NULL
);

-- What the player says their last tier was (editable by the player, Discord or web)
CREATE TABLE profile_last_tiers (
  discord_id  TEXT NOT NULL REFERENCES users(discord_id) ON DELETE CASCADE,
  gamemode_id INTEGER NOT NULL REFERENCES gamemodes(id),
  tier        TEXT NOT NULL DEFAULT 'Unranked',
  updated_at  TEXT NOT NULL,
  PRIMARY KEY (discord_id, gamemode_id)
);

-- Official current tier. Only written by the result system.
CREATE TABLE player_tiers (
  discord_id  TEXT NOT NULL REFERENCES users(discord_id) ON DELETE CASCADE,
  gamemode_id INTEGER NOT NULL REFERENCES gamemodes(id),
  tier        TEXT NOT NULL REFERENCES tiers(name),
  updated_at  TEXT NOT NULL,
  PRIMARY KEY (discord_id, gamemode_id)
);

CREATE TABLE role_mappings (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  kind        TEXT NOT NULL CHECK (kind IN ('tier','tester')),
  gamemode_id INTEGER NOT NULL REFERENCES gamemodes(id),
  tier        TEXT NOT NULL DEFAULT '',
  role_id     TEXT NOT NULL,
  UNIQUE (kind, gamemode_id, tier)
);

CREATE TABLE tester_assignments (
  discord_id  TEXT NOT NULL,
  gamemode_id INTEGER NOT NULL REFERENCES gamemodes(id),
  assigned_by TEXT,
  created_at  TEXT NOT NULL,
  PRIMARY KEY (discord_id, gamemode_id)
);

CREATE TABLE permissions (
  discord_id TEXT NOT NULL,
  permission TEXT NOT NULL,
  granted_by TEXT,
  created_at TEXT NOT NULL,
  PRIMARY KEY (discord_id, permission)
);

CREATE TABLE queues (
  gamemode_id INTEGER PRIMARY KEY REFERENCES gamemodes(id),
  is_open     INTEGER NOT NULL DEFAULT 0,
  updated_by  TEXT,
  updated_at  TEXT NOT NULL
);

CREATE TABLE queue_entries (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  gamemode_id INTEGER NOT NULL REFERENCES gamemodes(id),
  discord_id  TEXT NOT NULL,
  position    INTEGER NOT NULL DEFAULT 0,
  status      TEXT NOT NULL DEFAULT 'waiting'
              CHECK (status IN ('waiting','ticketed','left','cancelled','completed')),
  joined_at   TEXT NOT NULL,
  updated_at  TEXT NOT NULL
);
CREATE UNIQUE INDEX uq_queue_waiting ON queue_entries(gamemode_id, discord_id) WHERE status = 'waiting';
CREATE INDEX ix_queue_lookup ON queue_entries(gamemode_id, status, joined_at);

CREATE TABLE test_tickets (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  channel_id     TEXT UNIQUE,
  message_id     TEXT,
  discord_id     TEXT NOT NULL,
  gamemode_id    INTEGER NOT NULL REFERENCES gamemodes(id),
  queue_entry_id INTEGER REFERENCES queue_entries(id),
  tester_id      TEXT,
  status         TEXT NOT NULL DEFAULT 'waiting'
                 CHECK (status IN ('waiting','claimed','in_progress','completed','cancelled')),
  last_tier      TEXT NOT NULL DEFAULT 'Unranked',
  created_at     TEXT NOT NULL,
  closed_at      TEXT
);
-- A player can only ever have ONE active testing ticket
CREATE UNIQUE INDEX uq_active_ticket_user ON test_tickets(discord_id) WHERE status IN ('waiting','claimed','in_progress');
CREATE INDEX ix_ticket_gm_status ON test_tickets(gamemode_id, status);

CREATE TABLE tests (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  ticket_id   INTEGER NOT NULL UNIQUE REFERENCES test_tickets(id),
  discord_id  TEXT NOT NULL,
  gamemode_id INTEGER NOT NULL REFERENCES gamemodes(id),
  tester_id   TEXT,
  started_at  TEXT NOT NULL,
  ended_at    TEXT,
  outcome     TEXT
);

-- Permanent result history (never deleted)
CREATE TABLE test_results (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  ticket_id   INTEGER REFERENCES test_tickets(id),
  discord_id  TEXT NOT NULL REFERENCES users(discord_id),
  gamemode_id INTEGER NOT NULL REFERENCES gamemodes(id),
  old_tier    TEXT NOT NULL,
  new_tier    TEXT NOT NULL,
  tester_id   TEXT NOT NULL,
  is_high     INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL
);
CREATE INDEX ix_results_user ON test_results(discord_id, created_at);
CREATE INDEX ix_results_recent ON test_results(created_at);

CREATE TABLE bot_config (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE web_sessions (
  id         TEXT PRIMARY KEY,
  discord_id TEXT NOT NULL,
  username   TEXT NOT NULL,
  created_at TEXT NOT NULL,
  expires_at INTEGER NOT NULL
);
`,
  },
  {
    version: 2,
    name: 'profile gamemodes, drag tickets',
    sql: `
CREATE TABLE profile_gamemodes (
  discord_id  TEXT NOT NULL REFERENCES users(discord_id) ON DELETE CASCADE,
  gamemode_id INTEGER NOT NULL REFERENCES gamemodes(id),
  created_at  TEXT NOT NULL,
  PRIMARY KEY (discord_id, gamemode_id)
);
ALTER TABLE test_tickets ADD COLUMN queue_position INTEGER;
-- a queue entry can only ever produce one ticket (guards against double /drag)
CREATE UNIQUE INDEX uq_ticket_entry ON test_tickets(queue_entry_id) WHERE queue_entry_id IS NOT NULL;
`,
  },
  {
    version: 3,
    name: 'result announcements, role retry, corrections',
    sql: `
ALTER TABLE test_results ADD COLUMN ign TEXT;
ALTER TABLE test_results ADD COLUMN role_status TEXT NOT NULL DEFAULT 'ok';
ALTER TABLE test_results ADD COLUMN role_error TEXT;
ALTER TABLE test_results ADD COLUMN result_message_id TEXT;
ALTER TABLE test_results ADD COLUMN high_message_id TEXT;
ALTER TABLE test_results ADD COLUMN corrects_result_id INTEGER;
ALTER TABLE test_results ADD COLUMN reason TEXT;
-- results that existed before this migration must never be announced retroactively
UPDATE test_results SET result_message_id='legacy',
  high_message_id = CASE WHEN is_high = 1 THEN 'legacy' END,
  ign = (SELECT p.ign FROM profiles p WHERE p.discord_id = test_results.discord_id);
`,
  },
];

/** Applies any pending migrations. Safe to call on every start. Returns number applied. */
export function migrate(): number {
  db.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (
    version INTEGER PRIMARY KEY, name TEXT NOT NULL, applied_at TEXT NOT NULL)`);
  const done = new Set<number>(
    (db.prepare('SELECT version FROM schema_migrations').all() as any[]).map((r) => r.version),
  );
  let applied = 0;
  for (const m of MIGRATIONS) {
    if (done.has(m.version)) continue;
    db.transaction(() => {
      db.exec(m.sql);
      db.prepare('INSERT INTO schema_migrations(version,name,applied_at) VALUES (?,?,?)')
        .run(m.version, m.name, new Date().toISOString());
    })();
    log.info(`Applied migration ${m.version}: ${m.name}`);
    applied++;
  }
  return applied;
}

/** Seeds the tier ladder (always) and default gamemodes (first run only). */
export function seedDefaults(): void {
  const now = new Date().toISOString();
  db.transaction(() => {
    const insTier = db.prepare('INSERT OR IGNORE INTO tiers(name, rank_order, points) VALUES (?,?,?)');
    TIER_LADDER.forEach((t, i) => insTier.run(t, i + 1, TIER_POINTS[t]));

    const seeded = db.prepare("SELECT value FROM bot_config WHERE key='defaults_seeded'").get();
    if (!seeded) {
      const insGm = db.prepare(
        'INSERT OR IGNORE INTO gamemodes(name, emoji, active, sort_order, created_at) VALUES (?,?,1,?,?)');
      DEFAULT_GAMEMODES.forEach((g, i) => insGm.run(g.name, g.emoji, i + 1, now));
      db.prepare("INSERT INTO bot_config(key,value) VALUES ('defaults_seeded','1')").run();
      log.info('Seeded default gamemodes.');
    }
    db.prepare(`INSERT OR IGNORE INTO queues(gamemode_id, is_open, updated_at)
                SELECT id, 0, ? FROM gamemodes`).run(now);
  })();
}
