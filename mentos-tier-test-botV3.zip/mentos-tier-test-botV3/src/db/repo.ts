import { db } from './connection';
import { AppError } from '../errors';
import { DEFAULT_TIER, UNRANKED } from '../constants';

const now = () => new Date().toISOString();

export interface Gamemode { id: number; name: string; emoji: string; active: number; sort_order: number }
export interface Profile { discord_id: string; ign: string; username: string; created_at: string; updated_at: string }
export interface QueueEntry {
  id: number; gamemode_id: number; discord_id: string; position: number; status: string;
  joined_at: string; ign?: string; username?: string;
}
export type TicketStatus = 'waiting' | 'claimed' | 'in_progress' | 'completed' | 'cancelled';
export interface Ticket {
  id: number; channel_id: string; message_id: string | null; discord_id: string; gamemode_id: number;
  queue_entry_id: number | null; tester_id: string | null; status: TicketStatus; last_tier: string; queue_position: number | null;
  created_at: string; closed_at: string | null;
}
export const ACTIVE_STATUSES = ['waiting', 'claimed', 'in_progress'];
const ACTIVE_SQL = "('waiting','claimed','in_progress')";

/* ------------------------------ config ------------------------------ */
export function getConfig(key: string): string | undefined {
  const r = db.prepare('SELECT value FROM bot_config WHERE key=?').get(key) as any;
  return r?.value;
}
export function setConfig(key: string, value: string): void {
  db.prepare('INSERT INTO bot_config(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(key, value);
}
export function deleteConfig(key: string): void {
  db.prepare('DELETE FROM bot_config WHERE key=?').run(key);
}

/* ------------------------------ users / profiles ------------------------------ */
export function upsertUser(id: string, username: string): void {
  const t = now();
  db.prepare(`INSERT INTO users(discord_id, username, created_at, updated_at) VALUES (?,?,?,?)
    ON CONFLICT(discord_id) DO UPDATE SET username=excluded.username, updated_at=excluded.updated_at`).run(id, username, t, t);
}
export function getUsername(id: string): string | undefined {
  return (db.prepare('SELECT username FROM users WHERE discord_id=?').get(id) as any)?.username;
}

const PROFILE_SQL = `SELECT p.discord_id, p.ign, p.created_at, p.updated_at, u.username
  FROM profiles p JOIN users u ON u.discord_id = p.discord_id`;
export function getProfile(id: string): Profile | undefined {
  return db.prepare(`${PROFILE_SQL} WHERE p.discord_id=?`).get(id) as Profile | undefined;
}
export function getProfileByIgn(ign: string): Profile | undefined {
  return db.prepare(`${PROFILE_SQL} WHERE p.ign = ? COLLATE NOCASE`).get(ign) as Profile | undefined;
}
export function saveProfile(id: string, username: string, ign: string): { created: boolean } {
  return db.transaction(() => {
    upsertUser(id, username);
    const existing = getProfile(id);
    const taken = db.prepare('SELECT discord_id FROM profiles WHERE ign = ? COLLATE NOCASE AND discord_id <> ?').get(ign, id);
    if (taken) throw new AppError(`The IGN **${ign}** is already linked to another player.`);
    const t = now();
    if (existing) db.prepare('UPDATE profiles SET ign=?, updated_at=? WHERE discord_id=?').run(ign, t, id);
    else db.prepare('INSERT INTO profiles(discord_id, ign, created_at, updated_at) VALUES (?,?,?,?)').run(id, ign, t, t);
    return { created: !existing };
  })();
}
export function searchProfiles(q: string, limit = 10): { ign: string }[] {
  return db.prepare(`SELECT ign FROM profiles WHERE ign LIKE ? ESCAPE '\\' ORDER BY ign LIMIT ?`)
    .all(`%${q.replace(/[\\%_]/g, '\\$&')}%`, limit) as any[];
}

/* ------------------------------ tiers ------------------------------ */
export function getLastTiers(userId: string): Record<number, string> {
  const rows = db.prepare('SELECT gamemode_id, tier FROM profile_last_tiers WHERE discord_id=?').all(userId) as any[];
  return Object.fromEntries(rows.map((r) => [r.gamemode_id, r.tier]));
}
export function getLastTier(userId: string, gmId: number): string {
  const r = db.prepare('SELECT tier FROM profile_last_tiers WHERE discord_id=? AND gamemode_id=?').get(userId, gmId) as any;
  return r?.tier ?? UNRANKED;
}
export function setLastTier(userId: string, gmId: number, tier: string): void {
  db.prepare(`INSERT INTO profile_last_tiers(discord_id, gamemode_id, tier, updated_at) VALUES (?,?,?,?)
    ON CONFLICT(discord_id, gamemode_id) DO UPDATE SET tier=excluded.tier, updated_at=excluded.updated_at`)
    .run(userId, gmId, tier, now());
}
export function getPlayerTiers(userId: string): Record<number, string> {
  const rows = db.prepare('SELECT gamemode_id, tier FROM player_tiers WHERE discord_id=?').all(userId) as any[];
  return Object.fromEntries(rows.map((r) => [r.gamemode_id, r.tier]));
}
export function getPlayerTier(userId: string, gmId: number): string | null {
  const r = db.prepare('SELECT tier FROM player_tiers WHERE discord_id=? AND gamemode_id=?').get(userId, gmId) as any;
  return r?.tier ?? null;
}
/** The tier a tester must give as "oldrank": the official tier if one exists, otherwise the default (HT1). */
export function getExpectedOldTier(userId: string, gmId: number): string {
  return getPlayerTier(userId, gmId) ?? DEFAULT_TIER;
}

/* ------------------------------ gamemodes ------------------------------ */
export function listGamemodes(activeOnly = true): Gamemode[] {
  return db.prepare(`SELECT * FROM gamemodes ${activeOnly ? 'WHERE active=1' : ''} ORDER BY sort_order, id`).all() as Gamemode[];
}
export function findGamemode(name: string): Gamemode | undefined {
  return db.prepare('SELECT * FROM gamemodes WHERE name = ? COLLATE NOCASE').get(name) as Gamemode | undefined;
}
export function getGamemode(id: number): Gamemode | undefined {
  return db.prepare('SELECT * FROM gamemodes WHERE id=?').get(id) as Gamemode | undefined;
}
export function addGamemode(name: string, emoji: string): { gamemode: Gamemode; status: 'created' | 'reactivated' | 'exists' } {
  return db.transaction(() => {
    const existing = findGamemode(name);
    if (existing) {
      if (existing.active) return { gamemode: existing, status: 'exists' as const };
      db.prepare('UPDATE gamemodes SET active=1, emoji=? WHERE id=?').run(emoji, existing.id);
      return { gamemode: getGamemode(existing.id)!, status: 'reactivated' as const };
    }
    const max = (db.prepare('SELECT COALESCE(MAX(sort_order),0) m FROM gamemodes').get() as any).m;
    const info = db.prepare('INSERT INTO gamemodes(name, emoji, active, sort_order, created_at) VALUES (?,?,1,?,?)')
      .run(name, emoji, max + 1, now());
    db.prepare('INSERT OR IGNORE INTO queues(gamemode_id,is_open,updated_at) VALUES (?,0,?)').run(info.lastInsertRowid, now());
    return { gamemode: getGamemode(Number(info.lastInsertRowid))!, status: 'created' as const };
  })();
}
/** Soft-remove: history, results and role mappings are preserved. Waiting queue entries are cancelled. */
export function deactivateGamemode(id: number): number {
  return db.transaction(() => {
    db.prepare('UPDATE gamemodes SET active=0 WHERE id=?').run(id);
    db.prepare('UPDATE queues SET is_open=0, updated_at=? WHERE gamemode_id=?').run(now(), id);
    const r = db.prepare("UPDATE queue_entries SET status='cancelled', updated_at=? WHERE gamemode_id=? AND status='waiting'").run(now(), id);
    return r.changes;
  })();
}

/* ------------------------------ role mappings ------------------------------ */
export interface RoleMapping { id: number; kind: string; gamemode_id: number; tier: string; role_id: string }
export function getRoleMapping(kind: 'tier' | 'tester', gmId: number, tier = ''): RoleMapping | undefined {
  return db.prepare('SELECT * FROM role_mappings WHERE kind=? AND gamemode_id=? AND tier=?').get(kind, gmId, tier) as RoleMapping | undefined;
}
export function setRoleMapping(kind: 'tier' | 'tester', gmId: number, tier: string, roleId: string): void {
  db.prepare(`INSERT INTO role_mappings(kind, gamemode_id, tier, role_id) VALUES (?,?,?,?)
    ON CONFLICT(kind, gamemode_id, tier) DO UPDATE SET role_id=excluded.role_id`).run(kind, gmId, tier, roleId);
}
export function listRoleMappings(kind: 'tier' | 'tester', gmId: number): RoleMapping[] {
  return db.prepare('SELECT * FROM role_mappings WHERE kind=? AND gamemode_id=?').all(kind, gmId) as RoleMapping[];
}
export function listAllRoleMappings(kind: 'tier' | 'tester'): RoleMapping[] {
  return db.prepare('SELECT * FROM role_mappings WHERE kind=?').all(kind) as RoleMapping[];
}
export function deleteRoleMappingByRole(roleId: string): number {
  return db.prepare('DELETE FROM role_mappings WHERE role_id=?').run(roleId).changes;
}
export function deleteRoleMappings(kind: 'tier' | 'tester', gmId: number): void {
  db.prepare('DELETE FROM role_mappings WHERE kind=? AND gamemode_id=?').run(kind, gmId);
}

/* ------------------------------ testers / permissions ------------------------------ */
export function isTesterDb(userId: string, gmId: number): boolean {
  return !!db.prepare('SELECT 1 FROM tester_assignments WHERE discord_id=? AND gamemode_id=?').get(userId, gmId);
}
export function addTester(userId: string, gmId: number, by: string): void {
  db.prepare('INSERT OR IGNORE INTO tester_assignments(discord_id, gamemode_id, assigned_by, created_at) VALUES (?,?,?,?)')
    .run(userId, gmId, by, now());
}
export function removeTester(userId: string, gmId: number): void {
  db.prepare('DELETE FROM tester_assignments WHERE discord_id=? AND gamemode_id=?').run(userId, gmId);
}
export function listTesters(gmId: number): { discord_id: string; created_at: string }[] {
  return db.prepare('SELECT discord_id, created_at FROM tester_assignments WHERE gamemode_id=? ORDER BY created_at').all(gmId) as any[];
}
export function hasPermission(userId: string, permission: string): boolean {
  return !!db.prepare('SELECT 1 FROM permissions WHERE discord_id=? AND permission=?').get(userId, permission);
}
export function grantPermission(userId: string, permission: string, by: string): boolean {
  return db.prepare('INSERT OR IGNORE INTO permissions(discord_id, permission, granted_by, created_at) VALUES (?,?,?,?)')
    .run(userId, permission, by, now()).changes > 0;
}
export function revokePermission(userId: string, permission: string): boolean {
  return db.prepare('DELETE FROM permissions WHERE discord_id=? AND permission=?').run(userId, permission).changes > 0;
}
export function listPermission(permission: string): { discord_id: string; granted_by: string; created_at: string }[] {
  return db.prepare('SELECT discord_id, granted_by, created_at FROM permissions WHERE permission=? ORDER BY created_at').all(permission) as any[];
}

/* ------------------------------ queues ------------------------------ */
export function ensureQueue(gmId: number): void {
  db.prepare('INSERT OR IGNORE INTO queues(gamemode_id,is_open,updated_at) VALUES (?,0,?)').run(gmId, now());
}
export function isQueueOpen(gmId: number): boolean {
  const r = db.prepare('SELECT is_open FROM queues WHERE gamemode_id=?').get(gmId) as any;
  return !!r?.is_open;
}
export function setQueueOpen(gmId: number, open: boolean, by: string): void {
  ensureQueue(gmId);
  db.prepare('UPDATE queues SET is_open=?, updated_by=?, updated_at=? WHERE gamemode_id=?').run(open ? 1 : 0, by, now(), gmId);
}
export function listWaiting(gmId: number): QueueEntry[] {
  return db.prepare(`SELECT q.*, p.ign, u.username FROM queue_entries q
    LEFT JOIN profiles p ON p.discord_id=q.discord_id
    LEFT JOIN users u ON u.discord_id=q.discord_id
    WHERE q.gamemode_id=? AND q.status='waiting' ORDER BY q.position, q.id`).all(gmId) as QueueEntry[];
}
export function getWaitingEntry(gmId: number, userId: string): QueueEntry | undefined {
  return db.prepare("SELECT * FROM queue_entries WHERE gamemode_id=? AND discord_id=? AND status='waiting'").get(gmId, userId) as QueueEntry | undefined;
}
export function getWaitingEntriesForUser(userId: string): QueueEntry[] {
  return db.prepare("SELECT * FROM queue_entries WHERE discord_id=? AND status='waiting'").all(userId) as QueueEntry[];
}
export function addQueueEntry(gmId: number, userId: string): QueueEntry {
  return db.transaction(() => {
    const c = (db.prepare("SELECT COUNT(*) c FROM queue_entries WHERE gamemode_id=? AND status='waiting'").get(gmId) as any).c;
    const t = now();
    const info = db.prepare(`INSERT INTO queue_entries(gamemode_id, discord_id, position, status, joined_at, updated_at)
      VALUES (?,?,?,'waiting',?,?)`).run(gmId, userId, c + 1, t, t);
    return db.prepare('SELECT * FROM queue_entries WHERE id=?').get(info.lastInsertRowid) as QueueEntry;
  })();
}
export function renumberQueue(gmId: number): void {
  const rows = db.prepare("SELECT id FROM queue_entries WHERE gamemode_id=? AND status='waiting' ORDER BY joined_at, id").all(gmId) as any[];
  const up = db.prepare('UPDATE queue_entries SET position=? WHERE id=?');
  db.transaction(() => rows.forEach((r, i) => up.run(i + 1, r.id)))();
}
export function setEntryStatus(entryId: number, status: 'waiting' | 'ticketed' | 'left' | 'cancelled' | 'completed'): void {
  const e = db.prepare('SELECT gamemode_id FROM queue_entries WHERE id=?').get(entryId) as any;
  if (!e) return;
  db.prepare('UPDATE queue_entries SET status=?, updated_at=? WHERE id=?').run(status, now(), entryId);
  renumberQueue(e.gamemode_id);
}

/* ------------------------------ tickets / tests ------------------------------ */
export function createTicketRow(p: {
  channelId: string; userId: string; gamemodeId: number; entryId: number; lastTier: string;
}): Ticket {
  const info = db.prepare(`INSERT INTO test_tickets(channel_id, discord_id, gamemode_id, queue_entry_id, status, last_tier, created_at)
    VALUES (?,?,?,?, 'waiting', ?, ?)`).run(p.channelId, p.userId, p.gamemodeId, p.entryId, p.lastTier, now());
  return getTicket(Number(info.lastInsertRowid))!;
}
export function getTicket(id: number): Ticket | undefined {
  return db.prepare('SELECT * FROM test_tickets WHERE id=?').get(id) as Ticket | undefined;
}
export function getTicketByChannel(channelId: string): Ticket | undefined {
  return db.prepare('SELECT * FROM test_tickets WHERE channel_id=?').get(channelId) as Ticket | undefined;
}
export function getActiveTicketForUser(userId: string): Ticket | undefined {
  return db.prepare(`SELECT * FROM test_tickets WHERE discord_id=? AND status IN ${ACTIVE_SQL}`).get(userId) as Ticket | undefined;
}
export function getActiveTicketForGamemode(gmId: number): Ticket | undefined {
  return db.prepare(`SELECT * FROM test_tickets WHERE gamemode_id=? AND status IN ${ACTIVE_SQL} ORDER BY id LIMIT 1`).get(gmId) as Ticket | undefined;
}
export function listActiveTickets(gmId?: number): Ticket[] {
  return (gmId
    ? db.prepare(`SELECT * FROM test_tickets WHERE gamemode_id=? AND status IN ${ACTIVE_SQL}`).all(gmId)
    : db.prepare(`SELECT * FROM test_tickets WHERE status IN ${ACTIVE_SQL}`).all()) as Ticket[];
}
export function listRecentlyClosedTickets(sinceIso: string): Ticket[] {
  return db.prepare("SELECT * FROM test_tickets WHERE status IN ('completed','cancelled') AND closed_at >= ?").all(sinceIso) as Ticket[];
}
export function updateTicket(id: number, fields: Partial<Pick<Ticket, 'message_id' | 'tester_id' | 'status' | 'last_tier'>>): void {
  const keys = Object.keys(fields).filter((k) => ['message_id', 'tester_id', 'status', 'last_tier'].includes(k));
  if (!keys.length) return;
  db.prepare(`UPDATE test_tickets SET ${keys.map((k) => `${k}=?`).join(', ')} WHERE id=?`)
    .run(...keys.map((k) => (fields as any)[k]), id);
}
export function startTest(ticketId: number, userId: string, gmId: number, testerId: string): void {
  db.transaction(() => {
    db.prepare(`INSERT INTO tests(ticket_id, discord_id, gamemode_id, tester_id, started_at) VALUES (?,?,?,?,?)
      ON CONFLICT(ticket_id) DO NOTHING`).run(ticketId, userId, gmId, testerId, now());
    db.prepare("UPDATE test_tickets SET status='in_progress' WHERE id=?").run(ticketId);
  })();
}
export function cancelTicketDb(ticketId: number): void {
  db.transaction(() => {
    const t = now();
    const tk = getTicket(ticketId);
    if (!tk) return;
    db.prepare("UPDATE test_tickets SET status='cancelled', closed_at=? WHERE id=?").run(t, ticketId);
    db.prepare("UPDATE tests SET ended_at=?, outcome='cancelled' WHERE ticket_id=?").run(t, ticketId);
    if (tk.queue_entry_id) db.prepare("UPDATE queue_entries SET status='cancelled', updated_at=? WHERE id=?").run(t, tk.queue_entry_id);
  })();
}

/** Atomically records a result, updates the player's tier for that gamemode and completes the ticket/test/queue entry. */
export function applyResult(p: {
  ticketId: number | null; userId: string; gamemodeId: number; oldTier: string; newTier: string;
  testerId: string; isHigh: boolean; ign: string; correctsId?: number | null; reason?: string | null;
}): number {
  return db.transaction(() => {
    const t = now();
    const info = db.prepare(`INSERT INTO test_results(ticket_id, discord_id, gamemode_id, old_tier, new_tier, tester_id, is_high, created_at,
        ign, role_status, corrects_result_id, reason) VALUES (?,?,?,?,?,?,?,?,?, 'pending', ?, ?)`)
      .run(p.ticketId, p.userId, p.gamemodeId, p.oldTier, p.newTier, p.testerId, p.isHigh ? 1 : 0, t, p.ign, p.correctsId ?? null, p.reason ?? null);
    db.prepare(`INSERT INTO player_tiers(discord_id, gamemode_id, tier, updated_at) VALUES (?,?,?,?)
      ON CONFLICT(discord_id, gamemode_id) DO UPDATE SET tier=excluded.tier, updated_at=excluded.updated_at`)
      .run(p.userId, p.gamemodeId, p.newTier, t);
    if (p.ticketId) {
      db.prepare("UPDATE test_tickets SET status='completed', closed_at=?, tester_id=COALESCE(tester_id, ?) WHERE id=?")
        .run(t, p.testerId, p.ticketId);
      db.prepare(`INSERT INTO tests(ticket_id, discord_id, gamemode_id, tester_id, started_at, ended_at, outcome)
        VALUES (?,?,?,?,?,?, 'completed')
        ON CONFLICT(ticket_id) DO UPDATE SET ended_at=excluded.ended_at, outcome='completed'`)
        .run(p.ticketId, p.userId, p.gamemodeId, p.testerId, t, t);
      db.prepare(`UPDATE queue_entries SET status='completed', updated_at=?
        WHERE id=(SELECT queue_entry_id FROM test_tickets WHERE id=?)`).run(t, p.ticketId);
    }
    return Number(info.lastInsertRowid);
  })();
}

/* ------------------------------ result follow-up: roles, announcements (v3) ------------------------------ */
export function getResultFull(id: number): any | undefined {
  return db.prepare(`SELECT r.*, g.name AS gamemode, g.emoji AS emoji, COALESCE(r.ign, p.ign) AS ign_display, tu.username AS tester_name
    FROM test_results r JOIN gamemodes g ON g.id=r.gamemode_id
    LEFT JOIN profiles p ON p.discord_id=r.discord_id LEFT JOIN users tu ON tu.discord_id=r.tester_id WHERE r.id=?`).get(id);
}
export function getLatestResult(userId: string, gmId: number): any | undefined {
  return db.prepare('SELECT * FROM test_results WHERE discord_id=? AND gamemode_id=? ORDER BY id DESC LIMIT 1').get(userId, gmId);
}
export function setResultRoleStatus(id: number, status: 'pending' | 'ok' | 'failed', error?: string | null): void {
  db.prepare('UPDATE test_results SET role_status=?, role_error=? WHERE id=?').run(status, error ? error.slice(0, 500) : null, id);
}
/** Marks every failed role update of this player+gamemode as fixed (a later successful sync supersedes them). */
export function markRolesOk(userId: string, gmId: number): void {
  db.prepare("UPDATE test_results SET role_status='ok', role_error=NULL WHERE discord_id=? AND gamemode_id=? AND role_status IN ('failed','pending')").run(userId, gmId);
}
type AnnCol = 'result_message_id' | 'high_message_id';
const annCol = (c: AnnCol) => { if (c !== 'result_message_id' && c !== 'high_message_id') throw new Error('bad column'); return c; };
/** Atomic claim: only ONE caller can ever announce a given result in a given channel. */
export function claimAnnouncement(id: number, col: AnnCol): boolean {
  return db.prepare(`UPDATE test_results SET ${annCol(col)}='pending' WHERE id=? AND ${annCol(col)} IS NULL`).run(id).changes > 0;
}
export function finishAnnouncement(id: number, col: AnnCol, messageId: string): void {
  db.prepare(`UPDATE test_results SET ${annCol(col)}=? WHERE id=?`).run(messageId, id);
}
export function releaseAnnouncement(id: number, col: AnnCol): void {
  db.prepare(`UPDATE test_results SET ${annCol(col)}=NULL WHERE id=? AND ${annCol(col)}='pending'`).run(id);
}
export function resetPendingAnnouncements(): void {
  db.prepare("UPDATE test_results SET result_message_id=NULL WHERE result_message_id='pending'").run();
  db.prepare("UPDATE test_results SET high_message_id=NULL WHERE high_message_id='pending'").run();
}
/** Results that still need a role retry or an announcement. */
export function listPendingResults(sinceIso: string, userId?: string): any[] {
  return db.prepare(`SELECT id, discord_id, gamemode_id, role_status, result_message_id, high_message_id, is_high FROM test_results
    WHERE created_at >= ? AND (role_status='failed' OR result_message_id IS NULL OR (is_high=1 AND high_message_id IS NULL))
    ${userId ? 'AND discord_id=?' : ''} ORDER BY id`).all(...(userId ? [sinceIso, userId] : [sinceIso]));
}
export function getHighMinTier(): string { return getConfig('high_min_tier') ?? 'HT3'; }
export function setHighMinTier(tier: string): void { setConfig('high_min_tier', tier); }

/** Latest recorded result per player for one gamemode (players who picked the gamemode but never tested have tier=null). */
export function getTierListRows(gmId: number): { ign: string; tier: string | null }[] {
  return db.prepare(`SELECT p.ign AS ign,
      (SELECT r.new_tier FROM test_results r WHERE r.discord_id=p.discord_id AND r.gamemode_id=? ORDER BY r.id DESC LIMIT 1) AS tier
    FROM profiles p
    WHERE p.discord_id IN (SELECT discord_id FROM profile_gamemodes WHERE gamemode_id=?)
       OR EXISTS (SELECT 1 FROM test_results r WHERE r.discord_id=p.discord_id AND r.gamemode_id=?)
    ORDER BY p.ign COLLATE NOCASE`).all(gmId, gmId, gmId) as any[];
}

/* ------------------------------ history / leaderboards ------------------------------ */
export function countResults(userId: string): number {
  return (db.prepare('SELECT COUNT(*) c FROM test_results WHERE discord_id=?').get(userId) as any).c;
}
export function listResults(opts: { userId?: string; gamemodeId?: number; limit?: number } = {}): any[] {
  const where: string[] = [];
  const args: any[] = [];
  if (opts.userId) { where.push('r.discord_id=?'); args.push(opts.userId); }
  if (opts.gamemodeId) { where.push('r.gamemode_id=?'); args.push(opts.gamemodeId); }
  args.push(opts.limit ?? 10);
  return db.prepare(`SELECT r.id, r.old_tier, r.new_tier, r.is_high, r.created_at, r.tester_id,
      g.name AS gamemode, g.emoji AS emoji, p.ign, tu.username AS tester
    FROM test_results r
    JOIN gamemodes g ON g.id=r.gamemode_id
    LEFT JOIN profiles p ON p.discord_id=r.discord_id
    LEFT JOIN users tu ON tu.discord_id=r.tester_id
    ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
    ORDER BY r.created_at DESC, r.id DESC LIMIT ?`).all(...args);
}
export function getTierList(gmId: number): { ign: string; tier: string; updated_at: string }[] {
  return db.prepare(`SELECT p.ign, pt.tier, pt.updated_at FROM player_tiers pt
    JOIN profiles p ON p.discord_id=pt.discord_id
    JOIN tiers t ON t.name=pt.tier
    WHERE pt.gamemode_id=? ORDER BY t.rank_order DESC, pt.updated_at ASC`).all(gmId) as any[];
}
export function getOverallLeaderboard(limit = 100): any[] {
  return db.prepare(`SELECT p.ign, SUM(t.points) AS points, COUNT(*) AS gamemodes
    FROM player_tiers pt
    JOIN tiers t ON t.name=pt.tier
    JOIN profiles p ON p.discord_id=pt.discord_id
    JOIN gamemodes g ON g.id=pt.gamemode_id AND g.active=1
    GROUP BY pt.discord_id ORDER BY points DESC, p.ign LIMIT ?`).all(limit);
}
export function getPublicPlayer(ign: string): any | null {
  const p = getProfileByIgn(ign);
  if (!p) return null;
  const tiers = db.prepare(`SELECT g.id, g.name, g.emoji, pt.tier AS current_tier,
      'Not Tested' AS last_tier
    FROM gamemodes g
    LEFT JOIN player_tiers pt ON pt.gamemode_id=g.id AND pt.discord_id=?
    LEFT JOIN profile_last_tiers pl ON pl.gamemode_id=g.id AND pl.discord_id=?
    WHERE g.active=1 ORDER BY g.sort_order, g.id`).all(p.discord_id, p.discord_id);
  return {
    ign: p.ign,
    createdAt: p.created_at,
    updatedAt: p.updated_at,
    testsCompleted: countResults(p.discord_id),
    tiers,
    history: listResults({ userId: p.discord_id, limit: 50 }).map(({ tester_id, ...rest }) => rest),
  };
}
export function getStats(): any {
  const c = (sql: string) => (db.prepare(sql).get() as any).c as number;
  return {
    players: c('SELECT COUNT(*) c FROM profiles'),
    results: c('SELECT COUNT(*) c FROM test_results'),
    highResults: c('SELECT COUNT(*) c FROM test_results WHERE is_high=1'),
    activeTickets: c(`SELECT COUNT(*) c FROM test_tickets WHERE status IN ${ACTIVE_SQL}`),
    waiting: c("SELECT COUNT(*) c FROM queue_entries WHERE status='waiting'"),
    ranked: c('SELECT COUNT(DISTINCT discord_id) c FROM player_tiers'),
    perGamemode: db.prepare(`SELECT g.name, g.emoji,
        (SELECT COUNT(*) FROM test_results r WHERE r.gamemode_id=g.id) AS results,
        (SELECT COUNT(*) FROM player_tiers pt WHERE pt.gamemode_id=g.id) AS ranked
      FROM gamemodes g WHERE g.active=1 ORDER BY g.sort_order, g.id`).all(),
  };
}

/* ------------------------------ web sessions ------------------------------ */
export function createSession(id: string, userId: string, username: string, ttlMs: number): void {
  db.prepare('INSERT INTO web_sessions(id, discord_id, username, created_at, expires_at) VALUES (?,?,?,?,?)')
    .run(id, userId, username, now(), Date.now() + ttlMs);
}
export function getSession(id: string): { id: string; discord_id: string; username: string } | undefined {
  return db.prepare('SELECT id, discord_id, username FROM web_sessions WHERE id=? AND expires_at > ?').get(id, Date.now()) as any;
}
export function deleteSession(id: string): void {
  db.prepare('DELETE FROM web_sessions WHERE id=?').run(id);
}
export function purgeSessions(): void {
  db.prepare('DELETE FROM web_sessions WHERE expires_at <= ?').run(Date.now());
}

/* ------------------------------ profile gamemodes (v2) ------------------------------ */
export function getProfileGamemodeIds(userId: string): number[] {
  return (db.prepare(`SELECT pg.gamemode_id FROM profile_gamemodes pg JOIN gamemodes g ON g.id=pg.gamemode_id
    WHERE pg.discord_id=? ORDER BY g.sort_order, g.id`).all(userId) as any[]).map((r) => r.gamemode_id);
}
export function profileHasGamemode(userId: string, gmId: number): boolean {
  return !!db.prepare('SELECT 1 FROM profile_gamemodes WHERE discord_id=? AND gamemode_id=?').get(userId, gmId);
}
/** Saves IGN + gamemode selection atomically: either everything is stored or nothing is. */
export function saveProfileWithGamemodes(id: string, username: string, ign: string, gmIds: number[]): { created: boolean } {
  return db.transaction(() => {
    const r = saveProfile(id, username, ign);
    db.prepare('DELETE FROM profile_gamemodes WHERE discord_id=?').run(id);
    const ins = db.prepare('INSERT INTO profile_gamemodes(discord_id, gamemode_id, created_at) VALUES (?,?,?)');
    for (const g of new Set(gmIds)) ins.run(id, g, now());
    return r;
  })();
}

/* ------------------------------ /drag + claiming (v2) ------------------------------ */
export function getQueueEntry(id: number): QueueEntry | undefined {
  return db.prepare('SELECT * FROM queue_entries WHERE id=?').get(id) as QueueEntry | undefined;
}
/**
 * Records the ticket for a queue entry and removes the entry from the queue in ONE transaction.
 * Only called AFTER the Discord channel was created successfully. Throws if the entry was already
 * taken (another /drag won the race) so the caller can delete the channel it just made.
 */
export function recordDraggedTicket(p: {
  entryId: number; channelId: string; userId: string; gamemodeId: number; testerId: string | null; lastTier: string;
}): Ticket {
  return db.transaction(() => {
    const e = db.prepare('SELECT * FROM queue_entries WHERE id=?').get(p.entryId) as QueueEntry | undefined;
    if (!e || e.status !== 'waiting') throw new AppError('That player was already taken from the queue by someone else.');
    const t = now();
    const info = db.prepare(`INSERT INTO test_tickets(channel_id, discord_id, gamemode_id, queue_entry_id, tester_id, status, last_tier, queue_position, created_at)
      VALUES (?,?,?,?,?,?,?,?,?)`).run(p.channelId, p.userId, p.gamemodeId, p.entryId, p.testerId,
      p.testerId ? 'claimed' : 'waiting', p.lastTier, e.position, t);
    db.prepare("UPDATE queue_entries SET status='ticketed', updated_at=? WHERE id=?").run(t, p.entryId);
    renumberQueue(p.gamemodeId);
    return getTicket(Number(info.lastInsertRowid))!;
  })();
}
/** Atomic claim. Normal claim only succeeds on an unassigned ticket; `override` (admins) can reassign. */
export function claimTicket(id: number, testerId: string, override: boolean): boolean {
  const sql = override
    ? "UPDATE test_tickets SET tester_id=?, status=CASE WHEN status='waiting' THEN 'claimed' ELSE status END WHERE id=? AND status IN ('waiting','claimed','in_progress')"
    : "UPDATE test_tickets SET tester_id=?, status='claimed' WHERE id=? AND tester_id IS NULL AND status='waiting'";
  return db.prepare(sql).run(testerId, id).changes > 0;
}
export function clearQueue(gmId: number): number {
  const n = db.prepare("UPDATE queue_entries SET status='cancelled', updated_at=? WHERE gamemode_id=? AND status='waiting'").run(now(), gmId).changes;
  return n;
}

/** Removes every config key whose value equals `value` (used when a channel/role/message is deleted). Returns the keys removed. */
export function deleteConfigByValue(value: string): string[] {
  const keys = (db.prepare('SELECT key FROM bot_config WHERE value=?').all(value) as any[]).map((r) => r.key as string);
  for (const k of keys) deleteConfig(k);
  return keys;
}

/** Undo of recordDraggedTicket when the ticket message could not be posted: player keeps their original place. */
export function revertDraggedTicket(ticketId: number, entryId: number): void {
  db.transaction(() => {
    const t = getTicket(ticketId);
    db.prepare('DELETE FROM test_tickets WHERE id=?').run(ticketId);
    db.prepare("UPDATE queue_entries SET status='waiting', updated_at=? WHERE id=?").run(now(), entryId);
    if (t) renumberQueue(t.gamemode_id);
  })();
}
