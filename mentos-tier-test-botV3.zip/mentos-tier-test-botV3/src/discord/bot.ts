import { Client, Events, GatewayIntentBits, Guild, GuildMember } from 'discord.js';
import * as repo from '../db/repo';
import { assertBotConfig, config } from '../config';
import { COLORS } from '../constants';
import { appEvents } from '../events';
import { log } from '../logger';
import { commandMap } from './commands';
import { routeComponent } from './components';
import { handleInteractionError } from './util';
import { registerCommands } from '../register';
import { logEvent } from '../services/logs';
import { syncTesterAssignments } from '../services/permissions';
import { cancelTicket, handleMemberLeft, scheduleChannelDeletion } from '../services/queue';
import { publishProfilePanel, refreshQueuePanel } from './panel';
import { retryPending } from '../services/results';

let client: Client;
export const getClient = () => client;

async function reconcile(guild: Guild) {
  // 1. Active tickets whose channel disappeared while the bot was offline
  for (const t of repo.listActiveTickets()) {
    const ch = await guild.channels.fetch(t.channel_id).catch(() => null);
    if (!ch) await cancelTicket(guild, t, undefined, 'Ticket channel no longer exists.', false);
  }
  // 2. Finished tickets whose channel is still around (bot restarted before the delayed delete)
  const since = new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString();
  for (const t of repo.listRecentlyClosedTickets(since)) {
    if (guild.channels.cache.has(t.channel_id)) scheduleChannelDeletion(guild, t.channel_id, 5);
  }
  // 3. Tester role <-> database sync
  try {
    const members = await guild.members.fetch();
    members.forEach((m) => syncTesterAssignments(m));
  } catch (e: any) { log.warn('Could not sync tester roles at startup (enable the Server Members intent):', e?.message); }
  // 3b. Finish anything a crash/permission problem left behind: failed role updates, missing announcements
  repo.resetPendingAnnouncements();
  await retryPending(guild).then((r) => { if (r.rolesFixed || r.announced) log.info(`Retry: ${r.rolesFixed} role(s) fixed, ${r.announced} announcement(s) posted.`); }).catch((e) => log.warn('retryPending failed:', e?.message));
  // 4. Re-sync every panel with the database (re-creates panels whose message was deleted while offline)
  await publishProfilePanel(guild, true).catch(() => undefined);
  for (const gm of repo.listGamemodes(true)) await refreshQueuePanel(guild, gm.id, true).catch(() => undefined);
}

export async function startBot(): Promise<Client> {
  assertBotConfig();
  client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildMessages] });

  client.once(Events.ClientReady, async (c) => {
    log.info(`Logged in as ${c.user.tag}`);
    try {
      if (config.autoRegister) log.info(`Registered ${await registerCommands()} slash commands.`);
      const guild = await c.guilds.fetch(config.guildId);
      await guild.channels.fetch();
      await guild.roles.fetch();
      await reconcile(guild);
      log.info('Startup reconciliation finished.');
    } catch (e: any) { log.error('Startup failed:', e?.message ?? e); }
  });

  client.on(Events.InteractionCreate, async (i: any) => {
    try {
      if (i.guildId !== config.guildId) return;
      if (i.isChatInputCommand()) {
        const cmd = commandMap.get(i.commandName);
        if (cmd) await cmd.execute(i);
      } else if (i.isAutocomplete()) {
        await commandMap.get(i.commandName)?.autocomplete?.(i);
      } else if (i.isMessageComponent() || i.isModalSubmit()) {
        await routeComponent(i);
      }
    } catch (e) {
      await handleInteractionError(i, e);
    }
  });

  // Keep DB tester assignments in sync when roles are changed by hand in Discord
  client.on(Events.GuildMemberUpdate, (_o, m: GuildMember) => {
    if (m.guild.id === config.guildId) { try { syncTesterAssignments(m); } catch (e: any) { log.warn(e?.message); } }
  });
  client.on(Events.GuildMemberRemove, async (m) => {
    if (m.guild.id !== config.guildId) return;
    await handleMemberLeft(m.guild, m.id).catch((e) => log.error('handleMemberLeft:', e?.message));
  });
  client.on(Events.GuildRoleDelete, async (role) => {
    if (role.guild.id !== config.guildId) return;
    const removed = repo.deleteConfigByValue(role.id).length + repo.deleteRoleMappingByRole(role.id);
    if (removed) {
      await logEvent(role.guild, { title: '⚠️ Mapped role deleted', color: COLORS.warn, description: `Role **${role.name}** was deleted in Discord. Re-run the role-create command to recreate it.` });
    }
  });
  client.on(Events.ChannelDelete, async (ch: any) => {
    if (ch.guildId !== config.guildId) return;
    try {
      const t = repo.getTicketByChannel(ch.id);
      if (t && repo.ACTIVE_STATUSES.includes(t.status)) await cancelTicket(ch.guild, t, undefined, 'The ticket channel was deleted.', false);
      for (const key of repo.deleteConfigByValue(ch.id)) {
        if (key.startsWith('gm_channel:')) repo.deleteConfig(`gm_panel:${key.split(':')[1]}`);
        if (key === 'profile_channel') repo.deleteConfig('profile_panel');
      }
    } catch (e: any) { log.error('ChannelDelete handler:', e?.message); }
  });
  // A panel message was deleted by someone: put it back
  client.on(Events.MessageDelete, async (msg) => {
    if (msg.guildId !== config.guildId) return;
    try {
      const guild = client.guilds.cache.get(config.guildId)!;
      if (repo.getConfig('profile_panel') === msg.id) { repo.deleteConfig('profile_panel'); await publishProfilePanel(guild, true); return; }
      for (const gm of repo.listGamemodes(true)) {
        if (repo.getConfig(`gm_panel:${gm.id}`) === msg.id) { repo.deleteConfig(`gm_panel:${gm.id}`); await refreshQueuePanel(guild, gm.id, true); return; }
      }
    } catch (e: any) { log.warn('MessageDelete handler:', e?.message); }
  });
  client.on(Events.Error, (e) => log.error('Discord client error:', e.message));

  // Profile changes from Discord AND the website are logged here
  appEvents.on('profile', async (e: any) => {
    const guild = client.guilds.cache.get(config.guildId);
    const names = (ids?: number[]) => (ids ?? []).map((id) => repo.getGamemode(id)?.name).filter(Boolean).join(', ') || '—';
    await logEvent(guild, {
      title: e.created ? '👤 Profile created' : '👤 Profile updated', player: e.userId,
      description: `IGN: **${e.ign}**${e.oldIgn && e.oldIgn !== e.ign ? ` (was ${e.oldIgn})` : ''} • Source: ${e.source}${e.gamemodeIds ? `\nGamemodes: ${names(e.gamemodeIds)}` : ''}`,
    });
  });

  await client.login(config.token);
  return client;
}

export async function stopBot() { try { await client?.destroy(); } catch { /* ignore */ } }
