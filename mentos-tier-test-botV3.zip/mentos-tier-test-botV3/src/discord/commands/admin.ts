import {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, SlashCommandBuilder,
} from 'discord.js';
import * as repo from '../../db/repo';
import { config } from '../../config';
import { AppError } from '../../errors';
import { COLORS, TIER_LADDER } from '../../constants';
import { Command, adminOnly, gmAutocomplete, gmOption } from './shared';
import { begin } from '../util';
import { base, failure, notice, success, warning } from '../embeds';
import { getWebUrl, isLinkable, publishProfilePanel, refreshQueuePanel } from '../panel';
import { SetupReport, setupGamemode, setupTierTesting } from '../../services/guildSetup';
import { resolveGamemode, validateEmoji, validateGamemodeName } from '../../services/gamemodes';
import { createTesterRole, createTierRoles, deleteTierRoles, ensureRole, findTierRoles, RoleOutcome } from '../../services/roles';
import { logEvent } from '../../services/logs';
import { HIGH_RESULT } from '../../services/permissions';

const roleLines = (r: RoleOutcome[]) => r.map((x) =>
  x.error ? `❌ ${x.name} — Failed (${x.error})` : x.created ? `🆕 ${x.name} — Created` : `✅ ${x.name} — Already exists`).join('\n');

/* ---------------------------------------------------------------- setup */
const reportLines = (r: SetupReport) => r.items.map((it) =>
  it.status === 'exists' ? `✅ ${it.label} — Already exists`
    : it.status === 'created' ? `🆕 ${it.label} — Created`
      : it.status === 'updated' ? `🔄 ${it.label} — Updated`
        : `❌ ${it.label} — Failed${it.detail ? ` (${it.detail})` : ''}`);

/** Splits a long report into several embed fields (Discord limit: 1024 chars per field). */
function reportEmbeds(title: string, r: SetupReport) {
  const failed = r.items.filter((x) => x.status === 'failed').length;
  const created = r.items.filter((x) => x.status === 'created').length;
  const e = base(failed || r.problems.length ? COLORS.warn : COLORS.success, title);
  let chunk = '';
  let n = 1;
  for (const line of reportLines(r)) {
    if ((chunk + line).length > 950) { e.addFields({ name: n === 1 ? 'Result' : '\u200b', value: chunk }); chunk = ''; n++; }
    chunk += line + '\n';
  }
  if (chunk) e.addFields({ name: n === 1 ? 'Result' : '\u200b', value: chunk });
  if (r.problems.length) e.addFields({ name: '⚠️ Needs your attention', value: [...new Set(r.problems)].join('\n').slice(0, 1000) });
  e.setDescription(failed ? 'Some items failed — fix the problems below and run the command again.' : created ? `${created} item(s) created. No duplicates were created.` : 'Everything already exists. No duplicates were created.');
  return e;
}

const setup: Command = {
  data: adminOnly(new SlashCommandBuilder().setName('setup-tier-testing')
    .setDescription('Create categories, channels, gamemode roles and panels (safe to run repeatedly).')),
  async execute(i) {
    const { guild, member } = await begin(i, { admin: true });
    const r = await setupTierTesting(guild);
    await i.editReply({ embeds: [reportEmbeds('Tier Testing Setup', r)] });
    const created = r.items.filter((x) => x.status === 'created').length;
    await logEvent(guild, { title: '⚙️ Server setup run', user: member.id, description: `${created} created, ${r.items.filter((x) => x.status === 'failed').length} failed.` });
  },
};

const panelSetup: Command = {
  data: adminOnly(new SlashCommandBuilder().setName('panel-setup').setDescription('Refresh (or re-create if deleted) the profile panel and every queue panel.')),
  async execute(i) {
    const { guild, member } = await begin(i, { admin: true });
    const lines: string[] = [];
    const pr = await publishProfilePanel(guild, true);
    lines.push(`${pr === 'created' ? '🆕' : pr === 'updated' ? '🔄' : '❌'} Profile panel — ${pr === 'missing-channel' ? 'the #profile channel is missing (run /setup-tier-testing)' : pr}`);
    for (const gm of repo.listGamemodes(true)) {
      const r = await refreshQueuePanel(guild, gm.id, true);
      lines.push(`${r === 'created' ? '🆕' : r === 'updated' ? '🔄' : '❌'} ${gm.name} queue panel — ${r === 'missing-channel' ? 'channel missing (run /setup-tier-testing)' : r}`);
    }
    await i.editReply({ embeds: [notice('Panels', lines.join('\n') + '\n\nExisting panels are edited in place; nothing is duplicated.')] });
    await logEvent(guild, { title: '⚙️ Panels refreshed', user: member.id });
  },
};

/* ---------------------------------------------------------------- gamemodes */
const gamemodeAdd: Command = {
  data: adminOnly(new SlashCommandBuilder().setName('gamemode-add').setDescription('Add a gamemode (or re-activate a removed one).')
    .addStringOption((o) => o.setName('gamemode').setDescription('Gamemode name, e.g. Sword').setRequired(true).setMaxLength(24))
    .addStringOption((o) => o.setName('emoji').setDescription('Emoji shown in menus (optional)'))),
  async execute(i) {
    const { guild, member } = await begin(i, { admin: true });
    const name = validateGamemodeName(i.options.getString('gamemode', true));
    const emoji = validateEmoji(i.options.getString('emoji'));
    const r = repo.addGamemode(name, emoji);
    if (r.status === 'exists') throw new AppError(`**${r.gamemode.name}** already exists and is active.`);
    const setup = repo.getConfig('request_category') ? await setupGamemode(guild, r.gamemode) : { items: [], problems: [] };
    await i.editReply({ embeds: [success(`Gamemode ${r.status === 'created' ? 'added' : 're-activated'}`,
      `${r.gamemode.emoji} **${r.gamemode.name}** is now active.${setup.items.length ? '\n\n' + reportLines(setup).join('\n') : '\nRun `/setup-tier-testing` to create its channel, role and queue panel.'}\n\nNext: \`/tier-role-create ${r.gamemode.name}\`, \`/tester-role-create ${r.gamemode.name}\`, then \`/queue-open ${r.gamemode.name}\`.`),
      ...(setup.problems.length ? [base(COLORS.warn, '⚠️ Needs your attention', [...new Set(setup.problems)].join('\n'))] : [])] });
    await logEvent(guild, { title: '➕ Gamemode added', color: COLORS.success, user: member.id, gamemode: r.gamemode.name, description: r.status === 'reactivated' ? 'Re-activated a previously removed gamemode.' : undefined });
  },
};

const gamemodeRemove: Command = {
  data: adminOnly(gmOption(new SlashCommandBuilder().setName('gamemode-remove')
    .setDescription('Deactivate a gamemode. History is kept and roles are NOT deleted.'))),
  autocomplete: gmAutocomplete(false),
  async execute(i) {
    const { guild, member } = await begin(i, { admin: true });
    const gm = resolveGamemode(i.options.getString('gamemode', true));
    if (repo.listActiveTickets(gm.id).length) throw new AppError(`**${gm.name}** has active tests. Finish or close those tickets first.`);
    const cancelled = repo.deactivateGamemode(gm.id);
    await refreshQueuePanel(guild, gm.id, false);
    await i.editReply({ embeds: [success('Gamemode removed',
      `**${gm.name}** is no longer active (queue closed${cancelled ? `, ${cancelled} waiting player(s) removed` : ''}).\n` +
      `• Result history and player tiers were **kept**.\n• The gamemode channel, its role and Discord tier roles were **not** deleted. To delete the tier roles use \`/tier-role-delete ${gm.name}\`.\n` +
      `• Re-add it any time with \`/gamemode-add ${gm.name}\`.`)] });
    await logEvent(guild, { title: '➖ Gamemode removed', color: COLORS.warn, user: member.id, gamemode: gm.name, description: 'Roles were not deleted.' });
  },
};

const gamemodeList: Command = {
  data: new SlashCommandBuilder().setName('gamemode-list').setDescription('List the active gamemodes.').setDMPermission(false),
  async execute(i) {
    await begin(i);
    const gms = repo.listGamemodes(true);
    const lines = gms.map((g) => `${g.emoji} **${g.name}** — ${repo.isQueueOpen(g.id) ? '🟢 Queue open' : '🔴 Queue closed'}`);
    await i.editReply({ embeds: [notice('🎮 Active Gamemodes', lines.join('\n') || 'No active gamemodes. Admins can add one with `/gamemode-add`.')] });
  },
};

/* ---------------------------------------------------------------- tier roles */
const tierRoleCreate: Command = {
  data: adminOnly(gmOption(new SlashCommandBuilder().setName('tier-role-create').setDescription('Create the LT5…HT1 roles for a gamemode (only missing ones).'))),
  autocomplete: gmAutocomplete(false),
  async execute(i) {
    const { guild, member } = await begin(i, { admin: true });
    const gm = resolveGamemode(i.options.getString('gamemode', true));
    const res = await createTierRoles(guild, gm);
    const created = res.filter((r) => r.created).length;
    await i.editReply({ embeds: [base(res.some((r) => r.error) ? COLORS.warn : COLORS.success, `${gm.name} Tier Roles`,
      `${roleLines(res)}\n\n${created} created, ${res.filter((r) => !r.created && !r.error).length} already existed.`)] });
    await logEvent(guild, { title: '🏷️ Tier roles created', user: member.id, gamemode: gm.name, description: `${created} new role(s).` });
  },
};

const tierRoleDelete: Command = {
  data: adminOnly(gmOption(new SlashCommandBuilder().setName('tier-role-delete').setDescription('Delete all tier roles of a gamemode (asks for confirmation).'))),
  autocomplete: gmAutocomplete(true),
  async execute(i) {
    const { guild, member } = await begin(i, { admin: true });
    const gm = resolveGamemode(i.options.getString('gamemode', true), true);
    const existing = await findTierRoles(guild, gm);
    if (!existing.length) throw new AppError(`No **${gm.name}** tier roles exist.`);
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId('confirm:tierdel:yes').setLabel(`Delete ${existing.length} roles`).setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId('confirm:tierdel:no').setLabel('Cancel').setStyle(ButtonStyle.Secondary));
    const msg = await i.editReply({
      embeds: [warning('Confirm role deletion', `This will permanently delete **${existing.length}** role(s):\n${existing.map((r) => r.role.name).join(', ')}\n\nPlayers lose these roles. Their stored tiers in the database are kept.`)],
      components: [row],
    });
    try {
      const c = await msg.awaitMessageComponent({ componentType: ComponentType.Button, time: 60_000, filter: (x) => x.user.id === i.user.id });
      if (c.customId !== 'confirm:tierdel:yes') {
        await c.update({ embeds: [notice('Cancelled', 'No roles were deleted.')], components: [] });
        return;
      }
      await c.deferUpdate();
      const r = await deleteTierRoles(guild, gm);
      await i.editReply({ embeds: [base(r.failed.length ? COLORS.warn : COLORS.success, `${gm.name} Tier Roles Deleted`,
        `🗑️ Deleted: ${r.deleted.length}${r.failed.length ? `\n❌ Could not delete: ${r.failed.join(', ')}` : ''}`)], components: [] });
      await logEvent(guild, { title: '🗑️ Tier roles deleted', color: COLORS.warn, user: member.id, gamemode: gm.name, description: `${r.deleted.length} role(s) deleted.` });
    } catch {
      await i.editReply({ embeds: [notice('Timed out', 'No roles were deleted.')], components: [] });
    }
  },
};

/* ---------------------------------------------------------------- tester roles */
const testerRoleCreate: Command = {
  data: adminOnly(gmOption(new SlashCommandBuilder().setName('tester-role-create').setDescription('Create the "🧪 <Gamemode> Tester" role.'))),
  autocomplete: gmAutocomplete(false),
  async execute(i) {
    const { guild, member } = await begin(i, { admin: true });
    const gm = resolveGamemode(i.options.getString('gamemode', true));
    const r = await createTesterRole(guild, gm);
    await i.editReply({ embeds: [base(r.error ? COLORS.warn : COLORS.success, `${gm.name} Tester Role`, roleLines([r]))] });
    if (r.created) await logEvent(guild, { channel: 'tester', title: '🧪 Tester role created', user: member.id, gamemode: gm.name });
  },
};

const testerRoleCreateAll: Command = {
  data: adminOnly(new SlashCommandBuilder().setName('tester-role-create-all').setDescription('Create every missing Tester role (never duplicates).')),
  async execute(i) {
    const { guild, member } = await begin(i, { admin: true });
    const res: RoleOutcome[] = [];
    for (const gm of repo.listGamemodes(true)) res.push(await createTesterRole(guild, gm));
    const created = res.filter((r) => r.created).length;
    await i.editReply({ embeds: [base(res.some((r) => r.error) ? COLORS.warn : COLORS.success, 'Tester Roles', `${roleLines(res)}\n\n${created} created.`)] });
    await logEvent(guild, { channel: 'tester', title: '🧪 Tester roles created (all)', user: member.id, description: `${created} new role(s).` });
  },
};

const testerRoleAdd: Command = {
  data: adminOnly(gmOption(new SlashCommandBuilder().setName('tester-role-add').setDescription('Make a member a tester for a gamemode.'))
    .addUserOption((o: any) => o.setName('player').setDescription('The member').setRequired(true))),
  autocomplete: gmAutocomplete(false),
  async execute(i) {
    const { guild, member } = await begin(i, { admin: true });
    const gm = resolveGamemode(i.options.getString('gamemode', true));
    const user = i.options.getUser('player', true);
    if (user.bot) throw new AppError('Bots cannot be testers.');
    const target = await guild.members.fetch(user.id).catch(() => null);
    if (!target) throw new AppError('That user is not in this server.');
    const { role } = await ensureRole(guild, 'tester', gm);
    if (!target.roles.cache.has(role.id)) await target.roles.add(role, `Tester role added by ${member.user.tag}`);
    repo.upsertUser(user.id, user.username);
    repo.addTester(user.id, gm.id, member.id);
    await i.editReply({ embeds: [success('Tester added', `<@${user.id}> is now a **${gm.name}** tester (${role.name}).`)] });
    await logEvent(guild, { channel: 'tester', title: '🧪 Tester assigned', color: COLORS.success, user: member.id, player: user.id, gamemode: gm.name });
  },
};

const testerRoleRemove: Command = {
  data: adminOnly(gmOption(new SlashCommandBuilder().setName('tester-role-remove').setDescription('Remove a member as tester for a gamemode.'))
    .addUserOption((o: any) => o.setName('player').setDescription('The member').setRequired(true))),
  autocomplete: gmAutocomplete(true),
  async execute(i) {
    const { guild, member } = await begin(i, { admin: true });
    const gm = resolveGamemode(i.options.getString('gamemode', true), true);
    const user = i.options.getUser('player', true);
    const target = await guild.members.fetch(user.id).catch(() => null);
    const map = repo.getRoleMapping('tester', gm.id, '');
    const hasRole = !!(map && target?.roles.cache.has(map.role_id));
    if (!hasRole && !repo.isTesterDb(user.id, gm.id)) throw new AppError(`<@${user.id}> is not a **${gm.name}** tester.`);
    if (hasRole) await target!.roles.remove(map!.role_id, `Tester role removed by ${member.user.tag}`);
    repo.removeTester(user.id, gm.id);
    await i.editReply({ embeds: [success('Tester removed', `<@${user.id}> is no longer a **${gm.name}** tester.`)] });
    await logEvent(guild, { channel: 'tester', title: '🧪 Tester removed', color: COLORS.warn, user: member.id, player: user.id, gamemode: gm.name });
  },
};

const testerRoleList: Command = {
  data: adminOnly(gmOption(new SlashCommandBuilder().setName('tester-role-list').setDescription('List the testers of a gamemode.'))),
  autocomplete: gmAutocomplete(true),
  async execute(i) {
    const { guild } = await begin(i, { admin: true });
    const gm = resolveGamemode(i.options.getString('gamemode', true), true);
    const map = repo.getRoleMapping('tester', gm.id, '');
    const rows = repo.listTesters(gm.id);
    const lines: string[] = [];
    for (const r of rows) {
      const m = await guild.members.fetch(r.discord_id).catch(() => null);
      const synced = !!(m && map && m.roles.cache.has(map.role_id));
      lines.push(`<@${r.discord_id}>${synced ? '' : ' ⚠️ *Discord role missing — will resync when roles change*'}`);
    }
    await i.editReply({ embeds: [notice(`🧪 ${gm.name} Testers`, lines.join('\n') || 'No testers assigned.')
      .addFields({ name: 'Role', value: map ? `<@&${map.role_id}>` : 'Not created yet — use `/tester-role-create`.' })] });
  },
};

/* ---------------------------------------------------------------- high-result permission */
const highPerm: Command = {
  data: adminOnly(new SlashCommandBuilder().setName('high-result-permission').setDescription('Manage who may use /high-result.')
    .addSubcommand((s) => s.setName('add').setDescription('Grant the High Result permission')
      .addUserOption((o) => o.setName('player').setDescription('The member').setRequired(true)))
    .addSubcommand((s) => s.setName('remove').setDescription('Revoke the High Result permission')
      .addUserOption((o) => o.setName('player').setDescription('The member').setRequired(true)))
    .addSubcommand((s) => s.setName('list').setDescription('List members with the High Result permission'))),
  async execute(i) {
    const { guild, member } = await begin(i, { admin: true });
    const sub = i.options.getSubcommand();
    if (sub === 'list') {
      const rows = repo.listPermission(HIGH_RESULT);
      await i.editReply({ embeds: [notice('🔥 High Result Permission', rows.map((r) => `<@${r.discord_id}>`).join('\n') || 'Nobody has this permission yet.')] });
      return;
    }
    const user = i.options.getUser('player', true);
    if (sub === 'add') {
      if (user.bot) throw new AppError('Bots cannot hold this permission.');
      repo.upsertUser(user.id, user.username);
      if (!repo.grantPermission(user.id, HIGH_RESULT, member.id)) throw new AppError(`<@${user.id}> already has the High Result permission.`);
      await i.editReply({ embeds: [success('Permission granted', `<@${user.id}> can now use \`/high-result\`.`)] });
      await logEvent(guild, { channel: 'tester', title: '🔥 High-result permission granted', color: COLORS.high, user: member.id, player: user.id });
    } else {
      if (!repo.revokePermission(user.id, HIGH_RESULT)) throw new AppError(`<@${user.id}> does not have the High Result permission.`);
      await i.editReply({ embeds: [success('Permission revoked', `<@${user.id}> can no longer use \`/high-result\`.`)] });
      await logEvent(guild, { channel: 'tester', title: '🔥 High-result permission revoked', color: COLORS.warn, user: member.id, player: user.id });
    }
  },
};

const highCriteria: Command = {
  data: adminOnly(new SlashCommandBuilder().setName('high-result-criteria').setDescription('Show or set the minimum tier that counts as a HIGH result.')
    .addStringOption((o) => o.setName('minimum').setDescription('Minimum tier (omit to just show the current setting)')
      .addChoices(...[...TIER_LADDER].reverse().map((t) => ({ name: t, value: t })), { name: 'None (no tier counts as high)', value: 'none' }))),
  async execute(i) {
    const { guild, member } = await begin(i, { admin: true });
    const v = i.options.getString('minimum');
    if (v) {
      repo.setHighMinTier(v);
      await logEvent(guild, { title: '🔥 High-result criteria changed', color: COLORS.high, user: member.id, description: `Minimum tier is now **${v}**.` });
    }
    const cur = repo.getHighMinTier();
    await i.editReply({ embeds: [notice('🔥 High Result Criteria', cur === 'none' ? 'No tier counts as a high result automatically. Only `/high-result` creates high results.'
      : `Results of **${cur}** or higher are high results: they need the **High Result** permission and are also announced in **#high-result**.\nCurrent: ${[...TIER_LADDER].filter((t) => TIER_LADDER.indexOf(t) >= TIER_LADDER.indexOf(cur)).join(', ')}`)] });
  },
};

/* ---------------------------------------------------------------- web */
const webSetup: Command = {
  data: adminOnly(new SlashCommandBuilder().setName('web-setup').setDescription('Configure / check the results website and link it in the panel.')
    .addStringOption((o) => o.setName('url').setDescription('Public URL of the website, e.g. https://tiers.example.com'))),
  async execute(i) {
    const { guild, member } = await begin(i, { admin: true });
    const raw = i.options.getString('url');
    if (raw) {
      let u: URL;
      try { u = new URL(raw.trim()); } catch { throw new AppError('That is not a valid URL (include http:// or https://).'); }
      if (!/^https?:$/.test(u.protocol)) throw new AppError('The URL must start with http:// or https://');
      repo.setConfig('web_url', u.toString().replace(/\/+$/, ''));
    }
    const url = getWebUrl();
    let online = false;
    try {
      const r = await fetch(`http://127.0.0.1:${config.webPort}/api/health`, { signal: AbortSignal.timeout(3000) });
      online = r.ok;
    } catch { online = false; }
    const e = base(online ? COLORS.success : COLORS.warn, '🌐 Results Website',
      `**URL:** ${url}\n**Web server:** ${online ? '🟢 Running' : `🔴 Not reachable on port ${config.webPort} (start it with \`npm run start:web\` or \`npm start\`)`}\n` +
      `**Player login:** ${config.clientSecret ? '🟢 Discord OAuth configured' : '🔴 Set DISCORD_CLIENT_SECRET in .env to let players log in and edit profiles'}\n` +
      `**Link button:** ${isLinkable(url) ? 'shown below' : 'hidden (needs a public, non-localhost URL)'}`);
    const comps = isLinkable(url) ? [new ActionRowBuilder<ButtonBuilder>().addComponents(new ButtonBuilder().setLabel('Open website').setStyle(ButtonStyle.Link).setURL(url))] : [];
    await i.editReply({ embeds: [e], components: comps });
    await logEvent(guild, { title: '🌐 Web settings checked', user: member.id, description: `URL: ${url}` });
  },
};

export const adminCommands: Command[] = [
  setup, panelSetup, gamemodeAdd, gamemodeRemove, gamemodeList, tierRoleCreate, tierRoleDelete,
  testerRoleCreate, testerRoleCreateAll, testerRoleAdd, testerRoleRemove, testerRoleList, highPerm, highCriteria, webSetup,
];
void [failure, TIER_LADDER];
