import { Command } from './shared';
import { adminCommands } from './admin';
import { testerCommands } from './tester';
import { playerCommands } from './player';

export const commands: Command[] = [...adminCommands, ...testerCommands, ...playerCommands];
export const commandMap = new Map(commands.map((c) => [c.data.name, c]));
export const commandJson = () => commands.map((c) => c.data.toJSON());
