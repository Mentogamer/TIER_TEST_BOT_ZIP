import { SlashCommandBuilder } from 'discord.js';
import * as repo from '../../db/repo';
import { AppError } from '../../errors';
import { COLORS, TIER_LADDER, tierLabel } from '../../constants';
import { Command, gmAutocomplete } from './shared';
import { begin } from '../util';
import { base, fmtDate, notice, profileEmbed, success } from '../embeds';
import { ticketEmbed } from '../ticketUi';
import { resolveGamemode } from '../../services/gamemodes';
import { leaveQueue } from '../../services/queue';
import { startProfileFlow } from '../components';

const profile: Command = {
  data: new SlashCommandBuilder().setName('profile').setDescription('View a tier-testing profile.').setDMPermission(false)
    .addUserOption((o) => o.setName('player').setDescription('Another member (default: you)')),
  async execute(i) {
    await begin(i);
    const user = i.options.getUser('player') ?? i.user;
    const e = profileEmbed(user.id);
    if (!e) throw new AppError(user.id === i.user.id
      ? 'You have no profile yet. Use the panel in the #profile channel or `/profile-edit`.'
      : `<@${user.id}> has no profile.`);
    await i.editReply({ embeds: [e] });
  },
};

const profileEdit: Command = {
  data: new SlashCommandBuilder().setName('profile-edit').setDescription('Create or edit your IGN and gamemodes.').setDMPermission(false),
  async execute(i) { await startProfileFlow(i); },
};

const queueStatus: Command = {
  data: new SlashCommandBuilder().setName('queue-status').setDescription('Show every queue and your place in it.').setDMPermission(false),
  async execute(i) {
    await begin(i);
    const lines = repo.listGamemodes(true).map((g) => {
      const w = repo.listWaiting(g.id);
      const mine = w.find((x) => x.discord_id === i.user.id);
      const tk = repo.getActiveTicketForGamemode(g.id);
      return `${g.emoji} **${g.name}** — ${repo.isQueueOpen(g.id) ? '🟢 Open' : '🔴 Closed'} • ${w.length} waiting${tk ? ' • test in progress' : ''}${mine ? ` • **you: #${mine.position}**` : ''}`;
    });
    await i.editReply({ embeds: [notice('📋 Queue Status', lines.join('\n') || 'No active gamemodes.')] });
  },
};

const queueList: Command = {
  data: new SlashCommandBuilder().setName('queue-list').setDescription('List the players waiting in a gamemode queue.').setDMPermission(false)
    .addStringOption((o) => o.setName('gamemode').setDescription('The gamemode').setRequired(true).setAutocomplete(true)),
  autocomplete: gmAutocomplete(false),
  async execute(i) {
    await begin(i);
    const gm = resolveGamemode(i.options.getString('gamemode', true));
    const w = repo.listWaiting(gm.id);
    const tk = repo.getActiveTicketForGamemode(gm.id);
    const e = notice(`${gm.emoji} ${gm.name} Queue — ${repo.isQueueOpen(gm.id) ? '🟢 Open' : '🔴 Closed'}`,
      w.map((x) => `**${x.position}.** ${x.ign ?? x.username ?? x.discord_id} — <@${x.discord_id}>`).join('\n') || 'Nobody is waiting.');
    if (tk) e.addFields({ name: 'Now testing', value: `<@${tk.discord_id}> in <#${tk.channel_id}>` });
    await i.editReply({ embeds: [e] });
  },
};

const queueLeave: Command = {
  data: new SlashCommandBuilder().setName('queue-leave').setDescription('Leave a queue you are waiting in.').setDMPermission(false)
    .addStringOption((o) => o.setName('gamemode').setDescription('The gamemode').setRequired(true).setAutocomplete(true)),
  autocomplete: gmAutocomplete(false),
  async execute(i) {
    const { guild } = await begin(i);
    const gm = await leaveQueue(guild, i.user.id, resolveGamemode(i.options.getString('gamemode', true)).id);
    await i.editReply({ embeds: [success('Left the queue', `You left the **${gm.name}** queue.`)] });
  },
};

const testInfo: Command = {
  data: new SlashCommandBuilder().setName('test-info').setDescription('Show the active test ticket (this channel, a player, or yours).').setDMPermission(false)
    .addUserOption((o) => o.setName('player').setDescription('Player to look up')),
  async execute(i) {
    await begin(i);
    const user = i.options.getUser('player');
    const t = user ? repo.getActiveTicketForUser(user.id)
      : (repo.getTicketByChannel(i.channelId) ?? repo.getActiveTicketForUser(i.user.id));
    if (!t) throw new AppError('No active test ticket found.');
    await i.editReply({ embeds: [ticketEmbed(t).addFields({ name: 'Channel', value: `<#${t.channel_id}>`, inline: true })] });
  },
};

const history: Command = {
  data: new SlashCommandBuilder().setName('history').setDescription('Show recent test results.').setDMPermission(false)
    .addUserOption((o) => o.setName('player').setDescription('Player (default: you)'))
    .addStringOption((o) => o.setName('gamemode').setDescription('Filter by gamemode').setAutocomplete(true)),
  autocomplete: gmAutocomplete(true),
  async execute(i) {
    await begin(i);
    const user = i.options.getUser('player') ?? i.user;
    const gmName = i.options.getString('gamemode');
    const gm = gmName ? resolveGamemode(gmName, true) : undefined;
    const rows = repo.listResults({ userId: user.id, gamemodeId: gm?.id, limit: 10 });
    const e = base(COLORS.primary, `📜 Test History${gm ? ` — ${gm.name}` : ''}`,
      rows.map((r) => `${r.emoji} **${r.gamemode}** ${r.old_tier} → **${r.new_tier}**${r.is_high ? ' 🔥' : ''} • ${fmtDate(r.created_at)}${r.tester ? ` • ${r.tester}` : ''}`).join('\n')
      || 'No results yet.');
    e.setAuthor({ name: repo.getProfile(user.id)?.ign ?? user.username });
    await i.editReply({ embeds: [e] });
  },
};

const stats: Command = {
  data: new SlashCommandBuilder().setName('stats').setDescription('Tier-testing statistics.').setDMPermission(false),
  async execute(i) {
    await begin(i);
    const s = repo.getStats();
    const e = base(COLORS.primary, '📊 Tier Testing Stats').addFields(
      { name: 'Players', value: String(s.players), inline: true },
      { name: 'Ranked players', value: String(s.ranked), inline: true },
      { name: 'Tests completed', value: `${s.results} (${s.highResults} high)`, inline: true },
      { name: 'Active tickets', value: String(s.activeTickets), inline: true },
      { name: 'Waiting in queues', value: String(s.waiting), inline: true },
      { name: 'Per gamemode', value: s.perGamemode.map((g: any) => `${g.emoji} ${g.name}: ${g.results} tests • ${g.ranked} ranked`).join('\n') || '—' },
    );
    await i.editReply({ embeds: [e] });
  },
};

const help: Command = {
  data: new SlashCommandBuilder().setName('help').setDescription("How to use Mento's Tier Test Bot.").setDMPermission(false),
  async execute(i) {
    await begin(i);
    const e = base(COLORS.primary, "🏆 Mento's Tier Test Bot — Help")
      .addFields(
        { name: '👤 Players', value: '`/profile` `/profile-edit` `/queue-status` `/queue-list` `/queue-leave` `/test-info` `/history` `/stats`\nCreate your profile in **#profile**, then press **Join Queue** in a gamemode channel.' },
        { name: '🧪 Testers (their own gamemode only)', value: '`/queue-open` `/queue-close` `/queue-clear` `/drag <gamemode>` `/result <tier> <player> <gamemode>` `/result-retry` `/tier-list`\nClaim / start / complete from the buttons inside the ticket.' },
        { name: '🔥 High Result permission', value: '`/high-result <tier> <player> <gamemode>` · `/high-result-criteria` (admin) · `/result-correct` (admin)' },
        { name: '🛠️ Admins', value: '`/setup-tier-testing` `/panel-setup` `/gamemode-add|remove|list` `/tier-role-create|delete` `/tester-role-create|create-all|add|remove|list` `/high-result-permission` `/web-setup`' },
        { name: 'Tiers', value: [...TIER_LADDER].reverse().join(' › ') },
      );
    await i.editReply({ embeds: [e] });
  },
};

export const playerCommands: Command[] = [profile, profileEdit, queueStatus, queueList, queueLeave, testInfo, history, stats, help];
void [tierLabel];
