import { AutocompleteInteraction, ChatInputCommandInteraction, PermissionFlagsBits } from 'discord.js';
import * as repo from '../../db/repo';

export interface Command {
  data: { name: string; toJSON(): any };
  execute(i: ChatInputCommandInteraction): Promise<void>;
  autocomplete?(i: AutocompleteInteraction): Promise<void>;
}

export const adminOnly = (b: any) => b.setDefaultMemberPermissions(PermissionFlagsBits.Administrator).setDMPermission(false);
export const guildOnly = (b: any) => b.setDMPermission(false);

/** Adds the standard `gamemode` option (autocomplete from the database). */
export function gmOption(b: any, required = true, desc = 'The gamemode') {
  return b.addStringOption((o: any) => o.setName('gamemode').setDescription(desc).setRequired(required).setAutocomplete(true));
}

export const gmAutocomplete = (includeInactive = false) => async (i: AutocompleteInteraction) => {
  const q = String(i.options.getFocused()).toLowerCase();
  const list = repo.listGamemodes(!includeInactive)
    .filter((g) => g.name.toLowerCase().includes(q))
    .slice(0, 25)
    .map((g) => ({ name: `${g.name}${g.active ? '' : ' (removed)'}`, value: g.name }));
  await i.respond(list).catch(() => {});
};
