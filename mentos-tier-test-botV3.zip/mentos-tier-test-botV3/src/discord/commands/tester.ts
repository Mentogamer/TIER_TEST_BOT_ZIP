import { PermissionFlagsBits, SlashCommandBuilder } from 'discord.js';
import * as repo from '../../db/repo';
import { AppError } from '../../errors';
import { COLORS, TIER_LADDER, tierLabel } from '../../constants';
import { Command, gmAutocomplete, gmOption } from './shared';
import { begin } from '../util';
import { base, success } from '../embeds';
import { config } from '../../config';
import { resolveGamemode } from '../../services/gamemodes';
import { canManageQueue, canTest, isAdmin } from '../../services/permissions';
import { clearQueueFor, dragPlayer } from '../../services/queue';
import { announceQueue } from '../../services/gamemodeSetup';
import { refreshQueuePanel } from '../panel';
import { retryPending, submitResult } from '../../services/results';
import { publishTierList } from '../../services/tierlist';
import { logEvent } from '../../services/logs';

function queueToggle(name: 'queue-open' | 'queue-close', open: boolean): Command {
  return {
    data: gmOption(new SlashCommandBuilder().setName(name).setDescription(`${open ? 'Open' : 'Close'} the queue of ONE gamemode.`).setDMPermission(false)),
    autocomplete: gmAutocomplete(false),
    async execute(i) {
      const { guild, member } = await begin(i);
      const gm = resolveGamemode(i.options.getString('gamemode', true));
      if (!canManageQueue(member, gm.id)) throw new AppError(`Only administrators, queue managers or **${gm.name}** testers can ${open ? 'open' : 'close'} this queue.`);
      if (repo.isQueueOpen(gm.id) === open) throw new AppError(`The **${gm.name}** queue is already ${open ? 'open' : 'closed'}.`); // no repeat mentions
      repo.setQueueOpen(gm.id, open, member.id);
      const panel = await refreshQueuePanel(guild, gm.id, true);
      const warnings = await announceQueue(guild, gm, open, member.id);
      if (panel === 'none' || panel === 'missing-channel') warnings.push(`The ${gm.name} queue panel could not be updated. Run \`/setup-tier-testing\` to repair it.`);
      await logEvent(guild, { channel: 'queue', title: open ? '🟢 Queue opened' : '🔴 Queue closed', color: open ? COLORS.success : COLORS.warn, user: member.id, gamemode: gm.name });
      const e = success(`Queue ${open ? 'opened' : 'closed'}`,
        open ? `The ${gm.emoji} **${gm.name}** queue is open and the **${gm.name}** role was announced.`
          : `The ${gm.emoji} **${gm.name}** queue is closed. Players already waiting keep their spot.`);
      await i.editReply({ embeds: warnings.length ? [e, base(COLORS.warn, '⚠️ Warnings', warnings.join('\n'))] : [e] });
    },
  };
}

const drag: Command = {
  data: gmOption(new SlashCommandBuilder().setName('drag').setDescription('Create a private ticket for the FIRST player in a gamemode queue.').setDMPermission(false)),
  autocomplete: gmAutocomplete(false),
  async execute(i) {
    const { guild, member } = await begin(i);
    const gm = resolveGamemode(i.options.getString('gamemode', true));
    if (!canTest(member, gm.id)) throw new AppError(`Only **${gm.name}** testers or administrators can use \`/drag ${gm.name}\`.`);
    const r = await dragPlayer(guild, member, gm.id);
    await i.editReply({ embeds: [success('Player dragged', `<@${r.userId}> (**${r.ign}**) was pulled from the ${r.gamemode.emoji} **${r.gamemode.name}** queue.\nTicket: <#${r.channelId}> (#${r.ticket.id})`)] });
  },
};

const queueClear: Command = {
  data: gmOption(new SlashCommandBuilder().setName('queue-clear').setDescription('Remove EVERY waiting player from a gamemode queue.').setDMPermission(false)),
  autocomplete: gmAutocomplete(false),
  async execute(i) {
    const { guild, member } = await begin(i);
    const gm = resolveGamemode(i.options.getString('gamemode', true));
    if (!canManageQueue(member, gm.id) || !(isAdmin(member) || config.queueManagerRoleIds.some((id) => member.roles.cache.has(id)))) {
      throw new AppError('Only administrators or queue managers can clear a queue.');
    }
    const n = await clearQueueFor(guild, gm.id, member.id);
    await i.editReply({ embeds: [success('Queue cleared', `Removed **${n}** player(s) from the **${gm.name}** queue.`)] });
  },
};

const tierChoices = [...TIER_LADDER].reverse().map((t) => ({ name: t, value: t }));

function resultCommand(name: 'result' | 'high-result' | 'result-correct'): Command {
  const high = name === 'high-result';
  const correct = name === 'result-correct';
  const b = new SlashCommandBuilder().setName(name).setDMPermission(false)
    .setDescription(correct ? 'Admin: correct a player\'s latest result (history is kept).'
      : high ? 'Submit a HIGH result (requires the High Result permission).' : 'Submit a tier test result for a player.')
    .addStringOption((o) => o.setName('tier').setDescription('The tier the player earned').setRequired(true).addChoices(...tierChoices))
    .addUserOption((o) => o.setName('player').setDescription('The player who was tested').setRequired(true))
    .addStringOption((o) => o.setName('gamemode').setDescription('The gamemode that was tested').setRequired(true).setAutocomplete(true));
  if (correct) b.addStringOption((o) => o.setName('reason').setDescription('Why the result is being corrected').setMaxLength(300));
  if (correct) b.setDefaultMemberPermissions(PermissionFlagsBits.Administrator);
  return {
    data: b,
    autocomplete: gmAutocomplete(false),
    async execute(i) {
      const { guild, member } = await begin(i, { admin: correct });
      const user = i.options.getUser('player', true);
      if (user.bot) throw new AppError('Bots cannot be tested.');
      const s = await submitResult({
        guild, tester: member, userId: user.id, high,
        gamemode: resolveGamemode(i.options.getString('gamemode', true)), tier: i.options.getString('tier', true),
        correction: correct ? { reason: i.options.getString('reason') ?? undefined } : undefined,
      });
      const where = [s.announced.result === 'failed' ? '⚠️ #result announcement failed (retry with `/result-retry`)' : '#result',
        s.high ? (s.announced.high === 'failed' ? '⚠️ #high-result announcement failed (retry with `/result-retry`)' : '#high-result') : null].filter(Boolean).join(' • ');
      const e = success(correct ? 'Result corrected' : s.high ? 'High result recorded' : 'Result recorded',
        `**${s.ign}** (<@${s.userId}>) — ${s.gamemode.emoji} ${s.gamemode.name}\n${tierLabel(s.oldTier, s.gamemode.name)} → **${tierLabel(s.newTier, s.gamemode.name)}**\n` +
        `Saved • ${s.roleError ? 'roles **NOT** updated' : 'roles updated'} • announced: ${where}${s.ticketChannelId ? ' • ticket closing' : ''}`);
      await i.editReply({ embeds: s.roleError
        ? [e, base(COLORS.error, '❌ Role update failed', `${s.roleError}\n\nThe result is saved. Fix the permission/role position, then run \`/result-retry\` — the role was **not** assigned.`)]
        : [e] });
    },
  };
}

const resultRetry: Command = {
  data: new SlashCommandBuilder().setName('result-retry').setDescription('Retry failed role updates and missing result announcements.').setDMPermission(false)
    .addUserOption((o) => o.setName('player').setDescription('Only this player (default: everything pending)')),
  async execute(i) {
    const { guild, member } = await begin(i);
    const user = i.options.getUser('player');
    const r = await retryPending(guild, { userId: user?.id, allowed: (gmId) => canTest(member, gmId) });
    const lines = [`✅ Roles fixed: **${r.rolesFixed}**`, `📣 Announcements posted: **${r.announced}**`];
    if (r.rolesFailed.length) lines.push(`❌ Still failing:\n${r.rolesFailed.join('\n')}`);
    await i.editReply({ embeds: [base(r.rolesFailed.length ? COLORS.warn : COLORS.success, 'Retry finished', lines.join('\n').slice(0, 3900))] });
    await logEvent(guild, { channel: 'result', title: '🔁 Result retry', user: member.id, description: `roles fixed ${r.rolesFixed}, announcements ${r.announced}, failing ${r.rolesFailed.length}` });
  },
};

const tierList: Command = {
  data: new SlashCommandBuilder().setName('tier-list').setDescription('Publish or refresh the tier list in #tier-list.').setDMPermission(false),
  async execute(i) {
    const { guild, member } = await begin(i);
    const allowed = isAdmin(member) || config.queueManagerRoleIds.some((id) => member.roles.cache.has(id))
      || repo.listAllRoleMappings('tester').some((m) => member.roles.cache.has(m.role_id));
    if (!allowed) throw new AppError('Only administrators, queue managers or testers can publish the tier list.');
    const r = await publishTierList(guild, member.id);
    if (!r) throw new AppError('The **#tier-list** channel was not found. An admin must run `/setup-tier-testing`.');
    await i.editReply({ embeds: [success('Tier list published', `${r.messages} message(s) updated in <#${repo.getConfig('tierlist_channel')}>. Existing messages are edited, not duplicated.`)] });
  },
};

export const testerCommands: Command[] = [
  queueToggle('queue-open', true), queueToggle('queue-close', false), drag, queueClear,
  resultCommand('result'), resultCommand('high-result'), resultCommand('result-correct'), resultRetry, tierList,
];
