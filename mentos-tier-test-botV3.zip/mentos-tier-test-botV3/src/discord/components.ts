import {
  ActionRowBuilder, ButtonBuilder, ButtonInteraction, ButtonStyle, MessageComponentInteraction, ModalBuilder,
  ModalSubmitInteraction, StringSelectMenuBuilder, StringSelectMenuInteraction, TextInputBuilder, TextInputStyle,
} from 'discord.js';
import * as repo from '../db/repo';
import { AppError, ProfileRequiredError } from '../errors';
import { COLORS, DEFAULT_TIER, TIER_LADDER, tierLabel } from '../constants';
import { begin, EPHEMERAL } from './util';
import { notice, profileEmbed, success, warning } from './embeds';
import { toComponentEmoji } from '../services/gamemodes';
import { assertIgnAvailable, saveProfileComplete, validateIgn } from '../services/profiles';
import { syncGamemodeRoles } from '../services/gamemodeSetup';
import { cancelTicket, joinQueue, leaveQueue, refreshTicketMessage } from '../services/queue';
import { submitResult } from '../services/results';
import { canTest, isAdmin } from '../services/permissions';
import { logEvent } from '../services/logs';

/* ============================ profile flow ============================ */
function ignModal(current?: string) {
  const input = new TextInputBuilder().setCustomId('ign').setLabel('Minecraft IGN')
    .setStyle(TextInputStyle.Short).setMinLength(3).setMaxLength(16).setRequired(true).setPlaceholder('e.g. MentoYT');
  if (current) input.setValue(current);
  return new ModalBuilder().setCustomId('profile:modal').setTitle('Tier Testing Profile')
    .addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(input));
}

/** Opens step 1 (IGN modal). Used by the panel button and by /profile-edit. */
export function startProfileFlow(i: { user: { id: string }; showModal: (m: ModalBuilder) => Promise<unknown> }) {
  return i.showModal(ignModal(repo.getProfile(i.user.id)?.ign));
}

/** Step 2 message: multi-select of gamemodes. The validated IGN rides in the custom id so nothing is saved until step 2 finishes. */
function gamemodeStep(userId: string, ign: string) {
  const gms = repo.listGamemodes(true).slice(0, 25);
  if (!gms.length) throw new AppError('No gamemodes are active yet. Ask an admin to add some.');
  const chosen = new Set(repo.getProfileGamemodeIds(userId));
  const menu = new StringSelectMenuBuilder().setCustomId(`profile:gms:${ign}`)
    .setPlaceholder('Select the gamemodes you want to test…').setMinValues(1).setMaxValues(gms.length)
    .addOptions(gms.map((g) => ({ label: g.name, value: String(g.id), emoji: toComponentEmoji(g.emoji), default: chosen.has(g.id) })));
  return {
    embeds: [notice('🎮 Choose your gamemodes', `IGN: **${ign}**\nSelect every gamemode you want to be tested in, then confirm. Your profile is saved when you pick your gamemodes.\n*Nothing has been saved yet.*`)],
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu)],
  };
}

async function profileModal(i: ModalSubmitInteraction) {
  const ign = validateIgn(i.fields.getTextInputValue('ign'));
  assertIgnAvailable(i.user.id, ign);
  await i.reply({ ...gamemodeStep(i.user.id, ign), flags: EPHEMERAL });
}

async function profileGamemodeSelect(i: StringSelectMenuInteraction) {
  const { guild, member } = await begin(i, { update: true });
  const ign = i.customId.slice('profile:gms:'.length);
  const r = saveProfileComplete(i.user.id, i.user.username, ign, i.values.map(Number), 'discord');
  const warnings = await syncGamemodeRoles(guild, member);
  const e = success(r.created ? 'Profile created' : 'Profile updated',
    `**IGN:** ${r.ign}\n**Gamemodes:** ${r.gamemodeIds.map((id) => repo.getGamemode(id)!.name).join(', ')}\n**Starting tier:** ${DEFAULT_TIER}\n\nYour gamemode roles were synchronized. You can now join the queue of those gamemodes.`);
  const embeds: any[] = [e];
  if (warnings.length) embeds.push(warning('Role sync warning', warnings.join('\n')));
  await i.editReply({ embeds, components: [] });
}

async function profileView(i: ButtonInteraction) {
  await begin(i);
  const e = profileEmbed(i.user.id);
  if (!e) throw new ProfileRequiredError(repo.getConfig('profile_channel'));
  await i.editReply({ embeds: [e] });
}

/* ============================ router ============================ */
export async function routeComponent(i: MessageComponentInteraction | ModalSubmitInteraction): Promise<void> {
  const id = i.customId;
  if (id.startsWith('confirm:')) return; // handled by the command that created them
  if (i.isButton()) {
    if (id === 'profile:start') return void (await startProfileFlow(i));
    if (id === 'profile:view') return profileView(i);
    if (id.startsWith('q:join:')) return queueJoinButton(i);
    if (id.startsWith('q:leave:')) return queueLeaveButton(i);
    if (id.startsWith('ticket:')) return ticketButton(i);
  } else if (i.isStringSelectMenu()) {
    if (id.startsWith('profile:gms:')) return profileGamemodeSelect(i);
    if (id === 'ticket:resultsel') return ticketResultSelect(i);
  } else if (i.isModalSubmit()) {
    if (id === 'profile:modal') return profileModal(i);
  }
}

/* ============================ queue panels ============================ */
async function queueJoinButton(i: ButtonInteraction) {
  const { guild } = await begin(i);
  const r = await joinQueue(guild, { id: i.user.id, username: i.user.username }, Number(i.customId.split(':')[2]));
  await i.editReply({ embeds: [success('Joined the queue', `You are **#${r.position}** in the ${r.gamemode.emoji} **${r.gamemode.name}** queue.\nA tester will pull you into a private ticket when it's your turn.`)] });
}

async function queueLeaveButton(i: ButtonInteraction) {
  const { guild } = await begin(i);
  const gm = await leaveQueue(guild, i.user.id, Number(i.customId.split(':')[2]));
  await i.editReply({ embeds: [success('Left the queue', `You left the **${gm.name}** queue.`)] });
}

/* ============================ tickets ============================ */
function loadActiveTicket(channelId: string | null): repo.Ticket {
  const t = channelId ? repo.getTicketByChannel(channelId) : undefined;
  if (!t || !repo.ACTIVE_STATUSES.includes(t.status)) throw new AppError('This is not an active test ticket.');
  return t;
}

async function ticketButton(i: ButtonInteraction) {
  switch (i.customId) {
    case 'ticket:claim': return ticketClaim(i);
    case 'ticket:start': return ticketStart(i);
    case 'ticket:result': return ticketResultPrompt(i);
    case 'ticket:close': return ticketClosePrompt(i);
    case 'ticket:closeyes': return ticketCloseConfirm(i);
    case 'ticket:closeno': return void (await i.update({ embeds: [notice('Ticket kept open')], components: [] }));
  }
}

async function ticketClaim(i: ButtonInteraction) {
  const { guild, member } = await begin(i);
  const t = loadActiveTicket(i.channelId);
  const gm = repo.getGamemode(t.gamemode_id)!;
  const admin = isAdmin(member);
  if (member.id === t.discord_id) throw new AppError("You can't claim your own test.");
  if (!canTest(member, gm.id)) throw new AppError(`Only **${gm.name}** testers or administrators can claim this ticket.`);
  if (t.tester_id === member.id) throw new AppError('You are already the assigned tester.');
  if (t.tester_id && !admin) throw new AppError(`This ticket is already assigned to <@${t.tester_id}>. Only administrators can reassign it.`);
  const oldTester = t.tester_id;
  // atomic: two testers pressing at once -> only one UPDATE matches
  if (!repo.claimTicket(t.id, member.id, !!oldTester && admin)) throw new AppError('Another tester claimed this ticket first.');
  repo.upsertUser(member.id, member.user.username);

  const ch: any = i.channel;
  try {
    await ch.permissionOverwrites.edit(member.id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true, AttachFiles: true, EmbedLinks: true });
    if (oldTester) await ch.permissionOverwrites.delete(oldTester).catch(() => {});
  } catch { /* the bot may lack channel permissions; the claim itself is already saved */ }
  await refreshTicketMessage(guild, t.id);
  await ch.send({ content: `🧪 <@${t.discord_id}> your tester is now <@${member.id}>.`, allowedMentions: { users: [t.discord_id] } }).catch(() => {});
  await logEvent(guild, { channel: 'tester', title: oldTester ? '🔁 Tester reassigned' : '🧪 Tester assigned', color: COLORS.primary, user: member.id, player: t.discord_id, gamemode: gm.name, description: oldTester ? `Previously <@${oldTester}>` : undefined });
  await i.editReply({ embeds: [success(oldTester ? 'Ticket reassigned to you' : 'Ticket claimed', 'Press **Start Test** when you are ready.')] });
}

async function ticketStart(i: ButtonInteraction) {
  const { guild, member } = await begin(i);
  const t = loadActiveTicket(i.channelId);
  const gm = repo.getGamemode(t.gamemode_id)!;
  if (t.status !== 'claimed') throw new AppError(t.status === 'waiting' ? 'Claim the ticket first.' : 'The test already started.');
  if (member.id !== t.tester_id && !isAdmin(member)) throw new AppError('Only the assigned tester can start this test.');
  repo.startTest(t.id, t.discord_id, gm.id, t.tester_id ?? member.id);
  await refreshTicketMessage(guild, t.id);
  await (i.channel as any)?.send({ content: `▶️ The **${gm.name}** test has started. Good luck <@${t.discord_id}>!`, allowedMentions: { users: [t.discord_id] } }).catch(() => {});
  await logEvent(guild, { channel: 'ticket', title: '▶️ Test started', color: COLORS.primary, user: member.id, player: t.discord_id, gamemode: gm.name });
  await i.editReply({ embeds: [success('Test started')] });
}

async function ticketResultPrompt(i: ButtonInteraction) {
  const { member } = await begin(i);
  const t = loadActiveTicket(i.channelId);
  const gm = repo.getGamemode(t.gamemode_id)!;
  if (!canTest(member, gm.id)) throw new AppError(`Only **${gm.name}** testers can complete tests.`);
  if (t.status === 'waiting') throw new AppError('Claim the ticket before completing the test.');
  if (t.tester_id && t.tester_id !== member.id && !isAdmin(member)) throw new AppError(`Only the assigned tester (<@${t.tester_id}>) or an administrator can complete this test.`);
  const old = repo.getExpectedOldTier(t.discord_id, gm.id);
  const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder().setCustomId('ticket:resultsel').setPlaceholder('Select the NEW tier…')
      .addOptions([...TIER_LADDER].reverse().map((x) => ({ label: tierLabel(x, gm.name), value: x }))));
  await i.editReply({ embeds: [notice('🏆 Complete Test', `Current tier: **${tierLabel(old, gm.name)}**\nSelect the new tier for <@${t.discord_id}>. (Tiers that count as high results need the High Result permission.)`)], components: [row] });
}

async function ticketResultSelect(i: StringSelectMenuInteraction) {
  const { guild, member } = await begin(i, { update: true });
  const t = loadActiveTicket(i.channelId);
  if (t.tester_id && t.tester_id !== member.id && !isAdmin(member)) throw new AppError(`Only the assigned tester (<@${t.tester_id}>) or an administrator can complete this test.`);
  const r = await submitResult({
    guild, tester: member, ticket: t, high: false, userId: t.discord_id,
    gamemode: repo.getGamemode(t.gamemode_id)!, tier: i.values[0],
  });
  const e = success('Result submitted', `**${r.ign}**: ${r.oldTier} → **${r.newTier}** (${r.gamemode.name})`);
  await i.editReply({ embeds: r.roleError ? [e, warning('Role update failed', `${r.roleError}\nThe result is saved. Use \`/result-retry\` once fixed.`)] : [e], components: [] });
}

async function ticketClosePrompt(i: ButtonInteraction) {
  const { member } = await begin(i);
  const t = loadActiveTicket(i.channelId);
  const gm = repo.getGamemode(t.gamemode_id)!;
  if (!canTest(member, gm.id) && !isAdmin(member)) throw new AppError('Only testers or staff can close this ticket.');
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId('ticket:closeyes').setLabel('Close & cancel test').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('ticket:closeno').setLabel('Keep open').setStyle(ButtonStyle.Secondary));
  await i.editReply({ embeds: [notice('🔒 Close this ticket?', 'The test is cancelled with **no result**. Existing results and logs are kept; only this channel is removed.')], components: [row] });
}

async function ticketCloseConfirm(i: ButtonInteraction) {
  const { guild, member } = await begin(i, { update: true });
  const t = loadActiveTicket(i.channelId);
  const gm = repo.getGamemode(t.gamemode_id)!;
  if (!canTest(member, gm.id) && !isAdmin(member)) throw new AppError('Only testers or staff can close this ticket.');
  await i.editReply({ embeds: [success('Closing ticket…')], components: [] });
  await cancelTicket(guild, t, member.id, `Closed by <@${member.id}> without a result.`);
}
