import { EmbedBuilder } from 'discord.js';
import * as repo from '../db/repo';
import { BRAND, COLORS, DEFAULT_TIER } from '../constants';

export function base(color: number, title?: string, desc?: string): EmbedBuilder {
  const e = new EmbedBuilder().setColor(color).setFooter({ text: BRAND }).setTimestamp();
  if (title) e.setTitle(title);
  if (desc) e.setDescription(desc);
  return e;
}
export const success = (title: string, desc?: string) => base(COLORS.success, `✅ ${title}`, desc);
export const failure = (desc: string) => base(COLORS.error, '❌ Error', desc);
export const notice = (title: string, desc?: string) => base(COLORS.primary, title, desc);
export const warning = (title: string, desc?: string) => base(COLORS.warn, `⚠️ ${title}`, desc);

export const fmtDate = (iso: string) => `<t:${Math.floor(new Date(iso).getTime() / 1000)}:d>`;
export const fmtDateTime = (iso: string) => `<t:${Math.floor(new Date(iso).getTime() / 1000)}:f>`;

/** Profile card: selected gamemodes with the official tier (or the HT1 default). */
export function profileEmbed(userId: string): EmbedBuilder | null {
  const p = repo.getProfile(userId);
  if (!p) return null;
  const selected = repo.getProfileGamemodeIds(userId).map((id) => repo.getGamemode(id)!).filter((g) => g && g.active);
  const cur = repo.getPlayerTiers(userId);
  const lines = selected.map((g) => cur[g.id] ? `${g.emoji} **${g.name}** → **${cur[g.id]}** ✅` : `${g.emoji} **${g.name}** → ${DEFAULT_TIER}`);
  const recent = repo.listResults({ userId, limit: 5 });
  const e = base(COLORS.primary, `👤 ${p.username}`)
    .addFields(
      { name: '🪪 IGN', value: p.ign, inline: true },
      { name: '📊 Tests Completed', value: String(repo.countResults(userId)), inline: true },
      { name: '📅 Created', value: fmtDate(p.created_at), inline: true },
      { name: '🎮 Gamemodes', value: lines.join('\n') || 'None selected yet — edit your profile in #profile.' },
    );
  if (recent.length) {
    e.addFields({
      name: 'Latest Results',
      value: recent.map((r) => `${r.emoji} ${r.gamemode}: ${r.old_tier} → ${r.new_tier}${r.is_high ? ' 🔥' : ''}`).join('\n'),
    });
  }
  return e;
}
