import { ActionRowBuilder, ButtonBuilder, ButtonStyle, Guild } from 'discord.js';
import * as repo from '../db/repo';
import { config } from '../config';
import { BRAND, COLORS, DEFAULT_TIER, GAMEMODE_BLURBS, channelSlug } from '../constants';
import { base } from './embeds';
import { log } from '../logger';

export function getWebUrl(): string {
  return repo.getConfig('web_url') ?? config.webPublicUrl;
}
/** Discord rejects link buttons it can't open; localhost URLs are skipped. */
export function isLinkable(url: string): boolean {
  try {
    const u = new URL(url);
    return /^https?:$/.test(u.protocol) && !['localhost', '127.0.0.1', '0.0.0.0'].includes(u.hostname);
  } catch { return false; }
}

async function getChannel(guild: Guild, id?: string): Promise<any | null> {
  if (!id) return null;
  const ch: any = guild.channels.cache.get(id) ?? (await guild.channels.fetch(id).catch(() => null));
  return ch && ch.isTextBased() ? ch : null;
}

/** Edits the stored panel message, or (when allowed) re-creates it. Never throws. */
async function upsertPanel(guild: Guild, channelKey: string, messageKey: string, payload: any, create: boolean): Promise<'created' | 'updated' | 'none' | 'missing-channel'> {
  try {
    const ch = await getChannel(guild, repo.getConfig(channelKey));
    if (!ch) return 'missing-channel';
    const msgId = repo.getConfig(messageKey);
    if (msgId) {
      const msg = await ch.messages.fetch(msgId).catch(() => null);
      if (msg) { await msg.edit(payload); return 'updated'; }
    }
    if (!create) return 'none';
    const sent = await ch.send(payload);
    repo.setConfig(messageKey, sent.id);
    return 'created';
  } catch (e: any) {
    log.warn(`Panel update failed (${messageKey}):`, e?.message ?? e);
    return 'none';
  }
}

/* ------------------------------ profile panel ------------------------------ */
export function buildProfilePanel() {
  const embed = base(COLORS.primary, `📝 ${BRAND} — Player Profile`,
    'Create your profile once, then queue for tier tests in any gamemode you selected.\n\n' +
    '**How tier testing works**\n' +
    '**1.** Press **Create Profile / Edit Profile** and enter your Minecraft IGN.\n' +
    '**2.** Pick the gamemodes you want to be tested in — you get the matching gamemode roles.\n' +
    '**3.** Go to that gamemode\'s channel in **WAITLIST** and press **Join Queue** while the queue is **OPEN**.\n' +
    '**4.** A tester drags you into a private ticket and runs your test.\n' +
    `**5.** Your result is recorded. Until then you are **${DEFAULT_TIER}**.\n\n` +
    '🔒 Your Discord account is detected automatically — you only provide your IGN and gamemodes.');
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId('profile:start').setLabel('Create Profile / Edit Profile').setEmoji('📝').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('profile:view').setLabel('View My Profile').setEmoji('👤').setStyle(ButtonStyle.Secondary),
  );
  return { embeds: [embed], components: [row] };
}
export const publishProfilePanel = (guild: Guild, create = true) =>
  upsertPanel(guild, 'profile_channel', 'profile_panel', buildProfilePanel(), create);

/* ------------------------------ gamemode queue panels ------------------------------ */
export function buildQueuePanel(gmId: number) {
  const gm = repo.getGamemode(gmId)!;
  const active = !!gm.active;
  const open = active && repo.isQueueOpen(gmId);
  const waiting = repo.listWaiting(gmId);
  const shown = waiting.slice(0, 20).map((w) => `**${w.position}.** ${w.ign ?? w.username ?? 'Unknown'} — <@${w.discord_id}>`);
  if (waiting.length > 20) shown.push(`…and ${waiting.length - 20} more`);
  const blurb = GAMEMODE_BLURBS[channelSlug(gm.name)] ?? `Request a ${gm.name} tier test.`;
  const embed = base(!active ? COLORS.warn : open ? COLORS.success : COLORS.error, `${gm.emoji} ${gm.name} Queue`,
    `${blurb}\n\nYou need a profile (with **${gm.name}** selected) to join. Testers pull players in first-come, first-served order.`)
    .addFields(
      { name: 'Status', value: !active ? '⚪ DISABLED' : open ? '🟢 **OPEN**' : '🔴 **CLOSED**', inline: true },
      { name: 'In queue', value: String(waiting.length), inline: true },
      { name: 'Queue', value: shown.join('\n') || '*Nobody is waiting.*' },
    );
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`q:join:${gmId}`).setLabel('Join Queue').setEmoji('➕').setStyle(ButtonStyle.Success).setDisabled(!open),
    new ButtonBuilder().setCustomId(`q:leave:${gmId}`).setLabel('Leave Queue').setEmoji('➖').setStyle(ButtonStyle.Secondary).setDisabled(!active),
  );
  return { embeds: [embed], components: [row] };
}

/** Keeps the single queue-panel message of a gamemode in sync (edit, never repost). */
export const refreshQueuePanel = (guild: Guild, gmId: number, create = false) =>
  upsertPanel(guild, `gm_channel:${gmId}`, `gm_panel:${gmId}`, buildQueuePanel(gmId), create);
