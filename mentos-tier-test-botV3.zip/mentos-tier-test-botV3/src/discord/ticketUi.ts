import { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } from 'discord.js';
import * as repo from '../db/repo';
import { COLORS } from '../constants';
import { base } from './embeds';

export const STATUS_LABEL: Record<string, string> = {
  waiting: '⏳ Waiting for tester',
  claimed: '🧪 Tester assigned',
  in_progress: '▶️ Test in progress',
  completed: '✅ Completed',
  cancelled: '🚫 Cancelled',
};

export function ticketEmbed(t: repo.Ticket): EmbedBuilder {
  const gm = repo.getGamemode(t.gamemode_id)!;
  const profile = repo.getProfile(t.discord_id);
  const display = profile?.username ?? repo.getUsername(t.discord_id) ?? t.discord_id;
  return base(COLORS.primary, `🎫 ${gm.name.toUpperCase()} TIER TEST — ${display.toUpperCase()}`,
    'The assigned tester will contact you here. When ready, the tester presses **Start Test**; afterwards the result is submitted and this ticket closes automatically.')
    .addFields(
      { name: '🎮 Gamemode', value: `${gm.emoji} ${gm.name}`, inline: true },
      { name: '👤 Player', value: `<@${t.discord_id}>`, inline: true },
      { name: '🪪 IGN', value: profile?.ign ?? 'Unknown', inline: true },
      { name: '🎟️ Ticket', value: `#${t.id}${t.queue_position ? ` • queue position was #${t.queue_position}` : ''}`, inline: true },
      { name: '👨‍⚖️ Assigned Tester', value: t.tester_id ? `<@${t.tester_id}>` : 'Not assigned — press **Claim / Assign**', inline: true },
      { name: '📊 Status', value: STATUS_LABEL[t.status] ?? t.status, inline: true },
      { name: '🏆 Current Tier', value: t.last_tier, inline: true },
    );
}

export function ticketButtons(t: repo.Ticket): ActionRowBuilder<ButtonBuilder>[] {
  const closed = t.status === 'completed' || t.status === 'cancelled';
  return [
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId('ticket:claim').setLabel('Claim / Assign').setEmoji('🧪')
        .setStyle(ButtonStyle.Success).setDisabled(closed),
      new ButtonBuilder().setCustomId('ticket:start').setLabel('Start Test').setEmoji('▶️')
        .setStyle(ButtonStyle.Primary).setDisabled(closed || t.status !== 'claimed'),
      new ButtonBuilder().setCustomId('ticket:result').setLabel('Complete Test').setEmoji('🏆')
        .setStyle(ButtonStyle.Primary).setDisabled(closed || t.status === 'waiting'),
      new ButtonBuilder().setCustomId('ticket:close').setLabel('Close Ticket').setEmoji('🔒')
        .setStyle(ButtonStyle.Danger).setDisabled(closed),
    ),
  ];
}
