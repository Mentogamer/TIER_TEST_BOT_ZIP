import {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, Guild, GuildMember, MessageFlags, RepliableInteraction,
} from 'discord.js';
import { AppError, NeedsProfileError } from '../errors';
import { isAdmin } from '../services/permissions';
import { failure } from './embeds';
import { log } from '../logger';
import { logEvent } from '../services/logs';
import { COLORS } from '../constants';

export const EPHEMERAL = MessageFlags.Ephemeral;

/**
 * Acknowledges the interaction right away (ephemeral reply, or silent update for components on an
 * ephemeral message) so slow Discord operations never hit the 3 second limit, then resolves guild + member.
 */
export async function begin(
  i: RepliableInteraction, opts: { admin?: boolean; update?: boolean } = {},
): Promise<{ guild: Guild; member: GuildMember }> {
  if (!i.guild) throw new AppError('This can only be used inside the server.');
  if (!i.deferred && !i.replied) {
    if (opts.update && 'deferUpdate' in i) await (i as any).deferUpdate();
    else await i.deferReply({ flags: EPHEMERAL });
  }
  const member = await i.guild.members.fetch(i.user.id);
  if (opts.admin && !isAdmin(member)) throw new AppError('Only server administrators can use this command.');
  return { guild: i.guild, member };
}

const DISCORD_ERRORS: Record<number, string> = {
  50013: "I'm missing permissions. Make sure my role is **above** the tier/tester roles and that I have **Manage Roles** and **Manage Channels**.",
  50001: "I don't have access to that channel or resource.",
  10003: 'A required channel no longer exists. An admin should run `/setup-tier-testing` again.',
  10011: 'A required role no longer exists. Run the role-create command again.',
  10007: 'That user is not in this server.',
  10008: 'A required message no longer exists.',
};

export function errorPayload(e: any): { embeds: any[]; components: any[]; known: boolean } {
  if (e instanceof NeedsProfileError) {
    return {
      known: true,
      embeds: [failure(e.message)],
      components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId('profile:start').setLabel(e.buttonLabel).setEmoji('📝').setStyle(ButtonStyle.Primary))],
    };
  }
  if (e instanceof AppError) return { known: true, embeds: [failure(e.message)], components: [] };
  if (e?.code && DISCORD_ERRORS[e.code]) return { known: true, embeds: [failure(DISCORD_ERRORS[e.code])], components: [] };
  return { known: false, embeds: [failure('Something went wrong. The error has been logged for the staff.')], components: [] };
}

/** Central error handler: replies to the user and logs unexpected errors. Never throws. */
export async function handleInteractionError(i: any, e: any): Promise<void> {
  const p = errorPayload(e);
  if (!p.known) {
    log.error('Unhandled interaction error:', e?.stack ?? e);
    await logEvent(i.guild, {
      title: '❌ Error', color: COLORS.error, user: i.user?.id,
      description: `\`${String(e?.message ?? e).slice(0, 500)}\``,
      fields: [{ name: 'Where', value: i.commandName ? `/${i.commandName}` : String(i.customId ?? 'unknown'), inline: true }],
    });
  }
  try {
    if (i.deferred || i.replied) await i.editReply({ content: '', embeds: p.embeds, components: p.components });
    else await i.reply({ embeds: p.embeds, components: p.components, flags: EPHEMERAL });
  } catch (err: any) { log.warn('Could not send error reply:', err?.message); }
}
