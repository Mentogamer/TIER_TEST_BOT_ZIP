/** An error whose message is safe and useful to show to the end user. */
export class AppError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'AppError';
  }
}

/** An error that should come with a button that opens the profile form. */
export class NeedsProfileError extends AppError {
  constructor(message: string, public buttonLabel = 'Create / Edit Profile') {
    super(message);
    this.name = 'NeedsProfileError';
  }
}

export class ProfileRequiredError extends NeedsProfileError {
  constructor(profileChannelId?: string) {
    super(`You don't have a profile yet.\nVisit ${profileChannelId ? `<#${profileChannelId}>` : '#profile'} and create one before joining a queue.`, 'Create Profile');
    this.name = 'ProfileRequiredError';
  }
}
