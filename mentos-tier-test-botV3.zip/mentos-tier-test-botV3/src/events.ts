import { EventEmitter } from 'node:events';
/** In-process event bus (bot <-> web when both run in one process). */
export const appEvents = new EventEmitter();
