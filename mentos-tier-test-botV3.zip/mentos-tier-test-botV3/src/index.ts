import { migrate, seedDefaults } from './db/migrations';
import { db } from './db/connection';
import { startBot, stopBot } from './discord/bot';
import { startWeb } from './web/server';
import { log } from './logger';

async function main() {
  const args = process.argv.slice(2);
  const botOnly = args.includes('--bot-only');
  const webOnly = args.includes('--web-only');

  migrate();
  seedDefaults();

  if (!webOnly) await startBot();
  if (!botOnly) startWeb();

  const shutdown = async () => {
    log.info('Shutting down…');
    await stopBot();
    try { db.close(); } catch { /* ignore */ }
    process.exit(0);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

// A single failing command must never take the whole bot down.
process.on('unhandledRejection', (e: any) => log.error('Unhandled rejection:', e?.stack ?? e));
process.on('uncaughtException', (e: any) => log.error('Uncaught exception:', e?.stack ?? e));

main().catch((e) => { log.error('Fatal startup error:', e?.message ?? e); process.exit(1); });
