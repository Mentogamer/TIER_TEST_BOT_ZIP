import { REST, Routes } from 'discord.js';
import { assertBotConfig, config } from './config';
import { commandJson } from './discord/commands';

export async function registerCommands(): Promise<number> {
  assertBotConfig();
  const rest = new REST({ version: '10' }).setToken(config.token);
  const body = commandJson();
  await rest.put(Routes.applicationGuildCommands(config.clientId, config.guildId), { body });
  return body.length;
}

// `npm run register`
if (require.main === module) {
  registerCommands()
    .then((n) => { console.log(`Registered ${n} slash commands in guild ${config.guildId}.`); })
    .catch((e) => { console.error('Failed to register commands:', e?.message ?? e); process.exit(1); });
}
