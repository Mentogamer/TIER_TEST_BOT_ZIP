import { EmbedBuilder, Guild } from 'discord.js';
import * as repo from '../db/repo';
import { COLORS, tierLabel } from '../constants';
import { BRAND } from '../constants';
import { log } from '../logger';

type Col = 'result_message_id' | 'high_message_id';

export function resultEmbed(r: any, high: boolean): EmbedBuilder {
  const correction = !!r.corrects_result_id;
  const title = correction ? (high ? '✏️🔥 High Result Correction' : '✏️ Result Correction') : high ? '🔥 HIGH RESULT' : '🏆 Tier Test Result';
  const ign = r.ign_display ?? 'Unknown';
  const e = new EmbedBuilder().setColor(high ? COLORS.high : COLORS.success).setTitle(title)
    .setThumbnail(`https://minotar.net/helm/${encodeURIComponent(ign)}/100.png`)
    .addFields(
      { name: 'Player', value: `<@${r.discord_id}>`, inline: true },
      { name: 'Minecraft IGN', value: ign, inline: true },
      { name: 'Gamemode', value: `${r.emoji} ${r.gamemode}`, inline: true },
      { name: 'New Tier', value: `**${tierLabel(r.new_tier, r.gamemode)}**`, inline: true },
      { name: 'Previous Tier', value: tierLabel(r.old_tier, r.gamemode), inline: true },
      { name: 'Tester', value: `<@${r.tester_id}>`, inline: true },
      { name: 'Date', value: `<t:${Math.floor(new Date(r.created_at).getTime() / 1000)}:F>` },
    ).setFooter({ text: `${BRAND} • Result #${r.id}` }).setTimestamp(new Date(r.created_at));
  if (correction && r.reason) e.setDescription(`Correction of result #${r.corrects_result_id}: ${r.reason}`);
  else if (correction) e.setDescription(`Correction of result #${r.corrects_result_id}.`);
  return e;
}

async function sendOnce(guild: Guild, r: any, col: Col, channelKey: string, high: boolean): Promise<'sent' | 'skipped' | 'failed'> {
  if (!repo.claimAnnouncement(r.id, col)) return 'skipped'; // already announced (or being announced)
  try {
    const chId = repo.getConfig(channelKey);
    const ch: any = chId ? (guild.channels.cache.get(chId) ?? (await guild.channels.fetch(chId).catch(() => null))) : null;
    if (!ch?.isTextBased()) { repo.releaseAnnouncement(r.id, col); return 'failed'; }
    const msg = await ch.send({ embeds: [resultEmbed(r, high)], allowedMentions: { parse: [] } });
    repo.finishAnnouncement(r.id, col, msg.id);
    return 'sent';
  } catch (e: any) {
    repo.releaseAnnouncement(r.id, col); // kept NULL so a retry can post it later (never twice)
    log.warn(`Announcement ${col} for result ${r.id} failed:`, e?.message);
    return 'failed';
  }
}

/** Posts #result (always) and #high-result (high results only). Safe to call repeatedly: each is sent at most once. */
export async function announceResult(guild: Guild, resultId: number): Promise<{ result: string; high: string }> {
  const r = repo.getResultFull(resultId);
  if (!r) return { result: 'skipped', high: 'skipped' };
  const result = await sendOnce(guild, r, 'result_message_id', 'result_channel', !!r.is_high);
  const high = r.is_high ? await sendOnce(guild, r, 'high_message_id', 'high_result_channel', true) : 'skipped';
  return { result, high };
}
