import { ChannelType, Guild, GuildMember, PermissionFlagsBits as P, Role } from 'discord.js';
import * as repo from '../db/repo';
import { channelSlug, looseKey } from '../constants';
import { log } from '../logger';

const REASON = "Mento's Tier Test Bot";

export function botRolePositionProblem(guild: Guild, role: Role): string | null {
  const me = guild.members.me;
  if (me && role.position >= me.roles.highest.position) {
    return `Role **${role.name}** is positioned above (or equal to) my highest role. Drag my role above it in Server Settings → Roles.`;
  }
  return null;
}

/** Finds or creates the mentionable role of a gamemode (named exactly like the gamemode). Never duplicates. */
export async function ensureGamemodeRole(guild: Guild, gm: repo.Gamemode): Promise<{ role: Role; created: boolean; problems: string[] }> {
  const problems: string[] = [];
  let role: Role | null | undefined = undefined;
  const stored = repo.getConfig(`gm_role:${gm.id}`);
  if (stored) role = guild.roles.cache.get(stored) ?? (await guild.roles.fetch(stored).catch(() => null));
  let created = false;
  if (!role) role = guild.roles.cache.find((r) => r.name.toLowerCase() === gm.name.toLowerCase() && !r.managed && r.id !== guild.id);
  if (!role) {
    role = await guild.roles.create({ name: gm.name, mentionable: true, permissions: [], reason: `${REASON}: gamemode role` });
    created = true;
  }
  repo.setConfig(`gm_role:${gm.id}`, role.id);
  if (!role.mentionable) {
    try { await role.setMentionable(true, `${REASON}: queue announcements need a mentionable role`); }
    catch { problems.push(`Role **${role.name}** is not mentionable and I could not change it (Manage Roles / role position).`); }
  }
  const pos = botRolePositionProblem(guild, role);
  if (pos) problems.push(pos);
  return { role, created, problems };
}

export function getGamemodeRoleId(gmId: number): string | undefined {
  return repo.getConfig(`gm_role:${gmId}`);
}

/**
 * Makes the member's gamemode roles match their saved profile. Only the bot-managed gamemode roles are
 * touched; unrelated roles are never removed. Returns human-readable warnings (never throws).
 */
export async function syncGamemodeRoles(guild: Guild, member: GuildMember): Promise<string[]> {
  const warnings: string[] = [];
  const selected = new Set(repo.getProfileGamemodeIds(member.id));
  const add: Role[] = [];
  const remove: string[] = [];
  for (const gm of repo.listGamemodes(true)) {
    try {
      let roleId = getGamemodeRoleId(gm.id);
      let role = roleId ? guild.roles.cache.get(roleId) : undefined;
      if (!role) {
        if (!selected.has(gm.id)) continue; // nothing to remove if the role does not exist
        role = (await ensureGamemodeRole(guild, gm)).role;
      }
      const has = member.roles.cache.has(role.id);
      if (selected.has(gm.id) && !has) add.push(role);
      if (!selected.has(gm.id) && has) remove.push(role.id);
    } catch (e: any) { warnings.push(`${gm.name}: ${e?.message ?? 'could not resolve role'}`); }
  }
  try {
    for (const r of add) { const p = botRolePositionProblem(guild, r); if (p) warnings.push(p); }
    const addable = add.filter((r) => !botRolePositionProblem(guild, r));
    if (addable.length) await member.roles.add(addable, `${REASON}: profile gamemodes`);
    if (remove.length) await member.roles.remove(remove, `${REASON}: profile gamemodes`);
  } catch (e: any) {
    log.warn('Gamemode role sync failed:', e?.message);
    warnings.push(`I couldn't update your roles (${e?.code === 50013 ? 'missing permissions / role position' : e?.message}). An admin must move my role above the gamemode roles.`);
  }
  return warnings;
}

/** Posts the "queue opened/closed" announcement in the gamemode's channel. Returns warnings; never pretends a ping worked. */
export async function announceQueue(guild: Guild, gm: repo.Gamemode, open: boolean, by: string): Promise<string[]> {
  const warnings: string[] = [];
  const chId = repo.getConfig(`gm_channel:${gm.id}`);
  const ch: any = chId ? (guild.channels.cache.get(chId) ?? (await guild.channels.fetch(chId).catch(() => null))) : null;
  if (!ch?.isTextBased()) return [`The **#${channelSlug(gm.name)}** channel was not found, so nothing was announced. Run \`/setup-tier-testing\`.`];
  try {
    if (open) {
      let roleId = getGamemodeRoleId(gm.id);
      let role: Role | undefined = roleId ? guild.roles.cache.get(roleId) : undefined;
      if (!role) { const r = await ensureGamemodeRole(guild, gm); role = r.role; warnings.push(...r.problems); }
      const me = guild.members.me;
      if (!role.mentionable && !me?.permissions.has(P.MentionEveryone)) {
        warnings.push(`The **${role.name}** role is not mentionable, so the ping was NOT delivered.`);
      }
      await ch.send({
        content: `<@&${role.id}>`,
        embeds: [{ color: 0x2ecc71, title: `🟢 ${gm.emoji} ${gm.name} queue is OPEN`, description: `<@${by}> opened the queue. Press **Join Queue** on the panel above to be tested!` }],
        allowedMentions: { roles: [role.id] },
      });
    } else {
      await ch.send({
        embeds: [{ color: 0xe74c3c, title: `🔴 ${gm.emoji} ${gm.name} queue is CLOSED`, description: `<@${by}> closed the queue. Players already waiting keep their spot.` }],
        allowedMentions: { parse: [] },
      });
    }
  } catch (e: any) {
    warnings.push(`I couldn't post the announcement in <#${ch.id}> (${e?.code === 50013 || e?.code === 50001 ? 'missing permissions' : e?.message}).`);
  }
  return warnings;
}
void [ChannelType, looseKey];
