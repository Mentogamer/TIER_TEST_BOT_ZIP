import * as repo from '../db/repo';
import { AppError } from '../errors';

export function resolveGamemode(name: string, includeInactive = false): repo.Gamemode {
  const gm = repo.findGamemode((name ?? '').trim());
  if (!gm || (!gm.active && !includeInactive)) {
    throw new AppError(`Unknown gamemode **${name}**. Use \`/gamemode-list\` to see the active gamemodes.`);
  }
  return gm;
}

const CUSTOM_EMOJI = /^<a?:\w{2,32}:\d{17,22}>$/;
export function validateEmoji(raw: string | null | undefined, fallback = '🎮'): string {
  if (!raw) return fallback;
  const e = raw.trim();
  if (CUSTOM_EMOJI.test(e) || /^\p{Extended_Pictographic}/u.test(e)) return e;
  throw new AppError('The emoji must be a normal Unicode emoji (or a server custom emoji).');
}
export function validateGamemodeName(raw: string): string {
  const n = (raw ?? '').trim().replace(/\s+/g, ' ');
  if (!/^[A-Za-z0-9][A-Za-z0-9 -]{1,23}$/.test(n)) {
    throw new AppError('Gamemode names must be 2–24 characters: letters, numbers, spaces and dashes only.');
  }
  return n;
}
/** Converts an emoji string to the object form used in select menus. */
export function toComponentEmoji(e: string): { name: string; id?: string } {
  const m = /^<a?:(\w+):(\d+)>$/.exec(e);
  return m ? { name: m[1], id: m[2] } : { name: e };
}
