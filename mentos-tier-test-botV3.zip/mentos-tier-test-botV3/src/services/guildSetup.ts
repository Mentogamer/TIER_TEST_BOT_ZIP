import { ChannelType, Guild, PermissionFlagsBits as P } from 'discord.js';
import * as repo from '../db/repo';
import { config } from '../config';
import { LOG_CHANNELS, STRUCTURE, channelSlug, looseKey } from '../constants';
import { botRolePositionProblem } from './gamemodeSetup';
import { ensureGamemodeRole } from './gamemodeSetup';
import { ensureRole } from './roles';
import { publishTierList } from './tierlist';
import { publishProfilePanel, refreshQueuePanel } from '../discord/panel';
import { GAMEMODE_BLURBS } from '../constants';

export interface SetupItem { label: string; status: 'exists' | 'created' | 'updated' | 'failed'; detail?: string }
export interface SetupReport { items: SetupItem[]; problems: string[] }

const REQUIRED: [bigint, string][] = [
  [P.ViewChannel, 'View Channels'], [P.ManageChannels, 'Manage Channels'], [P.ManageRoles, 'Manage Roles'],
  [P.SendMessages, 'Send Messages'], [P.EmbedLinks, 'Embed Links'], [P.ReadMessageHistory, 'Read Message History'],
  [P.AttachFiles, 'Attach Files'],
];

export function missingPermissions(guild: Guild): string[] {
  const me = guild.members.me;
  if (!me) return ['Could not read my own member data.'];
  return REQUIRED.filter(([f]) => !me.permissions.has(f)).map(([, n]) => `Missing server permission: **${n}**`);
}

function overwrites(guild: Guild, kind: 'public' | 'staff') {
  const bot = {
    id: guild.members.me!.id,
    allow: [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.EmbedLinks, P.AttachFiles, P.ManageChannels],
  };
  const staff = config.staffRoleIds.filter((id) => guild.roles.cache.has(id))
    .map((id) => ({ id, allow: [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.EmbedLinks] }));
  if (kind === 'public') {
    return [{
      id: guild.roles.everyone.id,
      allow: [P.ViewChannel, P.ReadMessageHistory],
      deny: [P.SendMessages, P.SendMessagesInThreads, P.CreatePublicThreads, P.CreatePrivateThreads],
    }, bot, ...staff];
  }
  return [{ id: guild.roles.everyone.id, deny: [P.ViewChannel] }, bot, ...staff];
}

type Kind = 'public' | 'staff';
interface Ctx { guild: Guild; items: SetupItem[]; problems: string[] }

/** Reuses (stored id -> same name ignoring emoji/case) or creates. Never touches unrelated channels. */
async function ensure(
  c: Ctx, key: string, label: string, name: string, type: ChannelType.GuildCategory | ChannelType.GuildText,
  o: { parent?: any; kind: Kind; topic?: string },
): Promise<any | null> {
  const { guild, items } = c;
  const stored = repo.getConfig(key);
  let ch: any = stored ? guild.channels.cache.get(stored) : undefined;
  if (!ch) {
    const want = looseKey(name);
    const candidates = guild.channels.cache.filter((x: any) => x.type === type && looseKey(x.name) === want);
    ch = candidates.find((x: any) => !o.parent || x.parentId === o.parent.id) ?? candidates.first();
  }
  if (ch) { repo.setConfig(key, ch.id); items.push({ label, status: 'exists' }); return ch; }
  if (guild.channels.cache.size >= 495) { items.push({ label, status: 'failed', detail: "the server is at Discord's 500 channel limit" }); return null; }
  if (o.parent && o.parent.children?.cache.size >= 50) { items.push({ label, status: 'failed', detail: "the category is at Discord's 50 channel limit" }); return null; }
  try {
    ch = await guild.channels.create({
      name, type, parent: o.parent?.id, topic: o.topic, permissionOverwrites: overwrites(guild, o.kind) as any,
      reason: "Mento's Tier Test Bot setup",
    } as any);
    repo.setConfig(key, ch.id);
    items.push({ label, status: 'created' });
    return ch;
  } catch (e: any) {
    items.push({ label, status: 'failed', detail: e?.code === 50013 ? 'missing permissions' : (e?.message ?? 'unknown error') });
    return null;
  }
}

/** Role + LT5/HT5 tier roles + WAITLIST channel + queue panel of one gamemode. Used by setup and /gamemode-add. */
export async function ensureGamemodeResources(c: Ctx, gm: repo.Gamemode, waitCat: any | null, reqCat: any | null): Promise<void> {
  const slug = channelSlug(gm.name);
  try {
    const r = await ensureGamemodeRole(c.guild, gm);
    c.items.push({ label: `@${r.role.name} role`, status: r.created ? 'created' : 'exists' });
    c.problems.push(...r.problems);
  } catch (e: any) {
    c.items.push({ label: `@${gm.name} role`, status: 'failed', detail: e?.code === 50013 ? 'missing Manage Roles permission' : e?.message });
  }
  // minimum tier roles (the rest are created on demand by /result or /tier-role-create)
  try {
    let created = 0;
    for (const t of ['LT5', 'HT5']) { const r = await ensureRole(c.guild, 'tier', gm, t); if (r.created) created++; const p = botRolePositionProblem(c.guild, r.role); if (p) c.problems.push(p); }
    c.items.push({ label: `LT5-${gm.name} / HT5-${gm.name} roles`, status: created ? 'created' : 'exists' });
  } catch (e: any) {
    c.items.push({ label: `${gm.name} tier roles`, status: 'failed', detail: e?.code === 50013 ? 'missing Manage Roles permission' : e?.message });
  }
  const ch = await ensure(c, `gm_channel:${gm.id}`, `#${slug}`, slug, ChannelType.GuildText,
    { parent: waitCat ?? undefined, kind: 'public', topic: `${gm.name} tier test waitlist. ${GAMEMODE_BLURBS[slug] ?? ''}`.trim() });
  if (ch) {
    // channels that an earlier version put into REQUEST TEST belong to WAITLIST now: move (never recreate)
    if (waitCat && reqCat && ch.parentId === reqCat.id && ch.parentId !== waitCat.id) {
      try { await ch.setParent(waitCat.id, { lockPermissions: false, reason: "Mento's Tier Test Bot: move to WAITLIST" }); c.items.push({ label: `#${slug}`, status: 'updated', detail: 'moved to WAITLIST' }); }
      catch (e: any) { c.items.push({ label: `#${slug}`, status: 'failed', detail: `could not move to WAITLIST (${e?.message})` }); }
    }
    const r = await refreshQueuePanel(c.guild, gm.id, true);
    c.items.push({ label: `${gm.name} queue panel`, status: r === 'created' ? 'created' : r === 'updated' ? 'updated' : 'failed', detail: r === 'none' ? 'could not post/edit the panel (check channel permissions)' : undefined });
  }
}

/** Idempotent full setup. Safe to run repeatedly. */
export async function setupTierTesting(guild: Guild): Promise<SetupReport> {
  await guild.channels.fetch();
  await guild.roles.fetch();
  await guild.members.fetchMe();
  const c: Ctx = { guild, items: [], problems: missingPermissions(guild) };
  if (c.problems.some((p) => p.includes('Manage Channels'))) return c;
  const pub = { kind: 'public' as Kind };

  // REQUEST TEST: only #profile, #result, #high-result, #tier-list
  const reqCat = await ensure(c, 'request_category', STRUCTURE.requestCategory, STRUCTURE.requestCategory, ChannelType.GuildCategory, pub);
  const prof = await ensure(c, 'profile_channel', `#${STRUCTURE.profileChannel}`, STRUCTURE.profileChannel, ChannelType.GuildText,
    { parent: reqCat ?? undefined, ...pub, topic: 'Create or edit your tier-testing profile here.' });
  await ensure(c, 'result_channel', `#${STRUCTURE.resultChannel}`, STRUCTURE.resultChannel, ChannelType.GuildText,
    { parent: reqCat ?? undefined, ...pub, topic: 'Completed tier test results.' });
  await ensure(c, 'high_result_channel', `#${STRUCTURE.highResultChannel}`, STRUCTURE.highResultChannel, ChannelType.GuildText,
    { parent: reqCat ?? undefined, ...pub, topic: 'High-tier result announcements.' });
  const tl = await ensure(c, 'tierlist_channel', `#${STRUCTURE.tierListChannel}`, STRUCTURE.tierListChannel, ChannelType.GuildText,
    { parent: reqCat ?? undefined, ...pub, topic: 'Current tier list per gamemode.' });
  if (prof) {
    const r = await publishProfilePanel(guild, true);
    c.items.push({ label: 'Profile panel', status: r === 'created' ? 'created' : r === 'updated' ? 'updated' : 'failed', detail: r === 'none' ? 'could not post/edit the panel' : undefined });
  }

  // WAITLIST: one channel + role + queue panel per gamemode
  const waitCat = await ensure(c, 'waitlist_category', STRUCTURE.waitlistCategory, STRUCTURE.waitlistCategory, ChannelType.GuildCategory, pub);
  for (const gm of repo.listGamemodes(true)) await ensureGamemodeResources(c, gm, waitCat, reqCat);

  // TIER TEST TICKET: tickets are created here by /drag
  await ensure(c, 'tickets_category', STRUCTURE.ticketCategory, STRUCTURE.ticketCategory, ChannelType.GuildCategory, { kind: 'staff' });

  // TIER TEST LOGS
  const logCat = await ensure(c, 'logs_category', STRUCTURE.logCategory, STRUCTURE.logCategory, ChannelType.GuildCategory, { kind: 'staff' });
  for (const l of Object.values(LOG_CHANNELS)) {
    await ensure(c, l.key, `#${l.name}`, l.name, ChannelType.GuildText, { parent: logCat ?? undefined, kind: 'staff', topic: l.topic });
  }

  if (tl) {
    try {
      const r = await publishTierList(guild);
      c.items.push({ label: 'Tier list', status: r ? 'updated' : 'failed', detail: r ? undefined : 'could not post' });
    } catch (e: any) { c.items.push({ label: 'Tier list', status: 'failed', detail: e?.message }); }
  }
  return c;
}

/** Used by /gamemode-add after setup already exists. */
export async function setupGamemode(guild: Guild, gm: repo.Gamemode): Promise<SetupReport> {
  await guild.channels.fetch();
  const c: Ctx = { guild, items: [], problems: missingPermissions(guild) };
  const get = (k: string) => { const id = repo.getConfig(k); return id ? guild.channels.cache.get(id) ?? null : null; };
  await ensureGamemodeResources(c, gm, get('waitlist_category'), get('request_category'));
  return c;
}
