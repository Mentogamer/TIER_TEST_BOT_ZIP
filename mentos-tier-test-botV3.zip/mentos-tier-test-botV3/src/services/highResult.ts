import * as repo from '../db/repo';
import { tierRank } from '../constants';

/** Does this tier count as a HIGH result under the configured minimum ("none" disables the criteria)? */
export function isHighTier(tier: string): boolean {
  const min = repo.getHighMinTier();
  if (min === 'none') return false;
  return tierRank(tier) >= 0 && tierRank(tier) >= tierRank(min);
}
