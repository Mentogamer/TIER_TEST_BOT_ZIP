import { EmbedBuilder, Guild } from 'discord.js';
import * as repo from '../db/repo';
import { BRAND, COLORS, LOG_CHANNELS, LogKind } from '../constants';
import { log } from '../logger';

export interface LogOpts {
  /** Which log channel: admin (default), queue, ticket, tester, result */
  channel?: LogKind;
  title: string;
  color?: number;
  description?: string;
  user?: string;       // who did it (discord id)
  player?: string;     // relevant player (discord id)
  gamemode?: string;
  oldTier?: string;
  newTier?: string;
  fields?: { name: string; value: string; inline?: boolean }[];
}

/** Posts an event to #tier-test-logs. Never throws. */
export async function logEvent(guild: Guild | null | undefined, o: LogOpts): Promise<void> {
  log.info(`[event] ${o.title}${o.gamemode ? ` | ${o.gamemode}` : ''}${o.user ? ` | by ${o.user}` : ''}${o.description ? ` | ${o.description}` : ''}`);
  try {
    const id = repo.getConfig(LOG_CHANNELS[o.channel ?? 'admin'].key) ?? repo.getConfig('logs_channel');
    if (!guild || !id) return;
    const ch: any = guild.channels.cache.get(id) ?? (await guild.channels.fetch(id).catch(() => null));
    if (!ch || !ch.isTextBased()) return;
    const e = new EmbedBuilder().setColor(o.color ?? COLORS.primary).setTitle(o.title).setTimestamp().setFooter({ text: BRAND });
    if (o.description) e.setDescription(o.description.slice(0, 4000));
    const f: { name: string; value: string; inline?: boolean }[] = [];
    if (o.user) f.push({ name: 'User', value: `<@${o.user}>`, inline: true });
    if (o.player) f.push({ name: 'Player', value: `<@${o.player}>${repo.getProfile(o.player) ? ` (${repo.getProfile(o.player)!.ign})` : ''}`, inline: true });
    if (o.gamemode) f.push({ name: 'Gamemode', value: o.gamemode, inline: true });
    if (o.oldTier || o.newTier) f.push({ name: 'Tier change', value: `${o.oldTier ?? '—'} → ${o.newTier ?? '—'}`, inline: true });
    if (o.fields) f.push(...o.fields);
    if (f.length) e.addFields(f.slice(0, 25));
    await ch.send({ embeds: [e], allowedMentions: { parse: [] } });
  } catch (err: any) {
    log.warn('Failed to write to log channel:', err?.message ?? err);
  }
}
