import { GuildMember, PermissionFlagsBits } from 'discord.js';
import * as repo from '../db/repo';
import { config } from '../config';

export const HIGH_RESULT = 'high_result';

export function isAdmin(m: GuildMember): boolean {
  return m.id === m.guild.ownerId || m.permissions.has(PermissionFlagsBits.Administrator);
}
/** The Discord tester role is the source of truth (the DB assignment is kept in sync with it). */
export function hasTesterRole(m: GuildMember, gmId: number): boolean {
  const map = repo.getRoleMapping('tester', gmId, '');
  return !!map && m.roles.cache.has(map.role_id);
}
export function canTest(m: GuildMember, gmId: number): boolean {
  return isAdmin(m) || hasTesterRole(m, gmId);
}
/** Admins, configured queue-manager roles, or the gamemode's testers. */
export function canManageQueue(m: GuildMember, gmId: number): boolean {
  return canTest(m, gmId) || config.queueManagerRoleIds.some((id) => m.roles.cache.has(id));
}
export function canHighResult(m: GuildMember): boolean {
  return repo.hasPermission(m.id, HIGH_RESULT);
}
/** Syncs DB tester assignments to the member's actual Discord roles. */
export function syncTesterAssignments(m: GuildMember): void {
  for (const map of repo.listAllRoleMappings('tester')) {
    const has = m.roles.cache.has(map.role_id);
    const inDb = repo.isTesterDb(m.id, map.gamemode_id);
    if (has && !inDb) { repo.upsertUser(m.id, m.user.username); repo.addTester(m.id, map.gamemode_id, 'role-sync'); }
    else if (!has && inDb) repo.removeTester(m.id, map.gamemode_id);
  }
}
