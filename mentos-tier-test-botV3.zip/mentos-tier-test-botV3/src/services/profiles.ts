import * as repo from '../db/repo';
import { AppError } from '../errors';
import { appEvents } from '../events';

export function validateIgn(raw: string): string {
  const ign = (raw ?? '').trim();
  if (!ign) throw new AppError('Your Minecraft IGN is required.');
  if (!/^[A-Za-z0-9_]{3,16}$/.test(ign)) {
    throw new AppError('Your IGN must be 3–16 characters: letters, numbers and underscores only.');
  }
  return ign;
}

/** Throws if another player already owns this IGN. */
export function assertIgnAvailable(userId: string, ign: string): void {
  const owner = repo.getProfileByIgn(ign);
  if (owner && owner.discord_id !== userId) throw new AppError(`The IGN **${ign}** is already linked to another player.`);
}

/**
 * Saves a COMPLETE profile (IGN + at least one gamemode) in one transaction. The Discord identity comes from the
 * interaction, never from user input. Incomplete data is rejected before anything is written.
 */
export function saveProfileComplete(userId: string, username: string, rawIgn: string, gmIds: number[], source: 'discord' | 'web' = 'discord') {
  const ign = validateIgn(rawIgn);
  assertIgnAvailable(userId, ign);
  const valid = [...new Set(gmIds)].filter((id) => repo.getGamemode(id)?.active);
  if (!valid.length) throw new AppError('Select at least one gamemode you want to be tested in.');
  const before = repo.getProfile(userId);
  const oldIds = repo.getProfileGamemodeIds(userId);
  const r = repo.saveProfileWithGamemodes(userId, username, ign, valid);
  appEvents.emit('profile', { userId, username, ign, oldIgn: before?.ign, created: r.created, source, gamemodeIds: valid, oldGamemodeIds: oldIds });
  return { ...r, ign, gamemodeIds: valid };
}

/** Website: players may only change their IGN (gamemodes are chosen in Discord so roles stay in sync). */
export function saveIgnFromWeb(userId: string, username: string, rawIgn: string) {
  const ign = validateIgn(rawIgn);
  const before = repo.getProfile(userId);
  if (!before) throw new AppError('Create your profile in Discord first (the #profile channel) — gamemode selection happens there.');
  assertIgnAvailable(userId, ign);
  const r = repo.saveProfile(userId, username, ign);
  appEvents.emit('profile', { userId, username, ign, oldIgn: before.ign, created: false, source: 'web' });
  return { ...r, ign };
}
