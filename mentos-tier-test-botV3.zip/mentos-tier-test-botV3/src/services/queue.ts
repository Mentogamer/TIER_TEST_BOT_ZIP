import { ChannelType, Guild, GuildMember, PermissionFlagsBits as P } from 'discord.js';
import * as repo from '../db/repo';
import { AppError, NeedsProfileError, ProfileRequiredError } from '../errors';
import { config } from '../config';
import { COLORS, channelSlug } from '../constants';
import { log } from '../logger';
import { logEvent } from './logs';
import { ticketButtons, ticketEmbed } from '../discord/ticketUi';
import { base } from '../discord/embeds';
import { refreshQueuePanel } from '../discord/panel';

/* ---------- per-gamemode lock: serialises joins / drags / results ---------- */
const chains = new Map<number, Promise<unknown>>();
export function withLock<T>(key: number, fn: () => Promise<T>): Promise<T> {
  const prev = chains.get(key) ?? Promise.resolve();
  const next = prev.catch(() => undefined).then(fn);
  chains.set(key, next.catch(() => undefined));
  return next;
}

const isUnknownMember = (e: any) => e?.code === 10007 || e?.code === 10013;
const isSnowflake = (s?: string) => !!s && /^\d{15,25}$/.test(s);
const touchPanel = (guild: Guild, gmId: number) => refreshQueuePanel(guild, gmId, true).catch(() => undefined);

export interface JoinResult { position: number; gamemode: repo.Gamemode }

export async function joinQueue(guild: Guild, user: { id: string; username: string }, gmId: number): Promise<JoinResult> {
  const r = await withLock(gmId, async () => {
    const gm = repo.getGamemode(gmId);
    if (!gm || !gm.active) throw new AppError('That gamemode is not active.');
    const profile = repo.getProfile(user.id);
    if (!profile || !profile.ign) throw new ProfileRequiredError(repo.getConfig('profile_channel'));
    if (!repo.profileHasGamemode(user.id, gmId)) {
      throw new NeedsProfileError(
        `Your profile doesn't include **${gm.name}**.\nEdit your profile in ${repo.getConfig('profile_channel') ? `<#${repo.getConfig('profile_channel')}>` : '#profile'} and select it.`,
        'Edit Profile');
    }
    if (!repo.isQueueOpen(gmId)) throw new AppError(`The **${gm.name}** queue is currently **closed**.`);
    if (repo.getWaitingEntry(gmId, user.id)) throw new AppError(`You are already in the **${gm.name}** queue.`);
    const active = repo.getActiveTicketForUser(user.id);
    if (active) throw new AppError(`You already have an active testing ticket: <#${active.channel_id}>`);

    repo.upsertUser(user.id, user.username);
    repo.addQueueEntry(gmId, user.id);
    return { position: repo.getWaitingEntry(gmId, user.id)?.position ?? 0, gamemode: gm };
  });
  await touchPanel(guild, gmId);
  await logEvent(guild, { channel: 'queue', title: '➕ Player joined queue', color: COLORS.success, player: user.id, gamemode: r.gamemode.name, fields: [{ name: 'Position', value: `#${r.position}`, inline: true }] });
  return r;
}

export async function leaveQueue(guild: Guild, userId: string, gmId: number): Promise<repo.Gamemode> {
  const gm = await withLock(gmId, async () => {
    const g = repo.getGamemode(gmId);
    const entry = repo.getWaitingEntry(gmId, userId);
    if (!g || !entry) throw new AppError('You are not waiting in that queue.');
    repo.setEntryStatus(entry.id, 'left');
    return g;
  });
  await touchPanel(guild, gmId);
  await logEvent(guild, { channel: 'queue', title: '➖ Player left queue', color: COLORS.warn, player: userId, gamemode: gm.name });
  return gm;
}

export async function clearQueueFor(guild: Guild, gmId: number, by: string): Promise<number> {
  const gm = repo.getGamemode(gmId)!;
  const n = await withLock(gmId, async () => repo.clearQueue(gmId));
  await touchPanel(guild, gmId);
  await logEvent(guild, { channel: 'queue', title: '🧹 Queue cleared', color: COLORS.warn, user: by, gamemode: gm.name, description: `${n} player(s) removed.` });
  return n;
}

/* ------------------------------ /drag ------------------------------ */
export interface DragResult { ticket: repo.Ticket; channelId: string; userId: string; ign: string; gamemode: repo.Gamemode }

function uniqueChannelName(guild: Guild, parentId: string, base: string): string {
  const taken = new Set(guild.channels.cache.filter((c: any) => c.parentId === parentId).map((c: any) => c.name));
  if (!taken.has(base)) return base;
  for (let n = 2; n < 100; n++) { const nm = `${base.slice(0, 95)}-${n}`; if (!taken.has(nm)) return nm; }
  return `${base.slice(0, 80)}-${Date.now() % 100000}`;
}

/**
 * Pulls the FIRST player of the gamemode queue into a private ticket.
 * Order of operations protects the queue: channel is created first; the DB transaction that records the
 * ticket AND removes the queue entry runs only afterwards; any failure afterwards restores the entry.
 * The per-gamemode lock plus the unique index on test_tickets.queue_entry_id stop double tickets.
 */
export async function dragPlayer(guild: Guild, tester: GuildMember, gmId: number): Promise<DragResult> {
  const result = await withLock(gmId, async () => {
    const gm = repo.getGamemode(gmId);
    if (!gm || !gm.active) throw new AppError('That gamemode is not active.');
    const catId = repo.getConfig('tickets_category');
    const category: any = catId ? (guild.channels.cache.get(catId) ?? (await guild.channels.fetch(catId).catch(() => null))) : null;
    if (!category) throw new AppError('The **TIER TEST TICKET** category is missing. An admin must run `/setup-tier-testing`.');
    if (category.children?.cache.size >= 50) throw new AppError("The ticket category is full (Discord's limit is 50 channels). Close some tickets first.");
    if (guild.channels.cache.size >= 495) throw new AppError("The server is at Discord's channel limit. Delete unused channels first.");

    for (let guard = 0; guard < 25; guard++) {
      const next = repo.listWaiting(gmId)[0];
      if (!next) throw new AppError(`There are no players waiting in the **${gm.name}** queue.`);

      const profile = repo.getProfile(next.discord_id);
      if (!profile) { repo.setEntryStatus(next.id, 'cancelled'); continue; }
      let member: GuildMember;
      try { member = await guild.members.fetch(next.discord_id); }
      catch (e: any) {
        if (!isUnknownMember(e)) throw e;
        repo.setEntryStatus(next.id, 'cancelled');
        await logEvent(guild, { channel: 'queue', title: '⚠️ Queue entry removed', color: COLORS.warn, player: next.discord_id, gamemode: gm.name, description: 'Player is no longer in the server.' });
        continue;
      }
      if (repo.getActiveTicketForUser(member.id)) { repo.setEntryStatus(next.id, 'cancelled'); continue; }

      const talk = [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.AttachFiles, P.EmbedLinks];
      const overwrites: any[] = [
        { id: guild.roles.everyone.id, deny: [P.ViewChannel] },
        { id: member.id, allow: talk },
        { id: guild.members.me!.id, allow: [...talk, P.ManageChannels, P.ManageMessages] },
      ];
      if (tester.id !== member.id) overwrites.push({ id: tester.id, allow: talk });
      for (const id of config.staffRoleIds) if (guild.roles.cache.has(id)) overwrites.push({ id, allow: talk });

      const name = uniqueChannelName(guild, category.id, `${channelSlug(gm.name)}-${channelSlug(profile.ign)}`.slice(0, 95));
      // 1) create the channel (if this throws the queue entry is untouched)
      const channel: any = await guild.channels.create({
        name, type: ChannelType.GuildText, parent: category.id,
        topic: `${gm.name} tier test | IGN ${profile.ign} | player ${member.id}`,
        permissionOverwrites: overwrites, reason: `/drag ${gm.name} by ${tester.user.tag}`,
      });

      // 2) record ticket + remove from queue atomically
      let ticket: repo.Ticket;
      try {
        ticket = repo.recordDraggedTicket({
          entryId: next.id, channelId: channel.id, userId: member.id, gamemodeId: gm.id,
          testerId: tester.id, lastTier: repo.getExpectedOldTier(member.id, gm.id),
        });
      } catch (e) {
        await channel.delete('Ticket could not be recorded').catch(() => {});
        throw e;
      }
      repo.upsertUser(tester.id, tester.user.username);

      // 3) post the ticket; if that fails, undo everything and keep the player's queue spot
      try {
        const msg = await channel.send({
          content: `<@${member.id}> <@${tester.id}>`,
          embeds: [ticketEmbed(ticket)], components: ticketButtons(ticket),
          allowedMentions: { users: [member.id, tester.id] },
        });
        repo.updateTicket(ticket.id, { message_id: msg.id });
      } catch (e) {
        repo.revertDraggedTicket(ticket.id, next.id);
        await channel.delete('Ticket message failed').catch(() => {});
        throw e;
      }
      return { ticket: repo.getTicket(ticket.id)!, channelId: channel.id as string, userId: member.id, ign: profile.ign, gamemode: gm };
    }
    throw new AppError('No eligible player could be pulled from the queue. Try again.');
  });

  await touchPanel(guild, gmId);
  await logEvent(guild, {
    channel: 'ticket', title: '🎫 Ticket created (/drag)', color: COLORS.primary, user: tester.id, player: result.userId,
    gamemode: result.gamemode.name, fields: [{ name: 'Ticket', value: `<#${result.channelId}> (#${result.ticket.id})`, inline: true }],
  });
  // Tell the player (DM may be closed; the ticket mention already pinged them)
  return result;
}

/** Re-renders the embed + buttons of a ticket's main message. */
export async function refreshTicketMessage(guild: Guild, ticketId: number): Promise<void> {
  const t = repo.getTicket(ticketId);
  if (!t?.message_id) return;
  try {
    const ch: any = guild.channels.cache.get(t.channel_id) ?? (await guild.channels.fetch(t.channel_id).catch(() => null));
    if (!ch) return;
    const msg = await ch.messages.fetch(t.message_id);
    await msg.edit({ embeds: [ticketEmbed(t)], components: ticketButtons(t) });
  } catch (e: any) { log.warn('Could not refresh ticket message:', e?.message); }
}

export function scheduleChannelDeletion(guild: Guild, channelId: string, seconds = config.ticketCloseDelaySec): void {
  setTimeout(async () => {
    try {
      const ch = guild.channels.cache.get(channelId) ?? (await guild.channels.fetch(channelId).catch(() => null));
      if (ch) await ch.delete('Tier test ticket finished');
    } catch (e: any) { log.warn('Could not delete ticket channel:', e?.message); }
  }, seconds * 1000);
}

/** Cancels an active ticket (no result). Results and logs are never deleted, only the channel. */
export async function cancelTicket(guild: Guild, ticket: repo.Ticket, byId: string | undefined, reason: string, deleteChannel = true): Promise<void> {
  const gm = repo.getGamemode(ticket.gamemode_id)!;
  await withLock(gm.id, async () => {
    const fresh = repo.getTicket(ticket.id);
    if (!fresh || !repo.ACTIVE_STATUSES.includes(fresh.status)) return;
    repo.cancelTicketDb(ticket.id);
    await logEvent(guild, {
      channel: 'ticket', title: '🚫 Ticket closed (no result)', color: COLORS.warn, user: isSnowflake(byId) ? byId : undefined,
      player: ticket.discord_id, gamemode: gm.name, description: reason,
    });
    if (deleteChannel) {
      const ch: any = guild.channels.cache.get(ticket.channel_id);
      if (ch?.isTextBased()) {
        await refreshTicketMessage(guild, ticket.id);
        await ch.send({ embeds: [base(COLORS.warn, '🚫 Ticket closed', `${reason}\nThis channel will be deleted shortly.`)] }).catch(() => {});
      }
      scheduleChannelDeletion(guild, ticket.channel_id, 5);
    }
  });
}

/** Called when a member leaves the server: drop them from queues and cancel their ticket. */
export async function handleMemberLeft(guild: Guild, userId: string): Promise<void> {
  for (const e of repo.getWaitingEntriesForUser(userId)) {
    await withLock(e.gamemode_id, async () => { repo.setEntryStatus(e.id, 'cancelled'); });
    await touchPanel(guild, e.gamemode_id);
  }
  const t = repo.getActiveTicketForUser(userId);
  if (t) await cancelTicket(guild, t, undefined, 'The player left the server.');
}
