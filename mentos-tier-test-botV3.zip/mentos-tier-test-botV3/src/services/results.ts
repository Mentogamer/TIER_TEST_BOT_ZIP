import { Guild, GuildMember } from 'discord.js';
import * as repo from '../db/repo';
import { AppError } from '../errors';
import { COLORS, DEFAULT_TIER, TIER_LADDER, normalizeTier, tierLabel, tierRank } from '../constants';
import { logEvent } from './logs';
import { applyTierRoles } from './roles';
import { canHighResult, canTest, isAdmin } from './permissions';
import { scheduleChannelDeletion, withLock } from './queue';
import { isHighTier } from './highResult';
import { announceResult } from './announcements';
import { scheduleTierListRefresh } from './tierlist';
import { base } from '../discord/embeds';
import { config } from '../config';
import { log } from '../logger';

export { isHighTier };

export interface ResultSummary {
  resultId: number; high: boolean; correction: boolean; userId: string; ign: string; gamemode: repo.Gamemode;
  oldTier: string; newTier: string; testerId: string; ticketChannelId?: string;
  roleError?: string; announced: { result: string; high: string };
}

const errText = (e: any) => (e?.message ?? String(e)).slice(0, 300);

/** Applies the roles for the player's CURRENT tier. Returns an error text or null. Records the outcome. */
export async function syncResultRoles(guild: Guild, userId: string, gm: repo.Gamemode, resultId?: number): Promise<string | null> {
  const latest = repo.getLatestResult(userId, gm.id);
  const target = await guild.members.fetch(userId).catch(() => null);
  const id = resultId ?? latest?.id;
  if (!target) { if (id) repo.setResultRoleStatus(id, 'failed', 'Player is not in the server.'); return 'The player is not in the server.'; }
  try {
    await applyTierRoles(guild, target, gm, latest?.new_tier ?? DEFAULT_TIER);
    repo.markRolesOk(userId, gm.id);
    return null;
  } catch (e: any) {
    const text = e?.code === 50013 ? 'Missing permissions / my role is below the tier role.' : errText(e);
    if (id) repo.setResultRoleStatus(id, 'failed', text);
    return text;
  }
}

export async function submitResult(o: {
  guild: Guild; tester: GuildMember; userId: string; gamemode: repo.Gamemode; tier: string; high: boolean;
  ticket?: repo.Ticket; correction?: { reason?: string };
}): Promise<ResultSummary> {
  const { guild, tester, gamemode: gm } = o;
  const tier = normalizeTier(o.tier);
  if (!tier || !TIER_LADDER.includes(tier)) throw new AppError(`**${o.tier}** is not a valid tier. Valid: ${TIER_LADDER.join(', ')}.`);
  if (!gm.active) throw new AppError(`**${gm.name}** is not an active gamemode.`);
  const userId = o.userId;
  if (tester.id === userId) throw new AppError('You cannot submit a result for yourself.');

  // Authorisation. High results (explicit /high-result, or a tier that meets the criteria) need the separate permission.
  const high = o.high || isHighTier(tier);
  if (o.correction) {
    if (!isAdmin(tester)) throw new AppError('Only administrators can correct a result.');
  } else if (high) {
    if (!canHighResult(tester)) {
      throw new AppError(o.high ? 'You do not have the **High Result** permission.'
        : `**${tier}** counts as a **high result** (minimum: ${repo.getHighMinTier()}). You need the **High Result** permission — ask someone who has it to use \`/high-result\`.`);
    }
  } else if (!canTest(tester, gm.id)) {
    throw new AppError(`You are not allowed to submit **${gm.name}** results. You need the **🧪 ${gm.name} Tester** role.`);
  }

  const profile = repo.getProfile(userId);
  if (!profile || !profile.ign) throw new AppError(`<@${userId}> has no saved profile / Minecraft IGN. They must create one in the profile channel first.`);

  const summary = await withLock(gm.id, async () => {
    let ticket = o.ticket ?? repo.getActiveTicketForUser(userId);
    if (ticket && ticket.gamemode_id !== gm.id) ticket = undefined;
    if (ticket) {
      const fresh = repo.getTicket(ticket.id);
      ticket = fresh && repo.ACTIVE_STATUSES.includes(fresh.status) ? fresh : undefined;
    }
    let correctsId: number | null = null;
    if (o.correction) {
      correctsId = repo.getLatestResult(userId, gm.id)?.id ?? null;
      if (!correctsId) throw new AppError(`<@${userId}> has no recorded **${gm.name}** result to correct.`);
    }
    const oldTier = repo.getPlayerTier(userId, gm.id) ?? DEFAULT_TIER;
    repo.upsertUser(tester.id, tester.user.username);
    const resultId = repo.applyResult({
      ticketId: ticket?.id ?? null, userId, gamemodeId: gm.id, oldTier, newTier: tier, testerId: tester.id,
      isHigh: high, ign: profile.ign, correctsId, reason: o.correction?.reason ?? null,
    });
    return { resultId, oldTier, ticket } as const;
  });

  // Discord side. The result is already saved; role/announcement problems are recorded and can be retried.
  const roleError = (await syncResultRoles(guild, userId, gm, summary.resultId)) ?? undefined;
  const announced = await announceResult(guild, summary.resultId);

  await logEvent(guild, {
    channel: 'result',
    title: o.correction ? '✏️ Result corrected' : high ? '🔥 HIGH RESULT' : '🏆 Result',
    color: o.correction ? COLORS.warn : high ? COLORS.high : COLORS.success,
    user: tester.id, player: userId, gamemode: gm.name, oldTier: summary.oldTier, newTier: tier,
    description: o.correction?.reason ? `Reason: ${o.correction.reason}` : undefined,
    fields: [
      { name: 'Result ID', value: `#${summary.resultId}`, inline: true },
      { name: 'Roles', value: roleError ? `❌ ${roleError}` : '✅ updated', inline: true },
      ...(summary.ticket ? [{ name: 'Ticket', value: `<#${summary.ticket.channel_id}>`, inline: true }] : []),
    ],
  });
  if (roleError) {
    await logEvent(guild, { title: '⚠️ Role update failed — retry with /result-retry', color: COLORS.error, player: userId, gamemode: gm.name, description: roleError });
  }

  if (summary.ticket) {
    try {
      const ch: any = guild.channels.cache.get(summary.ticket.channel_id);
      if (ch?.isTextBased()) {
        await ch.send({
          embeds: [base(high ? COLORS.high : COLORS.success, `${high ? '🔥 High Result' : '🏆 Result'} — ${profile.ign}`,
            `${gm.emoji} **${gm.name}**\n${tierLabel(summary.oldTier, gm.name)} → **${tierLabel(tier, gm.name)}**\nTester: <@${tester.id}>\n\nThis ticket will close in ${config.ticketCloseDelaySec}s.`)],
        });
      }
      scheduleChannelDeletion(guild, summary.ticket.channel_id);
    } catch (e: any) { log.warn('Could not post result in ticket:', e?.message); }
  }
  scheduleTierListRefresh(guild);

  return {
    resultId: summary.resultId, high, correction: !!o.correction, userId, ign: profile.ign, gamemode: gm,
    oldTier: summary.oldTier, newTier: tier, testerId: tester.id, ticketChannelId: summary.ticket?.channel_id, roleError, announced,
  };
}

/** Retries failed role updates and missing announcements (never duplicates an announcement). */
export async function retryPending(guild: Guild, opts: { userId?: string; allowed?: (gmId: number) => boolean } = {}):
  Promise<{ rolesFixed: number; rolesFailed: string[]; announced: number }> {
  const since = new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString();
  const rows = repo.listPendingResults(since, opts.userId);
  const out = { rolesFixed: 0, rolesFailed: [] as string[], announced: 0 };
  const done = new Set<string>();
  for (const r of rows) {
    if (opts.allowed && !opts.allowed(r.gamemode_id)) continue;
    const gm = repo.getGamemode(r.gamemode_id);
    if (!gm) continue;
    const key = `${r.discord_id}:${r.gamemode_id}`;
    if (r.role_status === 'failed' && !done.has(key)) {
      done.add(key);
      const err = await syncResultRoles(guild, r.discord_id, gm);
      if (err) out.rolesFailed.push(`<@${r.discord_id}> ${gm.name}: ${err}`); else out.rolesFixed++;
    }
    const a = await announceResult(guild, r.id);
    if (a.result === 'sent' || a.high === 'sent') out.announced++;
  }
  return out;
}
