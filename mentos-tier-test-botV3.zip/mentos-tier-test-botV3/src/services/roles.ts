import { Guild, GuildMember, Role } from 'discord.js';
import * as repo from '../db/repo';
import {
  TIER_LADDER, TIER_ROLE_COLORS, TESTER_ROLE_COLOR, UNRANKED, DEFAULT_TIER, looseKey, tierRoleName, testerRoleName,
} from '../constants';
import { AppError } from '../errors';
import { botRolePositionProblem } from './gamemodeSetup';
import { log } from '../logger';

export interface RoleOutcome { name: string; created: boolean; role?: Role; error?: string }

async function getRole(guild: Guild, id: string): Promise<Role | null> {
  return guild.roles.cache.get(id) ?? (await guild.roles.fetch(id).catch(() => null));
}

/** Lets testers see #testing-tickets. */
async function grantTesterChannelAccess(guild: Guild, role: Role): Promise<void> {
  const id = repo.getConfig('tickets_channel');
  const ch: any = id ? guild.channels.cache.get(id) : null;
  if (!ch?.permissionOverwrites) return;
  try { await ch.permissionOverwrites.edit(role, { ViewChannel: true, ReadMessageHistory: true, SendMessages: false }); }
  catch (e: any) { log.warn('Could not grant tester access to #testing-tickets:', e?.message); }
}

/**
 * Finds the role for (kind, gamemode, tier) or creates it. Order: stored mapping -> existing role with the
 * exact name -> create. Never creates a duplicate.
 */
export async function ensureRole(guild: Guild, kind: 'tier' | 'tester', gm: repo.Gamemode, tier = ''): Promise<{ role: Role; created: boolean }> {
  const name = kind === 'tier' ? tierRoleName(tier, gm.name) : testerRoleName(gm.name);
  const mapped = repo.getRoleMapping(kind, gm.id, tier);
  if (mapped) {
    const r = await getRole(guild, mapped.role_id);
    if (r) return { role: r, created: false };
  }
  const found = guild.roles.cache.find((r) => looseKey(r.name) === looseKey(name));
  if (found) {
    repo.setRoleMapping(kind, gm.id, tier, found.id);
    if (kind === 'tester') await grantTesterChannelAccess(guild, found);
    return { role: found, created: false };
  }
  const role = await guild.roles.create({
    name,
    color: kind === 'tier' ? TIER_ROLE_COLORS[tier] : TESTER_ROLE_COLOR,
    mentionable: kind === 'tester',
    hoist: false,
    permissions: [],
    reason: `Mento's Tier Test Bot: ${kind} role for ${gm.name}`,
  });
  repo.setRoleMapping(kind, gm.id, tier, role.id);
  if (kind === 'tester') await grantTesterChannelAccess(guild, role);
  return { role, created: true };
}

export async function createTierRoles(guild: Guild, gm: repo.Gamemode): Promise<RoleOutcome[]> {
  const out: RoleOutcome[] = [];
  for (const tier of TIER_LADDER) {
    const name = tierRoleName(tier, gm.name);
    try { const r = await ensureRole(guild, 'tier', gm, tier); out.push({ name, created: r.created, role: r.role }); }
    catch (e: any) { out.push({ name, created: false, error: e?.message ?? 'unknown error' }); }
  }
  return out;
}

export async function createTesterRole(guild: Guild, gm: repo.Gamemode): Promise<RoleOutcome> {
  const name = testerRoleName(gm.name);
  try { const r = await ensureRole(guild, 'tester', gm); return { name, created: r.created, role: r.role }; }
  catch (e: any) { return { name, created: false, error: e?.message ?? 'unknown error' }; }
}

/** Existing Discord roles that belong to the tier ladder of a gamemode (by mapping or exact name). */
export async function findTierRoles(guild: Guild, gm: repo.Gamemode): Promise<{ tier: string; role: Role }[]> {
  const out: { tier: string; role: Role }[] = [];
  for (const tier of TIER_LADDER) {
    const mapped = repo.getRoleMapping('tier', gm.id, tier);
    let role = mapped ? await getRole(guild, mapped.role_id) : null;
    if (!role) role = guild.roles.cache.find((r) => looseKey(r.name) === looseKey(tierRoleName(tier, gm.name))) ?? null;
    if (role) out.push({ tier, role });
  }
  return out;
}

export async function deleteTierRoles(guild: Guild, gm: repo.Gamemode): Promise<{ deleted: string[]; failed: string[] }> {
  const deleted: string[] = [];
  const failed: string[] = [];
  for (const { role } of await findTierRoles(guild, gm)) {
    try { const n = role.name; await role.delete(`Mento's Tier Test Bot: tier roles of ${gm.name} deleted`); deleted.push(n); }
    catch { failed.push(role.name); }
  }
  repo.deleteRoleMappings('tier', gm.id);
  return { deleted, failed };
}

/**
 * Gives the member the tier role for `newTier` (gamemode-specific, e.g. "HT5-UHC") and removes only the OTHER tier
 * roles of THAT gamemode. Roles of other gamemodes and unrelated roles are never touched. Throws a clear AppError
 * when Discord permissions / role hierarchy make the change impossible.
 */
export async function applyTierRoles(guild: Guild, member: GuildMember, gm: repo.Gamemode, newTier: string) {
  const reason = `Tier result (${gm.name}): ${newTier}`;
  if (!guild.members.me?.permissions.has('ManageRoles')) throw new AppError('I am missing the **Manage Roles** permission.');
  const mappings = repo.listRoleMappings('tier', gm.id);
  let newRole: Role | null = null;
  if (newTier !== UNRANKED && newTier !== DEFAULT_TIER) newRole = (await ensureRole(guild, 'tier', gm, newTier)).role;
  const removeRoles = mappings
    .filter((m) => m.tier !== newTier && member.roles.cache.has(m.role_id))
    .map((m) => guild.roles.cache.get(m.role_id)).filter((r): r is Role => !!r);
  const needsAdd = !!newRole && !member.roles.cache.has(newRole.id);
  for (const r of [...(needsAdd ? [newRole!] : []), ...removeRoles]) {
    const problem = botRolePositionProblem(guild, r);
    if (problem) throw new AppError(problem);
  }
  if (removeRoles.length) await member.roles.remove(removeRoles.map((r) => r.id), reason);
  if (needsAdd) await member.roles.add(newRole!, reason);
  return { removed: removeRoles.map((r) => r.id), added: needsAdd ? newRole!.id : null };
}
