import { EmbedBuilder, Guild } from 'discord.js';
import * as repo from '../db/repo';
import { COLORS, DEFAULT_TIER, TIER_LADDER, tierRank, BRAND } from '../constants';
import { logEvent } from './logs';
import { log } from '../logger';

const esc = (s: string) => s.replace(/[\\_*~`|>]/g, '\\$&');

/** One embed (or several if the list is long) per gamemode, grouped by the LATEST recorded tier. */
function gamemodeEmbeds(gm: repo.Gamemode): EmbedBuilder[] {
  const rows = repo.getTierListRows(gm.id);
  const groups = new Map<string, string[]>();
  for (const r of rows) {
    const t = r.tier ?? DEFAULT_TIER;
    if (!groups.has(t)) groups.set(t, []);
    groups.get(t)!.push(esc(r.ign));
  }
  const order = [...TIER_LADDER].reverse().concat([DEFAULT_TIER]).filter((t) => groups.has(t));
  const lines = order.map((t) => `**${t}** — ${groups.get(t)!.join(', ')}`);
  const pages: string[] = [];
  let cur = '';
  for (const line of lines.length ? lines : ['*No players yet.*']) {
    // a single tier line can itself be long: split it on commas
    const parts = line.length > 3800 ? line.match(/.{1,3800}(,\s|$)/g) ?? [line] : [line];
    for (const part of parts) {
      if ((cur + part).length > 3800) { pages.push(cur); cur = ''; }
      cur += part + '\n';
    }
  }
  if (cur) pages.push(cur);
  return pages.map((d, i) => new EmbedBuilder().setColor(COLORS.primary)
    .setTitle(`${gm.emoji} ${gm.name}${i ? ' (cont.)' : ''}`).setDescription(d.trim())
    .setFooter({ text: `${rows.length} player(s)` }));
}

/** Packs embeds into messages within Discord's limits (10 embeds / 6000 chars per message). */
export function buildTierListMessages(): EmbedBuilder[][] {
  const header = new EmbedBuilder().setColor(COLORS.high).setTitle('🏆 Tier List')
    .setDescription(`Latest recorded tier of every player, per gamemode. Players who selected a gamemode but were never tested are **${DEFAULT_TIER}**.`)
    .setFooter({ text: BRAND }).setTimestamp();
  const all = [header, ...repo.listGamemodes(true).flatMap(gamemodeEmbeds)];
  const messages: EmbedBuilder[][] = [];
  let cur: EmbedBuilder[] = [];
  let size = 0;
  for (const e of all) {
    const len = (e.data.title?.length ?? 0) + (e.data.description?.length ?? 0) + (e.data.footer?.text.length ?? 0);
    if (cur.length && (cur.length >= 5 || size + len > 5000)) { messages.push(cur); cur = []; size = 0; }
    cur.push(e); size += len;
  }
  if (cur.length) messages.push(cur);
  return messages;
}

/** Edits the existing tier-list messages in place, adds new ones if needed, removes surplus bot messages. */
export async function publishTierList(guild: Guild, by?: string): Promise<{ messages: number; players: number } | null> {
  const chId = repo.getConfig('tierlist_channel');
  const ch: any = chId ? (guild.channels.cache.get(chId) ?? (await guild.channels.fetch(chId).catch(() => null))) : null;
  if (!ch?.isTextBased()) return null;
  const pages = buildTierListMessages();
  let ids: string[] = [];
  try { ids = JSON.parse(repo.getConfig('tierlist_msgs') ?? '[]'); } catch { ids = []; }
  const newIds: string[] = [];
  for (let i = 0; i < pages.length; i++) {
    const payload = { content: '', embeds: pages[i], allowedMentions: { parse: [] as any[] } };
    const existing = ids[i] ? await ch.messages.fetch(ids[i]).catch(() => null) : null;
    if (existing) { await existing.edit(payload); newIds.push(existing.id); }
    else newIds.push((await ch.send(payload)).id);
  }
  for (const extra of ids.slice(pages.length)) await ch.messages.fetch(extra).then((m: any) => m.delete()).catch(() => {});
  repo.setConfig('tierlist_msgs', JSON.stringify(newIds));
  repo.setConfig('tierlist_updated', new Date().toISOString());
  const players = (repo.getStats() as any).players;
  await logEvent(guild, { channel: 'result', title: '📋 Tier list updated', user: by, description: `${newIds.length} message(s) in <#${ch.id}>.` });
  return { messages: newIds.length, players };
}

/** Debounced refresh after results (only once a tier list has been published). */
let timer: ReturnType<typeof setTimeout> | undefined;
export function scheduleTierListRefresh(guild: Guild): void {
  if (!repo.getConfig('tierlist_msgs')) return;
  clearTimeout(timer);
  timer = setTimeout(() => { publishTierList(guild).catch((e) => log.warn('Tier list refresh failed:', e?.message)); }, 4000);
}
void tierRank;
