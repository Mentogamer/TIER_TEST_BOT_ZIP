import crypto from 'node:crypto';
import path from 'node:path';
import express, { NextFunction, Request, Response } from 'express';
import * as repo from '../db/repo';
import { assertWebConfig, config } from '../config';
import { AppError } from '../errors';
import { BRAND, TIER_LADDER } from '../constants';
import { saveIgnFromWeb } from '../services/profiles';
import { log } from '../logger';

const SESSION_TTL_MS = 7 * 24 * 3600 * 1000;
const secure = config.webPublicUrl.startsWith('https://');

/* ------------------------------ cookies / signing ------------------------------ */
const hmac = (v: string) => crypto.createHmac('sha256', config.sessionSecret).update(v).digest('hex');
const sign = (v: string) => `${v}.${hmac(v)}`;
function unsign(s?: string): string | null {
  if (!s) return null;
  const i = s.lastIndexOf('.');
  if (i < 1) return null;
  const v = s.slice(0, i);
  const a = Buffer.from(s.slice(i + 1));
  const b = Buffer.from(hmac(v));
  return a.length === b.length && crypto.timingSafeEqual(a, b) ? v : null;
}
function parseCookies(h?: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const part of (h ?? '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) { try { out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim()); } catch { /* skip */ } }
  }
  return out;
}
function setCookie(res: Response, name: string, value: string, maxAgeSec: number) {
  res.append('Set-Cookie', `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAgeSec}${secure ? '; Secure' : ''}`);
}

interface Req extends Request { session?: { id: string; discord_id: string; username: string } }

/* ------------------------------ tiny rate limiter ------------------------------ */
const hits = new Map<string, number[]>();
function limited(key: string, max: number, windowMs: number): boolean {
  const t = Date.now();
  const arr = (hits.get(key) ?? []).filter((x) => t - x < windowMs);
  arr.push(t);
  hits.set(key, arr);
  return arr.length > max;
}

export function startWeb() {
  assertWebConfig();
  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '20kb' }));

  app.use((req: Req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'same-origin');
    const sid = unsign(parseCookies(req.headers.cookie).sid);
    if (sid) req.session = repo.getSession(sid);
    next();
  });

  // CSRF: state-changing requests must come from our own origin
  app.use((req, res, next) => {
    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
      const origin = req.headers.origin;
      if (origin && new URL(origin).host !== req.headers.host) return void res.status(403).json({ error: 'Cross-origin request blocked.' });
    }
    next();
  });

  /* ------------------------------ public API ------------------------------ */
  app.get('/api/health', (_req, res) => { res.json({ ok: true, brand: BRAND }); });

  app.get('/api/config', (_req, res) => {
    res.json({
      brand: BRAND,
      tiers: [...TIER_LADDER].reverse(),
      gamemodes: repo.listGamemodes(true).map((g) => ({ id: g.id, name: g.name, emoji: g.emoji })),
      loginAvailable: !!config.clientSecret,
    });
  });

  app.get('/api/tierlist/:gamemode', (req, res) => {
    const gm = repo.findGamemode(String(req.params.gamemode));
    if (!gm || !gm.active) return void res.status(404).json({ error: 'Unknown gamemode.' });
    const rows = repo.getTierList(gm.id);
    const grouped = [...TIER_LADDER].reverse().map((t) => ({ tier: t, players: rows.filter((r) => r.tier === t).map((r) => r.ign) }));
    res.json({ gamemode: { id: gm.id, name: gm.name, emoji: gm.emoji }, tiers: grouped, total: rows.length });
  });

  app.get('/api/leaderboard', (_req, res) => { res.json({ players: repo.getOverallLeaderboard(100) }); });

  app.get('/api/recent', (_req, res) => {
    res.json({ results: repo.listResults({ limit: 20 }).map(({ tester_id, ...r }) => r) });
  });

  app.get('/api/search', (req, res) => {
    const q = String(req.query.q ?? '').trim();
    res.json({ players: q.length < 2 ? [] : repo.searchProfiles(q, 10) });
  });

  app.get('/api/player/:ign', (req, res) => {
    const p = repo.getPublicPlayer(String(req.params.ign));
    if (!p) return void res.status(404).json({ error: 'Player not found.' });
    res.json(p);
  });

  /* ------------------------------ logged-in player ------------------------------ */
  app.get('/api/me', (req: Req, res) => {
    if (!req.session) return void res.json({ loggedIn: false, loginAvailable: !!config.clientSecret });
    const uid = req.session.discord_id;
    const profile = repo.getProfile(uid);
    const cur = repo.getPlayerTiers(uid);
    const selected = new Set(repo.getProfileGamemodeIds(uid));
    res.json({
      loggedIn: true,
      username: req.session.username,
      profile: profile ? { ign: profile.ign, createdAt: profile.created_at, updatedAt: profile.updated_at, testsCompleted: repo.countResults(uid) } : null,
      gamemodes: repo.listGamemodes(true).map((g) => ({
        id: g.id, name: g.name, emoji: g.emoji,
        selected: selected.has(g.id),
        tier: cur[g.id] ?? 'Not Tested', // read-only: set by testers only
        verified: !!cur[g.id],
      })),
    });
  });

  app.post('/api/me/profile', (req: Req, res, next) => {
    try {
      if (!req.session) return void res.status(401).json({ error: 'Log in with Discord first.' });
      if (limited(`profile:${req.session.discord_id}`, 20, 60_000)) return void res.status(429).json({ error: 'Slow down a little.' });
      const { ign } = req.body ?? {};
      if (typeof ign !== 'string') throw new AppError('IGN is required.');
      const r = saveIgnFromWeb(req.session.discord_id, req.session.username, ign);
      res.json({ ok: true, ign: r.ign });
    } catch (e) { next(e); }
  });

  /* ------------------------------ Discord OAuth2 ------------------------------ */
  app.get('/auth/login', (_req, res) => {
    if (!config.clientSecret || !config.clientId) return void res.status(503).send('Login is not configured (set DISCORD_CLIENT_SECRET and CLIENT_ID).');
    const state = crypto.randomBytes(16).toString('hex');
    setCookie(res, 'oauth_state', sign(state), 600);
    const q = new URLSearchParams({
      client_id: config.clientId, redirect_uri: config.oauthRedirect, response_type: 'code', scope: 'identify', state, prompt: 'none',
    });
    res.redirect(`https://discord.com/oauth2/authorize?${q}`);
  });

  app.get('/auth/callback', async (req, res) => {
    try {
      const state = unsign(parseCookies(req.headers.cookie).oauth_state);
      if (!state || state !== req.query.state || typeof req.query.code !== 'string') return void res.status(400).send('Invalid login state. Please try again.');
      const tok = await fetch('https://discord.com/api/oauth2/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          client_id: config.clientId, client_secret: config.clientSecret, grant_type: 'authorization_code',
          code: req.query.code, redirect_uri: config.oauthRedirect,
        }),
      });
      if (!tok.ok) throw new Error(`token exchange failed (${tok.status})`);
      const { access_token } = (await tok.json()) as any;
      const me = await fetch('https://discord.com/api/users/@me', { headers: { Authorization: `Bearer ${access_token}` } });
      if (!me.ok) throw new Error(`user lookup failed (${me.status})`);
      const user = (await me.json()) as any;
      repo.upsertUser(user.id, user.username);
      const sid = crypto.randomBytes(32).toString('hex');
      repo.createSession(sid, user.id, user.username, SESSION_TTL_MS);
      setCookie(res, 'sid', sign(sid), SESSION_TTL_MS / 1000);
      setCookie(res, 'oauth_state', '', 0);
      res.redirect('/#/me');
    } catch (e: any) {
      log.error('OAuth callback failed:', e?.message);
      res.status(500).send('Login failed. Please try again.');
    }
  });

  app.post('/auth/logout', (req: Req, res) => {
    if (req.session) repo.deleteSession(req.session.id);
    setCookie(res, 'sid', '', 0);
    res.json({ ok: true });
  });

  /* ------------------------------ static site + errors ------------------------------ */
  app.use(express.static(path.resolve(__dirname, '../../public'), { maxAge: '5m' }));

  app.use((e: any, _req: Request, res: Response, _next: NextFunction) => {
    if (e instanceof AppError) return void res.status(400).json({ error: e.message });
    log.error('Web error:', e?.stack ?? e);
    res.status(500).json({ error: 'Internal server error.' });
  });

  repo.purgeSessions();
  setInterval(() => { try { repo.purgeSessions(); } catch { /* ignore */ } }, 3600_000).unref();

  const server = app.listen(config.webPort, config.webHost, () => {
    log.info(`${BRAND} web panel: ${config.webPublicUrl} (listening on ${config.webHost}:${config.webPort})`);
  });
  return server;
}
